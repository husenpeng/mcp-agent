/** Procedural WebGL Xuhui Riverside at night: the Alibaba campus, the river and bridge, Lujiazui, traffic, and the mark. */

import * as THREE from 'three'
import { Reflector } from 'three/addons/objects/Reflector.js'
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js'
import { SPLASH_TIMINGS } from './splash-timeline.ts'
import {
  SPLASH_AVENUE, SPLASH_BLIMP, SPLASH_BRIDGE, SPLASH_CRAFT, SPLASH_FORM, SPLASH_HERO, SPLASH_LAMPS, SPLASH_LANDMARKS,
  SPLASH_LEANING_TOWERS, SPLASH_MARK, SPLASH_MUSEUM, SPLASH_PROMENADE, SPLASH_RIVER, SPLASH_TANKS, splashCameraAt,
  splashCityLayout, splashFlyers, splashPhase, splashRandom, splashTraffic, type SplashCityLayout, type SplashLane,
} from './splash-city.ts'
import {
  FACADE_FRAGMENT_GLSL, FACADE_VERTEX_GLSL, GROUND_FRAGMENT_GLSL, GROUND_VERTEX_GLSL, PANEL_FRAGMENT_GLSL,
  PANEL_VERTEX_GLSL, SKY_FRAGMENT_GLSL, SKY_VERTEX_GLSL, SOLID_FRAGMENT_GLSL, SOLID_VERTEX_GLSL,
} from './splash-glsl.ts'
import {
  BEAM_FRAGMENT_GLSL, BEAM_VERTEX_GLSL, CRAFT_LIGHT_VERTEX_GLSL, LIGHT_FRAGMENT_GLSL, MARK_FRAGMENT_GLSL,
  MARK_FRONT_SCALE, MARK_VERTEX_GLSL, POINT_LIGHT_VERTEX_GLSL, RAIN_VERTEX_GLSL, SPARK_VERTEX_GLSL,
} from './splash-glsl-light.ts'
import { CRAFT_FRAGMENT_GLSL, CRAFT_VERTEX_GLSL, LANDMARK_FRAGMENT_GLSL, LANDMARK_VERTEX_GLSL } from './splash-glsl-landmark.ts'
import {
  createIgnitionTexture, createMarkGeometry, MARK_FIELD_SIZE, markIgnitionArrival, markIgnitionField,
  markIgnitionSeed, rasterizeMark, sampleMarkPoints,
} from './splash-mark.ts'
import {
  BLIMP_LIGHTS, BLIMP_SCREEN, BOAT_LIGHTS, createBlimpGeometry, createBoatGeometry, createBridge, createHaulerGeometry,
  createLeaningTowers, createMuseumGeometry, createOpenerTower, createPearlTower, createSpinnerGeometry, createTankGeometry,
  createTreeGeometry, createTwistTower, HAULER_LIGHTS, SPINNER_LIGHTS, TREE_TRUNK_HEIGHT, TWIST_RATE, type LandmarkModel,
  type ModelLight,
} from './splash-models.ts'
import { createScreenAtlas } from './splash-signage.ts'
import { createSplashPost } from './splash-post.ts'

/** Lifecycle of the running scene, owned by the splash document. */
export interface SplashScene {
  /** Jump to the resting composition with the mark lit. */
  finish(): void
  /** Stop rendering and release GPU resources. */
  stop(): void
}

/** Uniform objects shared by every city material; assigning `.value` updates all of them. */
interface SharedUniforms {
  readonly uTime: { value: number }
  /** 1 for the main view; 0 while the mirrored ground render draws, which skips interior detail. */
  readonly uDetail: { value: number }
  /** Haze multiplier; distant landmark materials replace it with their own. */
  readonly uHazeScale: { value: number }
  readonly uHoloPos: { value: THREE.Vector3 }
  readonly uHolo: { value: number }
  readonly uFogDensity: { value: number }
  readonly uFogFalloff: { value: number }
}

/** Scene objects animated on the splash timeline. */
interface Animated {
  readonly objects: readonly THREE.Object3D[]
  /**
   * Apply one sample.
   * @param timeline - milliseconds on the splash timeline, clamped at the hold frame.
   * @param seconds - seconds since the timeline started, unclamped, for motion that continues through the hold.
   */
  update(timeline: number, seconds: number): void
  dispose(): void
}

/** A light in world space for the static point-light mesh. */
interface WorldLight {
  readonly position: THREE.Vector3
  readonly color: readonly [number, number, number]
  readonly radius: number
}

/** An artwork atlas and its column/row grid. */
interface Atlas {
  readonly texture: THREE.Texture
  readonly grid: THREE.Vector2
}

/** One projector beam cone and the uniforms that drive it. */
interface Beam {
  readonly mesh: THREE.Mesh
  /** Share of the projector's power this cone carries. */
  readonly strength: number
  readonly power: { value: number }
  readonly reach: { value: number }
}

const staticScene: SplashScene = { finish: () => {}, stop: () => {} }

/** Rain stays out of the mirrored ground render. */
const RAIN_LAYER = 1
const CLEAR_COLOR = 0x0c0b0b
const MAX_PIXEL_RATIO = 2
const MIN_PIXEL_RATIO = 0.8
const SPARK_COUNT = 900
/** Share of the drawing buffer's resolution used by the mirrored ground render; ripple blur hides the loss. */
const MIRROR_SCALE = 0.4
/** Ground distance in metres past which the camera no longer sees open ground or water, so the mirror stops updating. */
const MIRROR_REACH = 900
/** Haze multiplier for Lujiazui, kilometres downstream, so its skyline stays legible behind the bridge. */
const SKYLINE_HAZE = 0.5
/** Riverside park tree rows along X, and the runway path's centre line. */
const TREE_ROWS = [18, 30] as const
/** Crown variants shared by the park trees. */
const TREE_VARIANTS = 3
const RUNWAY_X = 48

function cityMaterial(
  shared: SharedUniforms,
  vertexShader: string,
  fragmentShader: string,
  uniforms: Record<string, { value: unknown }> = {},
  options: THREE.ShaderMaterialParameters = {},
): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({ ...options, vertexShader, fragmentShader, uniforms: { ...shared, ...uniforms } })
}

function solidMaterial(
  shared: SharedUniforms, albedo: THREE.Color | number, sheen: number, emissive = new THREE.Color(0, 0, 0),
): THREE.ShaderMaterial {
  return cityMaterial(shared, SOLID_VERTEX_GLSL, SOLID_FRAGMENT_GLSL, {
    uAlbedo: { value: typeof albedo === 'number' ? new THREE.Color(albedo, albedo * 0.96, albedo * 1.04) : albedo },
    uEmissive: { value: emissive },
    uSheen: { value: sheen },
  })
}

/** Instance a base geometry's vertex attributes once per entry of `attributes`. */
function instanced(
  base: THREE.BufferGeometry,
  count: number,
  attributes: Record<string, THREE.InstancedBufferAttribute>,
): THREE.InstancedBufferGeometry {
  const geometry = new THREE.InstancedBufferGeometry()
  geometry.index = base.index
  for (const [name, attribute] of Object.entries(base.attributes)) geometry.setAttribute(name, attribute)
  for (const [name, attribute] of Object.entries(attributes)) geometry.setAttribute(name, attribute)
  geometry.instanceCount = count
  return geometry
}

function instancedQuad(count: number, attributes: Record<string, THREE.InstancedBufferAttribute>): THREE.InstancedBufferGeometry {
  const quad = new THREE.PlaneGeometry(1, 1)
  quad.deleteAttribute('normal')
  return instanced(quad, count, attributes)
}

/** Light capsules size themselves in pixels, so each draw reads the pixel size of the target it renders into. */
function bindViewport(mesh: THREE.Mesh, material: THREE.ShaderMaterial, viewport: { value: THREE.Vector2 }): void {
  mesh.frustumCulled = false
  mesh.onBeforeRender = (renderer) => {
    const target = renderer.getRenderTarget()
    if (target === null) renderer.getDrawingBufferSize(viewport.value)
    else viewport.value.set(target.width, target.height)
    material.uniformsNeedUpdate = true
  }
}

function lightMesh(
  shared: SharedUniforms,
  viewport: { value: THREE.Vector2 },
  vertexShader: string,
  geometry: THREE.InstancedBufferGeometry,
  uniforms: Record<string, { value: unknown }> = {},
): THREE.Mesh {
  const material = cityMaterial(shared, vertexShader, LIGHT_FRAGMENT_GLSL, { uViewport: viewport, ...uniforms }, {
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    transparent: true,
  })
  const mesh = new THREE.Mesh(geometry, material)
  bindViewport(mesh, material, viewport)
  return mesh
}

function pointLights(
  shared: SharedUniforms,
  viewport: { value: THREE.Vector2 },
  lights: readonly WorldLight[],
  offset: { value: THREE.Vector3 } = { value: new THREE.Vector3() },
): THREE.Mesh {
  const heads = new Float32Array(lights.length * 3)
  const colors = new Float32Array(lights.length * 4)
  lights.forEach((light, index) => {
    heads.set([light.position.x, light.position.y, light.position.z], index * 3)
    colors.set([...light.color, light.radius], index * 4)
  })
  return lightMesh(shared, viewport, POINT_LIGHT_VERTEX_GLSL, instancedQuad(lights.length, {
    aHead: new THREE.InstancedBufferAttribute(heads, 3),
    aLight: new THREE.InstancedBufferAttribute(colors, 4),
  }), { uLightOffset: offset })
}

function modelLights(lights: readonly ModelLight[], matrix: THREE.Matrix4): WorldLight[] {
  return lights.map(light => ({
    position: new THREE.Vector3(...light.offset).applyMatrix4(matrix),
    color: light.color,
    radius: light.radius,
  }))
}

/** Lights in a model's local frame, placed at the origin for meshes that move them with `uLightOffset`. */
function localLights(lights: readonly ModelLight[]): WorldLight[] {
  return modelLights(lights, new THREE.Matrix4())
}

function createCity(layout: SplashCityLayout, shared: SharedUniforms): THREE.Mesh[] {
  const box = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0)
  const drum = new THREE.CylinderGeometry(0.5, 0.5, 1, 48, 1).translate(0, 0.5, 0)
  return ([[SPLASH_FORM.box, box], [SPLASH_FORM.round, drum]] as const).map(([form, base]) => {
    const tiers = layout.tiers.filter(tier => tier.form === form)
    const centres = new Float32Array(tiers.length * 3)
    const sizes = new Float32Array(tiers.length * 4)
    const styles = new Float32Array(tiers.length * 4)
    tiers.forEach((tier, index) => {
      centres.set([tier.x, tier.y, tier.z], index * 3)
      sizes.set([tier.width, tier.height, tier.depth, tier.taper], index * 4)
      styles.set([tier.seed, tier.facade, tier.lit, tier.trim], index * 4)
    })
    base.deleteAttribute('uv')
    const geometry = instanced(base, tiers.length, {
      aCenter: new THREE.InstancedBufferAttribute(centres, 3),
      aSize: new THREE.InstancedBufferAttribute(sizes, 4),
      aStyle: new THREE.InstancedBufferAttribute(styles, 4),
    })
    const mesh = new THREE.Mesh(geometry, cityMaterial(shared, FACADE_VERTEX_GLSL, FACADE_FRAGMENT_GLSL, {}, {
      defines: form === SPLASH_FORM.round ? { RADIAL: '' } : {},
    }))
    mesh.frustumCulled = false
    return mesh
  })
}

function createGround(shared: SharedUniforms): Reflector {
  // The plane spans both banks and the river from upstream of the camera to beyond Lujiazui.
  const reflector = new Reflector(new THREE.PlaneGeometry(3200, 5600), {
    textureWidth: 1,
    textureHeight: 1,
    clipBias: 0.003,
    color: 0xddd6cf,
    multisample: 4,
    shader: {
      name: 'SplashGround',
      uniforms: {
        color: { value: null },
        tDiffuse: { value: null },
        textureMatrix: { value: null },
        uStreet: { value: new THREE.Vector4(SPLASH_LAMPS.x, SPLASH_LAMPS.spacing, SPLASH_PROMENADE.from, SPLASH_PROMENADE.to) },
        uRiver: { value: new THREE.Vector4(SPLASH_RIVER.west, SPLASH_RIVER.east, SPLASH_AVENUE.halfWidth, RUNWAY_X) },
        uAvenue: { value: new THREE.Vector2(SPLASH_AVENUE.start, SPLASH_AVENUE.end) },
      },
      vertexShader: GROUND_VERTEX_GLSL,
      fragmentShader: GROUND_FRAGMENT_GLSL,
    },
  })
  const material = reflector.material
  if (!(material instanceof THREE.ShaderMaterial)) throw new Error('splash: ground reflector has no shader material')
  // Reflector clones its shader uniforms; reattach the shared objects so one assignment drives every surface.
  Object.assign(material.uniforms, shared)
  const texture = reflector.getRenderTarget().texture
  texture.generateMipmaps = true
  texture.minFilter = THREE.LinearMipmapLinearFilter
  reflector.rotation.x = -Math.PI / 2
  reflector.position.set(300, 0, -1400)
  // The mirrored render skips interior detail; ripple blur hides it and it would double the facade cost.
  // Once the camera's lowest ray meets the ground past MIRROR_REACH, the mirror keeps its last frame.
  const mirror = reflector.onBeforeRender.bind(reflector)
  const forward = new THREE.Vector3()
  reflector.onBeforeRender = (renderer, scene, camera, ...rest) => {
    if (camera instanceof THREE.PerspectiveCamera) {
      const lowest = Math.asin(camera.getWorldDirection(forward).y) - THREE.MathUtils.degToRad(camera.fov / 2)
      if (lowest > -0.01 || camera.position.y / Math.tan(-lowest) > MIRROR_REACH) return
    }
    shared.uDetail.value = 0
    mirror(renderer, scene, camera, ...rest)
    shared.uDetail.value = 1
  }
  return reflector
}

function createSky(shared: SharedUniforms): THREE.Mesh {
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(1600, 48, 24),
    cityMaterial(shared, SKY_VERTEX_GLSL, SKY_FRAGMENT_GLSL, {}, { side: THREE.BackSide, depthTest: false, depthWrite: false }),
  )
  sky.renderOrder = -1
  sky.frustumCulled = false
  sky.onBeforeRender = (_renderer, _scene, camera) => {
    sky.position.copy(camera.position)
    sky.updateMatrixWorld()
  }
  return sky
}

/** One instance of a prop mesh: position, scale, and yaw about the vertical axis. */
interface Placement {
  readonly position: THREE.Vector3
  readonly scale: THREE.Vector3
  readonly yaw?: number
}

function placeBoxes(mesh: THREE.InstancedMesh, boxes: readonly Placement[]): THREE.InstancedMesh {
  const matrix = new THREE.Matrix4()
  const rotation = new THREE.Quaternion()
  const up = new THREE.Vector3(0, 1, 0)
  boxes.forEach((box, index) => {
    rotation.setFromAxisAngle(up, box.yaw ?? 0)
    mesh.setMatrixAt(index, matrix.compose(box.position, rotation, box.scale))
  })
  mesh.instanceMatrix.needsUpdate = true
  return mesh
}

/** Lamp post with an arm reaching toward the road along -X. */
function lampGeometry(): THREE.BufferGeometry {
  const height = SPLASH_LAMPS.height
  const parts = [
    new THREE.BoxGeometry(0.22, height, 0.22).translate(0, height / 2, 0),
    new THREE.BoxGeometry(2.4, 0.14, 0.16).translate(-1.15, height - 0.1, 0),
    new THREE.BoxGeometry(0.9, 0.2, 0.42).translate(-2.1, height - 0.25, 0),
  ]
  const merged = mergeGeometries(parts, false)
  for (const part of parts) part.dispose()
  return merged
}

function lampPositions(): { x: number; z: number; side: -1 | 1 }[] {
  const lamps: { x: number; z: number; side: -1 | 1 }[] = []
  for (let z: number = SPLASH_AVENUE.start; z > SPLASH_AVENUE.end; z -= SPLASH_LAMPS.spacing) {
    lamps.push({ x: -SPLASH_LAMPS.x, z, side: -1 }, { x: SPLASH_LAMPS.x, z, side: 1 })
  }
  return lamps
}

/** Whether a park position is taken by the art centre's tanks, the museum, or the bridge pier. */
function parkTaken(x: number, z: number, reach: number): boolean {
  const tank = SPLASH_TANKS.some(entry => Math.hypot(x - entry.x, z - entry.z) < entry.radius + reach + 3)
  const museum = SPLASH_MUSEUM.some(box =>
    Math.abs(z - box.z) < box.depth / 2 + reach + 4 && Math.abs(x - box.x) < box.width / 2 + reach + 4)
  return tank || museum || Math.abs(z - SPLASH_BRIDGE.z) < SPLASH_BRIDGE.width / 2 + reach + 4
}

/** A park tree: its placement, crown variant, leaf tone in [0, 1), and whether an uplight stands at its foot. */
interface TreePlacement extends Placement {
  readonly variant: number
  readonly tone: number
  readonly uplit: boolean
}

/** Park trees in two rows beside the avenue, varied in size, spacing, crown, and leaf tone; every third is uplit. */
function treePlacements(): TreePlacement[] {
  const random = splashRandom(0x7ee5)
  const trees: TreePlacement[] = []
  for (const row of TREE_ROWS) {
    for (let z: number = SPLASH_AVENUE.start; z > SPLASH_AVENUE.end; z -= 8 + random() * 4) {
      const x = row + (random() - 0.5) * 3
      const size = 0.8 + random() * 0.45
      if (parkTaken(x, z, 3.6 * size)) continue
      const height = size * (0.9 + random() * 0.25)
      trees.push({
        position: new THREE.Vector3(x, 0, z),
        scale: new THREE.Vector3(size, height, size),
        yaw: random() * Math.PI * 2,
        variant: Math.floor(random() * TREE_VARIANTS),
        tone: random(),
        uplit: trees.length % 3 === 0,
      })
    }
  }
  return trees
}

/** One instanced mesh per crown variant; `instanceColor` carries each tree's leaf tone, uplight, and noise seed. */
function createTrees(shared: SharedUniforms, trees: readonly TreePlacement[]): THREE.InstancedMesh[] {
  const material = cityMaterial(shared, SOLID_VERTEX_GLSL, SOLID_FRAGMENT_GLSL, {
    uAlbedo: { value: new THREE.Color(1, 1, 1) },
    uEmissive: { value: new THREE.Color(0, 0, 0) },
    uSheen: { value: 0.12 },
    uTrunkHeight: { value: TREE_TRUNK_HEIGHT },
  }, { defines: { FOLIAGE: '' } })
  const tint = new THREE.Color()
  return Array.from({ length: TREE_VARIANTS }, (_, variant) => ({ variant, members: trees.filter(tree => tree.variant === variant) }))
    .filter(({ members }) => members.length > 0)
    .map(({ variant, members }) => {
      const geometry = createTreeGeometry(splashRandom(0x7ee0 + variant))
      const mesh = placeBoxes(new THREE.InstancedMesh(geometry, material, members.length), members)
      members.forEach((tree, index) => {
        mesh.setColorAt(index, tint.setRGB(tree.tone, tree.uplit ? 1 : 0, (index * 0.618) % 1))
      })
      return mesh
    })
}

function createProps(layout: SplashCityLayout, shared: SharedUniforms, trees: readonly TreePlacement[]): THREE.Object3D[] {
  const metal = solidMaterial(shared, 0.05, 0.25)
  const units = placeBoxes(
    new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), metal, layout.roofUnits.length),
    layout.roofUnits.map(unit => ({
      position: new THREE.Vector3(unit.x, unit.y, unit.z),
      scale: new THREE.Vector3(unit.width, unit.height, unit.depth),
    })),
  )
  const masts = placeBoxes(
    new THREE.InstancedMesh(new THREE.CylinderGeometry(0.04, 1, 1, 12).translate(0, 0.5, 0), metal, layout.antennas.length),
    layout.antennas.map(mast => ({
      position: new THREE.Vector3(mast.x, mast.y, mast.z),
      scale: new THREE.Vector3(mast.radius, mast.height, mast.radius),
    })),
  )
  const lamps = lampPositions()
  const posts = placeBoxes(
    new THREE.InstancedMesh(lampGeometry(), metal, lamps.length),
    lamps.map(lamp => ({
      position: new THREE.Vector3(lamp.x, 0, lamp.z),
      scale: new THREE.Vector3(1, 1, 1),
      yaw: lamp.side > 0 ? 0 : Math.PI,
    })),
  )
  const housings = placeBoxes(
    new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), metal, layout.screens.length),
    layout.screens.map(screen => ({
      position: new THREE.Vector3(screen.x - Math.sin(screen.yaw) * 0.25, screen.y, screen.z - Math.cos(screen.yaw) * 0.25),
      scale: new THREE.Vector3(screen.width + 0.5, screen.height + 0.5, 0.4),
      yaw: screen.yaw,
    })),
  )
  const course = (SPLASH_AVENUE.start + SPLASH_AVENUE.end) / 2
  // Granite kerbs edge the avenue.
  const kerbs = placeBoxes(
    new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), solidMaterial(shared, 0.09, 0.15), 2),
    [-1, 1].map(side => ({
      position: new THREE.Vector3(side * (SPLASH_AVENUE.halfWidth + 0.15), 0, course),
      scale: new THREE.Vector3(0.3, 0.15, SPLASH_AVENUE.start - SPLASH_AVENUE.end),
    })),
  )
  // A glowing handrail runs along the river bank.
  const railing = new THREE.Mesh(
    new THREE.BoxGeometry(0.16, 0.12, SPLASH_AVENUE.start - SPLASH_AVENUE.end).translate(SPLASH_RIVER.west - 0.6, 1.05, course),
    solidMaterial(shared, 0.02, 0, new THREE.Color(0.3, 0.25, 0.19)),
  )
  return [units, masts, posts, housings, kerbs, railing, ...createTrees(shared, trees)]
}

/** Aviation lights on masts, lamp heads, park bollards, and tree uplights. */
function cityLights(layout: SplashCityLayout, trees: readonly TreePlacement[]): WorldLight[] {
  const lights: WorldLight[] = []
  const light = (x: number, y: number, z: number, color: readonly [number, number, number], radius: number): void => {
    lights.push({ position: new THREE.Vector3(x, y, z), color, radius })
  }
  for (const mast of layout.antennas) light(mast.x, mast.y + mast.height, mast.z, [1.6, 0.08, 0.06], Math.max(0.55, mast.radius * 0.5))
  for (const lamp of lampPositions()) light(lamp.x - lamp.side * 2.1, SPLASH_LAMPS.height - 0.42, lamp.z, [1.8, 1.25, 0.8], 0.4)
  for (let z: number = SPLASH_AVENUE.start; z > SPLASH_AVENUE.end; z -= 18) {
    if (!parkTaken(RUNWAY_X - 10, z, 1)) light(RUNWAY_X - 10, 0.9, z, [1.4, 1.0, 0.65], 0.22)
  }
  for (const tree of trees) {
    if (tree.uplit) light(tree.position.x + 1.2, 0.4, tree.position.z, [1.1, 0.85, 0.55], 0.25)
  }
  return lights
}

function laneAttributes(lanes: readonly SplashLane[]): { lane: Float32Array; motion: Float32Array } {
  const lane = new Float32Array(lanes.length * 4)
  const motion = new Float32Array(lanes.length * 4)
  lanes.forEach((entry, index) => {
    lane.set([entry.origin.x, entry.origin.y, entry.origin.z, entry.speed], index * 4)
    motion.set([entry.directionX, entry.directionZ, entry.phase, entry.span], index * 4)
  })
  return { lane, motion }
}

const CRAFT_LIGHTS: Record<number, readonly ModelLight[]> = {
  [SPLASH_CRAFT.spinner]: SPINNER_LIGHTS,
  [SPLASH_CRAFT.hauler]: HAULER_LIGHTS,
  [SPLASH_CRAFT.boat]: BOAT_LIGHTS,
}

/** Spinners, haulers, and cruise boats on their lanes, their lights, and the light-only cars and distant craft. */
function createTraffic(shared: SharedUniforms, viewport: { value: THREE.Vector2 }): THREE.Object3D[] {
  const flyers = splashFlyers()
  const objects: THREE.Object3D[] = []
  const models = [
    [SPLASH_CRAFT.spinner, createSpinnerGeometry()],
    [SPLASH_CRAFT.hauler, createHaulerGeometry()],
    [SPLASH_CRAFT.boat, createBoatGeometry()],
  ] as const
  for (const [kind, base] of models) {
    const craft = flyers.filter(flyer => flyer.kind === kind)
    const { lane, motion } = laneAttributes(craft)
    const looks = new Float32Array(craft.length * 4)
    craft.forEach((flyer, index) => { looks.set([...flyer.paint, flyer.bob], index * 4) })
    const mesh = new THREE.Mesh(
      instanced(base, craft.length, {
        aLane: new THREE.InstancedBufferAttribute(lane, 4),
        aMotion: new THREE.InstancedBufferAttribute(motion, 4),
        aCraft: new THREE.InstancedBufferAttribute(looks, 4),
      }),
      cityMaterial(shared, CRAFT_VERTEX_GLSL, CRAFT_FRAGMENT_GLSL, {}, { defines: { LANE: '' } }),
    )
    mesh.frustumCulled = false
    objects.push(mesh)
  }
  const lights: { lane: SplashLane; light: ModelLight }[] = flyers.flatMap(flyer =>
    (CRAFT_LIGHTS[flyer.kind] ?? []).map(light => ({ lane: flyer, light })))
  for (const vehicle of splashTraffic()) {
    lights.push({
      lane: vehicle,
      light: {
        offset: [0, 0, 0],
        color: vehicle.headlight ? [1.1, 1.0, 0.9] : [1.2, 0.06, 0.04],
        radius: vehicle.radius,
        kind: vehicle.headlight ? 1 : 2,
        trail: vehicle.trail,
      },
    })
  }
  const { lane, motion } = laneAttributes(lights.map(entry => entry.lane))
  const offsets = new Float32Array(lights.length * 4)
  const colors = new Float32Array(lights.length * 4)
  const kinds = new Float32Array(lights.length * 2)
  lights.forEach(({ lane: owner, light }, index) => {
    offsets.set([...light.offset, owner.bob], index * 4)
    colors.set([...light.color, light.radius], index * 4)
    kinds.set([light.kind, light.trail], index * 2)
  })
  objects.push(lightMesh(shared, viewport, CRAFT_LIGHT_VERTEX_GLSL, instancedQuad(lights.length, {
    aLane: new THREE.InstancedBufferAttribute(lane, 4),
    aMotion: new THREE.InstancedBufferAttribute(motion, 4),
    aOffset: new THREE.InstancedBufferAttribute(offsets, 4),
    aLight: new THREE.InstancedBufferAttribute(colors, 4),
    aKind: new THREE.InstancedBufferAttribute(kinds, 2),
  })))
  return objects
}

function createRain(shared: SharedUniforms, viewport: { value: THREE.Vector2 }): THREE.Mesh {
  const count = 2400
  const drops = new Float32Array(count * 4)
  let state = 0x2a17
  for (let index = 0; index < drops.length; index += 1) {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0
    drops[index] = state / 4294967296
  }
  const rain = lightMesh(shared, viewport, RAIN_VERTEX_GLSL, instancedQuad(count, {
    aDrop: new THREE.InstancedBufferAttribute(drops, 4),
  }), { uRainBox: { value: new THREE.Vector3(56, 40, 56) }, uRain: { value: 1 } })
  rain.layers.set(RAIN_LAYER)
  return rain
}

function createPanels(
  shared: SharedUniforms,
  panels: readonly { x: number; y: number; z: number; yaw: number; width: number; height: number; slot: number }[],
  atlas: Atlas,
  glow: number,
  offset: { value: THREE.Vector3 } = { value: new THREE.Vector3() },
): THREE.Mesh {
  const placement = new Float32Array(panels.length * 4)
  const shape = new Float32Array(panels.length * 4)
  panels.forEach((panel, index) => {
    placement.set([panel.x, panel.y, panel.z, panel.yaw], index * 4)
    shape.set([panel.width, panel.height, panel.slot, glow], index * 4)
  })
  const mesh = new THREE.Mesh(
    instancedQuad(panels.length, {
      aPanel: new THREE.InstancedBufferAttribute(placement, 4),
      aShape: new THREE.InstancedBufferAttribute(shape, 4),
    }),
    cityMaterial(shared, PANEL_VERTEX_GLSL, PANEL_FRAGMENT_GLSL, {
      uAtlas: { value: atlas.texture },
      uGrid: { value: atlas.grid },
      uPanelOffset: offset,
    }),
  )
  mesh.frustumCulled = false
  return mesh
}

/** Uniforms the landmark shader reads; `axis`, `radius`, and `twistRate` only matter to the twisting tower. */
function landmarkUniforms(seed: number, axis = new THREE.Vector2(), radius = 1, twistRate = 0): Record<string, { value: unknown }> {
  return { uSeed: { value: seed }, uAxis: { value: axis }, uRadius: { value: radius }, uTwistRate: { value: twistRate } }
}

function landmarkMesh(
  shared: SharedUniforms, geometry: THREE.BufferGeometry, defines: readonly string[], uniforms: Record<string, { value: unknown }>,
): THREE.Mesh {
  return new THREE.Mesh(geometry, cityMaterial(shared, LANDMARK_VERTEX_GLSL, LANDMARK_FRAGMENT_GLSL, uniforms, {
    defines: Object.fromEntries(defines.map(name => [name, ''])),
  }))
}

/** Place one Lujiazui landmark at its scale; the opener turns its front toward the resting camera. */
function placeLandmark(
  shared: SharedUniforms,
  model: LandmarkModel,
  plot: { readonly x: number; readonly z: number; readonly scale: number },
  faceCamera: boolean,
  uniforms: Record<string, { value: unknown }>,
): { group: THREE.Group; lights: WorldLight[] } {
  const group = new THREE.Group()
  const hazed = { ...uniforms, uHazeScale: { value: SKYLINE_HAZE } }
  for (const surface of model.surfaces) group.add(landmarkMesh(shared, surface.geometry, surface.defines, hazed))
  for (const outline of model.outlines) {
    const curve = new THREE.CatmullRomCurve3([...outline.points], false, 'centripetal')
    const tube = new THREE.TubeGeometry(curve, outline.points.length * 2, outline.radius, 6, false)
    const neon = solidMaterial(shared, 0.02, 0, new THREE.Color(...outline.color))
    neon.uniforms.uHazeScale = { value: SKYLINE_HAZE }
    group.add(new THREE.Mesh(tube, neon))
  }
  group.position.set(plot.x, 0, plot.z)
  group.scale.setScalar(plot.scale)
  if (faceCamera) {
    const rest = splashCameraAt(1).position
    group.rotation.y = Math.atan2(rest.x - plot.x, rest.z - plot.z)
  }
  group.updateMatrixWorld(true)
  return { group, lights: modelLights(model.lights, group.matrixWorld) }
}

/** Lujiazui across the river, the X plot's leaning towers, the art centre's tanks, the museum, and the arch bridge. */
function createLandmarks(shared: SharedUniforms): { objects: THREE.Object3D[]; lights: WorldLight[] } {
  const { pearl, twist, opener } = SPLASH_LANDMARKS
  const twistUniforms = landmarkUniforms(0.83, new THREE.Vector2(twist.x, twist.z), twist.radius * twist.scale, TWIST_RATE / twist.scale)
  const skyline = [
    placeLandmark(shared, createPearlTower(), pearl, false, landmarkUniforms(0.31)),
    placeLandmark(shared, createTwistTower(), twist, false, twistUniforms),
    placeLandmark(shared, createOpenerTower(), opener, true, landmarkUniforms(0.62)),
  ]
  const bridge = createBridge()
  const ribGlow = new THREE.Color(1.25, 0.72, 0.3)
  const objects: THREE.Object3D[] = [
    ...skyline.map(entry => entry.group),
    landmarkMesh(shared, createLeaningTowers(SPLASH_LEANING_TOWERS), ['BAKED', 'CRYSTAL'], landmarkUniforms(0.52)),
    landmarkMesh(shared, createTankGeometry(SPLASH_TANKS), ['BAKED', 'TANK'], landmarkUniforms(0.21)),
    landmarkMesh(shared, createMuseumGeometry(), ['TRANSLUCENT'], landmarkUniforms(0.12)),
    new THREE.Mesh(bridge.structure, solidMaterial(shared, 0.06, 0.35)),
    new THREE.Mesh(bridge.ribs, solidMaterial(shared, 0.04, 0.3, ribGlow)),
    new THREE.Mesh(bridge.hangers, solidMaterial(shared, 0.04, 0.2, new THREE.Color(0.32, 0.2, 0.09))),
    new THREE.Mesh(bridge.strips, solidMaterial(shared, 0.02, 0, new THREE.Color(1.2, 0.95, 0.7))),
  ]
  return { objects, lights: [...skyline.flatMap(entry => entry.lights), ...localLights(bridge.lights)] }
}

/** Advertising airship hovering beside Building 8; its screen and lights follow the hull. */
function createBlimp(shared: SharedUniforms, viewport: { value: THREE.Vector2 }, atlas: Atlas): Animated {
  const hull = new THREE.Mesh(
    createBlimpGeometry(SPLASH_BLIMP.length, SPLASH_BLIMP.radius),
    cityMaterial(shared, CRAFT_VERTEX_GLSL, CRAFT_FRAGMENT_GLSL, { uPaint: { value: new THREE.Color(0.035, 0.034, 0.04) } }),
  )
  const offset = { value: new THREE.Vector3(SPLASH_BLIMP.x, SPLASH_BLIMP.y, SPLASH_BLIMP.z) }
  const panel = { x: 0, y: BLIMP_SCREEN.y, z: BLIMP_SCREEN.z, yaw: 0, width: BLIMP_SCREEN.width, height: BLIMP_SCREEN.height, slot: 3 }
  const screen = createPanels(shared, [panel], atlas, 1.1, offset)
  const lights = pointLights(shared, viewport, localLights(BLIMP_LIGHTS), offset)
  return {
    objects: [hull, screen, lights],
    update: (_timeline, seconds) => {
      offset.value.set(SPLASH_BLIMP.x + Math.sin(seconds * 0.12) * 1.5, SPLASH_BLIMP.y + Math.sin(seconds * 0.5) * 0.4, SPLASH_BLIMP.z)
      hull.position.copy(offset.value)
    },
    dispose: () => {},
  }
}

/** Building 8's roof projector, beams, the mark whose strokes light up from the beam's contact point, and its sparks. */
function createProjector(shared: SharedUniforms, viewport: { value: THREE.Vector2 }): Animated {
  const { x, z, deck } = SPLASH_HERO
  const metal = solidMaterial(shared, 0.04, 0.4)
  const ringGlow = new THREE.Color(0, 0, 0)
  const ring = new THREE.Mesh(new THREE.TorusGeometry(8.4, 0.4, 12, 128), solidMaterial(shared, 0.03, 0.2, ringGlow))
  ring.rotation.x = Math.PI / 2
  ring.position.set(x, deck + 0.9, z)
  const innerGlow = new THREE.Color(0, 0, 0)
  const innerRing = new THREE.Mesh(new THREE.TorusGeometry(5.2, 0.2, 10, 96), solidMaterial(shared, 0.03, 0.2, innerGlow))
  innerRing.rotation.x = Math.PI / 2
  innerRing.position.set(x, deck + 2.5, z)
  const housing = new THREE.Mesh(new THREE.CylinderGeometry(3.1, 4.4, 2.7, 48), metal)
  housing.position.set(x, deck + 1.35, z)
  const lensGlow = new THREE.Color(0, 0, 0)
  const lens = new THREE.Mesh(new THREE.CircleGeometry(2.7, 48), solidMaterial(shared, 0.02, 0.1, lensGlow))
  lens.rotation.x = -Math.PI / 2
  lens.position.set(x, deck + 2.72, z)
  const fins = placeBoxes(
    new THREE.InstancedMesh(new THREE.BoxGeometry(0.3, 2.6, 2.6).translate(0, 1.3, 0), metal, 12),
    Array.from({ length: 12 }, (_, index) => {
      const angle = index / 12 * Math.PI * 2
      const position = new THREE.Vector3(x + Math.sin(angle) * 6.8, deck, z + Math.cos(angle) * 6.8)
      return { position, scale: new THREE.Vector3(1, 1, 1), yaw: angle }
    }),
  )

  const { geometry: markGeometry, project } = createMarkGeometry(SPLASH_MARK.width)
  const mask = rasterizeMark(MARK_FIELD_SIZE)
  const travel = markIgnitionField(mask, MARK_FIELD_SIZE, markIgnitionSeed(mask, MARK_FIELD_SIZE))
  const field = createIgnitionTexture(travel, MARK_FIELD_SIZE)
  const ignite = { value: 0 }
  const dormant = { value: 0 }
  const mark = new THREE.Mesh(markGeometry, cityMaterial(shared, MARK_VERTEX_GLSL, MARK_FRAGMENT_GLSL, {
    uField: { value: field },
    uIgnite: ignite,
    uDormant: dormant,
  }))
  const rest = splashCameraAt(1).position
  // The mark turns and leans toward the resting camera so its face reads without foreshortening.
  const facing = Math.atan2(rest.x - SPLASH_MARK.x, rest.z - SPLASH_MARK.z)
  const tilt = Math.atan2(SPLASH_MARK.y - rest.y, Math.hypot(rest.x - SPLASH_MARK.x, rest.z - SPLASH_MARK.z))
  mark.position.set(SPLASH_MARK.x, SPLASH_MARK.y, SPLASH_MARK.z)
  mark.rotation.set(tilt, facing, 0, 'YXZ')
  mark.updateMatrixWorld()

  const lensTop = deck + 2.75
  const markBottom = SPLASH_MARK.y + (markGeometry.boundingBox?.min.y ?? -SPLASH_MARK.width * 0.3) * Math.cos(tilt)
  const beam = (bottomRadius: number, topRadius: number, top: number, strength: number): Beam => {
    const power = { value: 0 }
    const reach = { value: 0 }
    const length = top - lensTop
    const mesh = new THREE.Mesh(
      new THREE.CylinderGeometry(topRadius, bottomRadius, length, 64, 1, true),
      cityMaterial(shared, BEAM_VERTEX_GLSL, BEAM_FRAGMENT_GLSL, { uBeam: power, uBeamReach: reach }, {
        blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, side: THREE.DoubleSide,
      }),
    )
    mesh.position.set(x, lensTop + length / 2, z)
    return { mesh, strength, power, reach }
  }
  const core = beam(1.5, 1.1, markBottom + 0.6, 1)
  const volume = beam(3.4, SPLASH_MARK.width * 0.46, SPLASH_MARK.y, 0.32)

  // Each spark rises inside the beam, fans out below the mark, and lands as the ignition front reaches its stroke point.
  let state = 0x51a4
  const random = (): number => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0
    return state / 4294967296
  }
  const points = sampleMarkPoints(mask, travel, MARK_FIELD_SIZE, SPARK_COUNT, random)
  const from = new Float32Array(points.length * 3)
  const via = new Float32Array(points.length * 3)
  const to = new Float32Array(points.length * 3)
  const timing = new Float32Array(points.length * 2)
  points.forEach((point, index) => {
    const angle = random() * Math.PI * 2
    const spread = Math.sqrt(random()) * 1.2
    const target = project(point.u, point.v, 0.9).applyMatrix4(mark.matrixWorld)
    from.set([x + Math.cos(angle) * spread, lensTop + 0.4, z + Math.sin(angle) * spread], index * 3)
    via.set([x + Math.cos(angle) * spread * 1.8, markBottom - 3 - random() * 5, z + Math.sin(angle) * spread * 1.8], index * 3)
    to.set([target.x, target.y, target.z], index * 3)
    const arrival = markIgnitionArrival(point.travel, SPLASH_TIMINGS.igniteMs, SPLASH_TIMINGS.igniteRampMs, MARK_FRONT_SCALE)
    timing.set([Math.max(SPLASH_TIMINGS.sparksMs, arrival - 620 - random() * 380), arrival], index * 2)
  })
  const sparkTimeline = { value: 0 }
  const sparks = lightMesh(shared, viewport, SPARK_VERTEX_GLSL, instancedQuad(points.length, {
    aFrom: new THREE.InstancedBufferAttribute(from, 3),
    aVia: new THREE.InstancedBufferAttribute(via, 3),
    aTo: new THREE.InstancedBufferAttribute(to, 3),
    aTiming: new THREE.InstancedBufferAttribute(timing, 2),
  }), { uTimeline: sparkTimeline })

  return {
    objects: [ring, innerRing, housing, lens, fins, core.mesh, volume.mesh, mark, sparks],
    update: (timeline, seconds) => {
      const { projectorMs, projectorRampMs, beamMs, beamRampMs, igniteMs, igniteRampMs } = SPLASH_TIMINGS
      const projector = splashPhase(timeline, projectorMs, projectorRampMs)
      const reach = splashPhase(timeline, beamMs, beamRampMs)
      const lit = splashPhase(timeline, igniteMs, igniteRampMs)
      ringGlow.setRGB(2.3 * projector, 0.12 * projector, 0.09 * projector)
      innerGlow.setRGB(0.25 * projector, 1.2 * projector, 1.7 * projector)
      lensGlow.setRGB(3.2 * projector, 0.9 * projector, 0.7 * projector)
      for (const part of [core, volume]) {
        part.power.value = part.strength * projector * (1 - 0.35 * lit)
        part.reach.value = reach * 1.04
      }
      dormant.value = splashPhase(timeline, beamMs + beamRampMs * 0.6, 500)
      ignite.value = lit
      sparkTimeline.value = timeline
      const settle = splashPhase(timeline, igniteMs + igniteRampMs - 200, 1600)
      mark.rotation.y = facing + 0.16 * Math.sin(seconds * 0.42) * settle
      shared.uHolo.value = 0.22 * projector + 0.78 * lit
    },
    dispose: () => { field.dispose() },
  }
}

function isMesh(object: THREE.Object3D): object is THREE.Mesh {
  return object instanceof THREE.Mesh
}

function disposeScene(scene: THREE.Scene): void {
  scene.traverse((object) => {
    if (object instanceof Reflector) {
      object.dispose()
      object.geometry.dispose()
      return
    }
    if (!isMesh(object)) return
    object.geometry.dispose()
    const materials = Array.isArray(object.material) ? object.material : [object.material]
    for (const material of materials) {
      if (material instanceof THREE.ShaderMaterial) {
        for (const uniform of Object.values(material.uniforms)) {
          const value: unknown = uniform.value
          if (value instanceof THREE.CanvasTexture) value.dispose()
        }
      }
      material.dispose()
    }
  })
}

function renderScene(canvas: HTMLCanvasElement, reducedMotion: boolean, onReady: () => void): SplashScene {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance', stencil: false })
  let shaderFailed = false
  renderer.debug.onShaderError = (gl, _program, vertexShader, fragmentShader) => {
    shaderFailed = true
    console.error('Tomato splash: shader compilation failed', gl.getShaderInfoLog(vertexShader), gl.getShaderInfoLog(fragmentShader))
  }
  renderer.setClearColor(CLEAR_COLOR, 1)
  let pixelRatio = Math.min(MAX_PIXEL_RATIO, window.devicePixelRatio || 1)
  renderer.setPixelRatio(pixelRatio)

  const shared: SharedUniforms = {
    uTime: { value: 0 },
    uDetail: { value: 1 },
    uHazeScale: { value: 1 },
    uHoloPos: { value: new THREE.Vector3(SPLASH_MARK.x, SPLASH_MARK.y, SPLASH_MARK.z) },
    uHolo: { value: 0 },
    uFogDensity: { value: 0.0013 },
    uFogFalloff: { value: 0.0125 },
  }
  const viewport = { value: new THREE.Vector2(1, 1) }
  const scene = new THREE.Scene()
  const camera = new THREE.PerspectiveCamera(60, 1, 1, 4600)
  camera.layers.enable(RAIN_LAYER)

  const layout = splashCityLayout()
  const trees = treePlacements()
  const screenAtlas = createScreenAtlas(renderer.capabilities.getMaxAnisotropy())
  const ground = createGround(shared)
  ground.getReflectionCamera(camera).layers.disable(RAIN_LAYER)
  const landmarks = createLandmarks(shared)
  const animated = [createProjector(shared, viewport), createBlimp(shared, viewport, screenAtlas)]
  scene.add(
    createSky(shared),
    ground,
    ...createCity(layout, shared),
    ...createProps(layout, shared, trees),
    ...landmarks.objects,
    createPanels(shared, layout.screens, screenAtlas, 1.0),
    ...animated.flatMap(entry => entry.objects),
    pointLights(shared, viewport, [...cityLights(layout, trees), ...landmarks.lights]),
    ...createTraffic(shared, viewport),
    createRain(shared, viewport),
  )
  const post = createSplashPost(renderer, scene, camera)

  let origin = 0
  let started = false
  let skipped = false
  let stopped = false
  let frame = 0
  let samples = 0
  let slowSamples = 0
  let lastStamp = 0
  let adapted = false
  let sizedWidth = -1
  let sizedHeight = -1

  const timelineAt = (now: number): number =>
    (skipped || reducedMotion ? SPLASH_TIMINGS.holdMs : Math.min(SPLASH_TIMINGS.holdMs, now - origin))
  const pose = (timeline: number): void => {
    const shot = splashCameraAt(timeline / SPLASH_TIMINGS.cameraMs)
    camera.position.set(shot.position.x, shot.position.y, shot.position.z)
    camera.fov = shot.fov
    camera.updateProjectionMatrix()
    camera.lookAt(shot.target.x, shot.target.y, shot.target.z)
  }
  const draw = (now: number): void => {
    // Size events need the page's rendering steps; comparing every frame also covers a window laid out while hidden.
    if (canvas.clientWidth !== sizedWidth || canvas.clientHeight !== sizedHeight) resize()
    const timeline = timelineAt(now)
    const seconds = (now - origin) / 1000
    shared.uTime.value = seconds
    post.time.value = seconds
    pose(timeline)
    for (const entry of animated) entry.update(timeline, seconds)
    post.exposure.value = splashPhase(timeline, 0, SPLASH_TIMINGS.fadeInMs)
    post.composer.render()
  }
  const resize = (): void => {
    sizedWidth = canvas.clientWidth
    sizedHeight = canvas.clientHeight
    // A hidden window can report zero size; zero-sized attachments leave every target incomplete.
    const width = Math.max(1, sizedWidth)
    const height = Math.max(1, sizedHeight)
    renderer.setPixelRatio(pixelRatio)
    renderer.setSize(width, height, false)
    post.setSize(width, height, pixelRatio)
    const mirrorPixels = (size: number): number => Math.max(1, Math.round(size * pixelRatio * MIRROR_SCALE))
    ground.getRenderTarget().setSize(mirrorPixels(width), mirrorPixels(height))
    camera.aspect = width / height
    camera.updateProjectionMatrix()
    // Resizing clears the canvas; the reduced-motion frame has no loop to repaint it.
    if (started && reducedMotion && !stopped) draw(performance.now())
  }
  // One downgrade when the first second runs below ~42 fps; repeated switching would itself read as flicker.
  const adapt = (stamp: number): void => {
    if (adapted) return
    if (lastStamp > 0) {
      samples += 1
      if (samples > 8 && stamp - lastStamp > 24) slowSamples += 1
    }
    lastStamp = stamp
    if (samples < 68) return
    adapted = true
    if (slowSamples > 30 && pixelRatio > MIN_PIXEL_RATIO) {
      pixelRatio = Math.max(MIN_PIXEL_RATIO, pixelRatio * 0.72)
      resize()
    }
  }
  const tick = (stamp: number): void => {
    if (stopped) return
    frame = requestAnimationFrame(tick)
    draw(performance.now())
    adapt(stamp)
  }
  const start = (): void => {
    if (stopped) return
    if (shaderFailed) throw new Error('splash: a city shader failed to compile')
    origin = performance.now()
    started = true
    onReady()
    if (reducedMotion) draw(origin)
    else frame = requestAnimationFrame(tick)
  }
  const fallback = (error: unknown): void => {
    console.error('Tomato splash: WebGL scene failed; using the static brand.', error)
    stopped = true
    cancelAnimationFrame(frame)
    document.documentElement.dataset.scene = 'fallback'
    if (!started) {
      started = true
      onReady()
    }
  }

  // The single reduced-motion frame has no loop to notice a new size, so the canvas is also observed.
  const sizing = new ResizeObserver(resize)
  sizing.observe(canvas)
  resize()
  pose(reducedMotion ? SPLASH_TIMINGS.holdMs : 0)
  // Compile every program before the clock starts, so slow shader translation cannot skip the opening.
  // Programs depend on the output color space, so they compile against the composer's linear scene target.
  renderer.setRenderTarget(post.composer.renderTarget1)
  const warmUp = renderer.compileAsync(scene, camera)
  renderer.setRenderTarget(null)
  warmUp
    .then(() => {
      if (stopped) return
      post.exposure.value = 0
      post.composer.render()
      start()
    })
    .catch(fallback)

  return {
    finish: () => {
      skipped = true
      if (started && reducedMotion && !stopped) draw(performance.now())
    },
    stop: () => {
      stopped = true
      cancelAnimationFrame(frame)
      sizing.disconnect()
      for (const entry of animated) entry.dispose()
      disposeScene(scene)
      post.dispose()
      renderer.dispose()
    },
  }
}

/**
 * Start the procedural city, falling back to the static local brand when WebGL is unavailable.
 * @param canvas - target WebGL canvas; null selects the static fallback.
 * @param reducedMotion - render only the composed final frame when true.
 * @param onReady - called once when the timeline starts: after shader warm-up, or immediately on fallback.
 * @returns final-frame and disposal actions owned by the splash document.
 */
export function startSplashScene(canvas: HTMLCanvasElement | null, reducedMotion: boolean, onReady: () => void): SplashScene {
  if (canvas === null) {
    document.documentElement.dataset.scene = 'fallback'
    onReady()
    return staticScene
  }
  try {
    return renderScene(canvas, reducedMotion, onReady)
  } catch (error) {
    console.error('Tomato splash: WebGL initialization failed; using the static brand.', error)
    document.documentElement.dataset.scene = 'fallback'
    onReady()
    return staticScene
  }
}
