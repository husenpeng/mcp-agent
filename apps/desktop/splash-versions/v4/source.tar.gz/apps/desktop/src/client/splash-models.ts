/** Geometry builders for the riverside landmarks, Lujiazui, the bridge, park props, craft, boats, and the airship. */

import * as THREE from 'three'
import { mergeGeometries, mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js'
import {
  SPLASH_BRIDGE, SPLASH_LANDMARKS, SPLASH_MUSEUM, SPLASH_MUSEUM_HEIGHT, SPLASH_RIVER, type SplashLeaningTower, type SplashTank,
} from './splash-city.ts'

/** A light carried by a model, in the model's local frame (craft: +X right, +Y up, +Z forward). */
export interface ModelLight {
  readonly offset: readonly [number, number, number]
  /** Linear radiance. */
  readonly color: readonly [number, number, number]
  /** Radius in metres. */
  readonly radius: number
  /** 0 shines everywhere, 1 is a headlight facing forward, 2 is a tail light facing backward. */
  readonly kind: 0 | 1 | 2
  /** Trail length behind the light, in metres. */
  readonly trail: number
}

/** A neon outline tube: radiance, radius, and the path it follows. */
export interface ModelOutline {
  readonly color: readonly [number, number, number]
  readonly radius: number
  readonly points: readonly THREE.Vector3[]
}

/** A landmark's surfaces and the steady lights mounted on it, in its local frame with the base at y = 0. */
export interface LandmarkModel {
  /** Meshes grouped by the `LANDMARK_FRAGMENT_GLSL` defines that draw them. */
  readonly surfaces: readonly { readonly defines: readonly string[]; readonly geometry: THREE.BufferGeometry }[]
  readonly outlines: readonly ModelOutline[]
  /** Aviation and accent lights. */
  readonly lights: readonly ModelLight[]
}

/** The arch bridge in world space: structure, LED-lit arch ribs, hangers, deck edge strips, and aviation lights. */
export interface BridgeModel {
  readonly structure: THREE.BufferGeometry
  readonly ribs: THREE.BufferGeometry
  readonly hangers: THREE.BufferGeometry
  readonly strips: THREE.BufferGeometry
  readonly lights: readonly ModelLight[]
}

const PEARL_HEIGHT = 318
const TWIST_HEIGHT = 400
const OPENER_HEIGHT = 330

/** Twist of the supertall's rounded triangular plan, in radians per metre of model height: a third of a turn overall. */
export const TWIST_RATE = (2 * Math.PI / 3) / TWIST_HEIGHT

const AVIATION_RED = [1.7, 0.07, 0.05] as const

function smoothstep(edge0: number, edge1: number, value: number): number {
  const t = Math.min(1, Math.max(0, (value - edge0) / (edge1 - edge0)))
  return t * t * (3 - 2 * t)
}

/** Attach constant per-vertex emission (rgb) and glass coverage (alpha) for the craft shader. */
function glow(geometry: THREE.BufferGeometry, rgb: readonly [number, number, number], glass = 0): THREE.BufferGeometry {
  const count = geometry.getAttribute('position').count
  const values = new Float32Array(count * 4)
  for (let index = 0; index < count; index += 1) values.set([rgb[0], rgb[1], rgb[2], glass], index * 4)
  geometry.setAttribute('aGlow', new THREE.BufferAttribute(values, 4))
  return geometry
}

function merge(parts: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const merged = mergeGeometries(parts, false)
  for (const part of parts) part.dispose()
  return merged
}

/** Cylinder between two points. */
function strut(from: THREE.Vector3, to: THREE.Vector3, bottomRadius: number, topRadius: number, segments: number): THREE.BufferGeometry {
  const axis = to.clone().sub(from)
  const geometry = new THREE.CylinderGeometry(topRadius, bottomRadius, axis.length(), segments)
  geometry.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), axis.clone().normalize()))
  const middle = from.clone().add(to).multiplyScalar(0.5)
  geometry.translate(middle.x, middle.y, middle.z)
  return geometry
}

function line(from: THREE.Vector2, to: THREE.Vector2, count: number): THREE.Vector2[] {
  return Array.from({ length: count + 1 }, (_, index) => from.clone().lerp(to, index / count))
}

function lift(points: readonly THREE.Vector2[], z: number | ((y: number) => number)): THREE.Vector3[] {
  return points.map(point => new THREE.Vector3(point.x, point.y, typeof z === 'number' ? z : z(point.y)))
}

/**
 * Television tower: three shafts and inclined legs carrying a lower sphere, five small spheres, an upper sphere,
 * a space module, and a stepped spire.
 * @returns the tower in its local frame, 318 m tall before scaling.
 */
export function createPearlTower(): LandmarkModel {
  const height = PEARL_HEIGHT
  const spheres: THREE.BufferGeometry[] = []
  const sphere = (x: number, y: number, z: number, radius: number): void => {
    spheres.push(new THREE.SphereGeometry(radius, 56, 32).translate(x, y, z))
  }
  sphere(0, 63, 0, 17)
  for (let index = 0; index < 5; index += 1) {
    const angle = index * (2 * Math.PI / 3) + Math.PI / 6
    sphere(Math.cos(angle) * 6.2, 94 + index * 14, Math.sin(angle) * 6.2, 4.3)
  }
  sphere(0, 179, 0, 15.3)
  sphere(0, 233, 0, 5.6)
  const shafts: THREE.BufferGeometry[] = []
  for (let index = 0; index < 3; index += 1) {
    const angle = index * (2 * Math.PI / 3) + Math.PI / 6
    const x = Math.cos(angle) * 6.2
    const z = Math.sin(angle) * 6.2
    shafts.push(new THREE.CylinderGeometry(3, 3, 182, 24).translate(x, 91, z))
    const legAngle = angle + Math.PI / 3
    shafts.push(strut(
      new THREE.Vector3(Math.cos(legAngle) * 24, 0, Math.sin(legAngle) * 24),
      new THREE.Vector3(Math.cos(legAngle) * 6, 50, Math.sin(legAngle) * 6),
      2.9, 2.3, 20,
    ))
  }
  shafts.push(new THREE.CylinderGeometry(4.2, 4.6, 54, 28).translate(0, 206, 0))
  const spire: readonly (readonly [number, number, number, number])[] = [
    [238, 262, 2.6, 2.2], [262, 288, 1.6, 1.3], [288, 306, 0.9, 0.6], [306, height, 0.35, 0.08],
  ]
  for (const [bottom, top, bottomRadius, topRadius] of spire) {
    shafts.push(new THREE.CylinderGeometry(topRadius, bottomRadius, top - bottom, 16).translate(0, (bottom + top) / 2, 0))
    shafts.push(new THREE.CylinderGeometry(bottomRadius + 0.6, bottomRadius + 0.6, 0.7, 20).translate(0, bottom + 0.35, 0))
  }
  const lights: ModelLight[] = [{ offset: [0, height + 0.4, 0], color: AVIATION_RED, radius: 0.9, kind: 0, trail: 0 }]
  for (let index = 0; index < 3; index += 1) {
    const angle = index * (2 * Math.PI / 3)
    lights.push({ offset: [Math.cos(angle) * 1.9, 288.6, Math.sin(angle) * 1.9], color: AVIATION_RED, radius: 0.6, kind: 0, trail: 0 })
    lights.push({ offset: [Math.cos(angle) * 3.4, 262.6, Math.sin(angle) * 3.4], color: AVIATION_RED, radius: 0.6, kind: 0, trail: 0 })
  }
  return {
    surfaces: [
      { defines: ['PEARL_SPHERE'], geometry: merge(spheres) },
      { defines: ['PEARL_COLUMN'], geometry: merge(shafts) },
    ],
    outlines: [],
    lights,
  }
}

/**
 * Supertall with a rounded triangular plan that tapers and twists a third of a turn, capped by a crown ring and mast.
 * @returns the tower in its local frame, 400 m tall before scaling.
 */
export function createTwistTower(): LandmarkModel {
  const height = TWIST_HEIGHT
  const { radius } = SPLASH_LANDMARKS.twist
  const levels = 90
  const segments = 132
  const positions: number[] = []
  const indices: number[] = []
  const ring = (level: number): void => {
    const y = level / levels * height
    const plan = radius * (1 - 0.42 * (y / height) ** 1.2)
    for (let segment = 0; segment < segments; segment += 1) {
      const theta = segment / segments * Math.PI * 2
      const reach = plan * (1 + 0.085 * Math.cos(3 * (theta - TWIST_RATE * y)))
      positions.push(Math.cos(theta) * reach, y, Math.sin(theta) * reach)
    }
  }
  for (let level = 0; level <= levels; level += 1) ring(level)
  for (let level = 0; level < levels; level += 1) {
    for (let segment = 0; segment < segments; segment += 1) {
      const a = level * segments + segment
      const b = level * segments + (segment + 1) % segments
      indices.push(a, a + segments, b, b, a + segments, b + segments)
    }
  }
  // The cap repeats the top ring so its edge stays crisp instead of averaging with the walls.
  const capStart = positions.length / 3
  ring(levels)
  const centre = positions.length / 3
  positions.push(0, height, 0)
  for (let segment = 0; segment < segments; segment += 1) indices.push(centre, capStart + (segment + 1) % segments, capStart + segment)
  const body = new THREE.BufferGeometry()
  body.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
  body.setIndex(indices)
  body.computeVertexNormals()
  const top = radius * 0.58
  const crown = Array.from({ length: 97 }, (_, index) => {
    const angle = index / 96 * Math.PI * 2
    return new THREE.Vector3(Math.cos(angle) * (top + 0.6), height - 1.2, Math.sin(angle) * (top + 0.6))
  })
  return {
    surfaces: [
      { defines: ['TWIST'], geometry: body },
      { defines: ['PEARL_COLUMN'], geometry: new THREE.CylinderGeometry(0.25, 1.1, 26, 12).translate(0, height + 13, 0) },
    ],
    outlines: [{ color: [2.0, 0.1, 0.07], radius: 0.5, points: crown }],
    lights: [{ offset: [0, height + 26.4, 0], color: AVIATION_RED, radius: 0.9, kind: 0, trail: 0 }],
  }
}

/**
 * Tapered tower whose depth narrows toward the crown, pierced by a trapezoidal opening; its +Z face is the front.
 * @returns the tower in its local frame, 330 m tall before scaling.
 */
export function createOpenerTower(): LandmarkModel {
  const height = OPENER_HEIGHT
  const depth = 52
  const narrowing = 0.72
  const shape = new THREE.Shape()
  shape.moveTo(-26, 0)
  shape.lineTo(26, 0)
  shape.lineTo(19, height)
  shape.lineTo(-19, height)
  shape.closePath()
  const hole = new THREE.Path()
  hole.moveTo(-15, 268)
  hole.lineTo(15, 268)
  hole.lineTo(12, 302)
  hole.lineTo(-12, 302)
  hole.closePath()
  shape.holes.push(hole)
  const body = new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: false, steps: 1 })
  body.translate(0, 0, -depth / 2)
  const position = body.getAttribute('position')
  for (let index = 0; index < position.count; index += 1) {
    position.setZ(index, position.getZ(index) * (1 - narrowing * position.getY(index) / height))
  }
  body.computeVertexNormals()
  const front = (y: number): number => depth / 2 * (1 - narrowing * y / height) + 0.3
  const opening = [
    ...line(new THREE.Vector2(-15, 268), new THREE.Vector2(15, 268), 20),
    ...line(new THREE.Vector2(15, 268), new THREE.Vector2(12, 302), 16),
    ...line(new THREE.Vector2(12, 302), new THREE.Vector2(-12, 302), 20),
    ...line(new THREE.Vector2(-12, 302), new THREE.Vector2(-15, 268), 16),
  ]
  return {
    surfaces: [{ defines: ['PLANAR'], geometry: body }],
    outlines: [
      { color: [2.1, 0.32, 0.08], radius: 0.45, points: lift(opening, front) },
      { color: [1.6, 0.85, 0.32], radius: 0.3, points: lift(line(new THREE.Vector2(-19, height), new THREE.Vector2(19, height), 30), front) },
    ],
    lights: [
      { offset: [-18, height + 0.6, 0], color: AVIATION_RED, radius: 0.9, kind: 0, trail: 0 },
      { offset: [18, height + 0.6, 0], color: AVIATION_RED, radius: 0.9, kind: 0, trail: 0 },
    ],
  }
}

/**
 * The X plot's towers in world space: rounded elliptical plans lofted upward with their roofs offset, so neighbouring
 * walls lean toward each other. `aFacade` carries arc length around the plan and height for the crystal facade.
 * @param towers - tower plans, heights, and roof offsets.
 * @returns one geometry for every tower, with flat roofs.
 */
export function createLeaningTowers(towers: readonly SplashLeaningTower[]): THREE.BufferGeometry {
  const segments = 72
  const levels = 14
  const positions: number[] = []
  const facade: number[] = []
  const indices: number[] = []
  for (const tower of towers) {
    const cos = Math.cos(tower.yaw)
    const sin = Math.sin(tower.yaw)
    const plan = Array.from({ length: segments + 1 }, (_, segment) => {
      const theta = segment / segments * Math.PI * 2
      // A superellipse reads as the towers' rounded-rectangle plans.
      const px = tower.radiusX * Math.sign(Math.cos(theta)) * Math.abs(Math.cos(theta)) ** 0.77
      const pz = tower.radiusZ * Math.sign(Math.sin(theta)) * Math.abs(Math.sin(theta)) ** 0.77
      return { x: px * cos - pz * sin, z: px * sin + pz * cos }
    })
    const arc = [0]
    for (let segment = 1; segment <= segments; segment += 1) {
      const from = plan[segment - 1] ?? { x: 0, z: 0 }
      const to = plan[segment] ?? { x: 0, z: 0 }
      arc.push((arc[segment - 1] ?? 0) + Math.hypot(to.x - from.x, to.z - from.z))
    }
    const base = positions.length / 3
    for (let level = 0; level <= levels; level += 1) {
      const t = level / levels
      plan.forEach((point, segment) => {
        positions.push(tower.x + point.x + tower.leanX * t, t * tower.height, tower.z + point.z + tower.leanZ * t)
        facade.push(arc[segment] ?? 0, t * tower.height)
      })
    }
    const row = segments + 1
    for (let level = 0; level < levels; level += 1) {
      for (let segment = 0; segment < segments; segment += 1) {
        const a = base + level * row + segment
        indices.push(a, a + row, a + 1, a + 1, a + row, a + row + 1)
      }
    }
    const cap = positions.length / 3
    plan.forEach((point) => {
      positions.push(tower.x + point.x + tower.leanX, tower.height, tower.z + point.z + tower.leanZ)
      facade.push(0, tower.height)
    })
    const centre = positions.length / 3
    positions.push(tower.x + tower.leanX, tower.height, tower.z + tower.leanZ)
    facade.push(0, tower.height)
    for (let segment = 0; segment < segments; segment += 1) indices.push(centre, cap + segment + 1, cap + segment)
  }
  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
  geometry.setAttribute('aFacade', new THREE.Float32BufferAttribute(facade, 2))
  geometry.setIndex(indices)
  geometry.computeVertexNormals()
  return geometry
}

/**
 * The art centre's steel tanks in world space; `aFacade` carries arc length and height for the plate seams.
 * @param tanks - tank centres, radii, and heights.
 * @returns one geometry for every tank, with flat roofs.
 */
export function createTankGeometry(tanks: readonly SplashTank[]): THREE.BufferGeometry {
  return merge(tanks.map((tank) => {
    const geometry = new THREE.CylinderGeometry(tank.radius, tank.radius, tank.height, 56).translate(0, tank.height / 2, 0)
    const position = geometry.getAttribute('position')
    const uv = geometry.getAttribute('uv')
    const facade = new Float32Array(position.count * 2)
    for (let index = 0; index < position.count; index += 1) {
      facade[index * 2] = uv.getX(index) * Math.PI * 2 * tank.radius
      facade[index * 2 + 1] = position.getY(index)
    }
    geometry.setAttribute('aFacade', new THREE.BufferAttribute(facade, 2))
    geometry.deleteAttribute('uv')
    return geometry.translate(tank.x, 0, tank.z)
  }))
}

/**
 * The riverside museum's three channel-glass boxes in world space, turned in a pinwheel.
 * @returns one geometry for every box.
 */
export function createMuseumGeometry(): THREE.BufferGeometry {
  return merge(SPLASH_MUSEUM.map(box => new THREE.BoxGeometry(box.width, SPLASH_MUSEUM_HEIGHT, box.depth)
    .translate(0, SPLASH_MUSEUM_HEIGHT / 2, 0)
    .rotateY(box.yaw)
    .translate(box.x, 0, box.z)))
}

/** Height of the arch rib above the deck at `x`, and its half spacing across the deck, which narrows toward the crown. */
function archAt(x: number): { height: number; half: number } {
  const t = (x - SPLASH_RIVER.west) / (SPLASH_RIVER.east - SPLASH_RIVER.west)
  const rise = Math.max(0, 1 - (2 * t - 1) ** 2)
  return { height: SPLASH_BRIDGE.deck + SPLASH_BRIDGE.rise * rise, half: (SPLASH_BRIDGE.width / 2 - 2) * (1 - 0.35 * rise) }
}

/**
 * The arch bridge across the river in world space: deck, bank piers and approach columns, two inward-leaning arch ribs
 * springing from the banks, crown braces, hangers every 20 m, and deck edge strips.
 * @returns the bridge's parts grouped by material.
 */
export function createBridge(): BridgeModel {
  const { z, deck, width, from, to } = SPLASH_BRIDGE
  const { west, east } = SPLASH_RIVER
  const structure: THREE.BufferGeometry[] = [new THREE.BoxGeometry(to - from, 3.4, width).translate((from + to) / 2, deck - 1.7, z)]
  for (const x of [west - 8, east + 8]) structure.push(new THREE.BoxGeometry(12, deck - 3.4, width + 4).translate(x, (deck - 3.4) / 2, z))
  for (let x = from + 12; x < west - 20; x += 34) structure.push(new THREE.BoxGeometry(3, deck - 3.4, 8).translate(x, (deck - 3.4) / 2, z))
  for (let x = east + 30; x < to - 6; x += 34) structure.push(new THREE.BoxGeometry(3, deck - 3.4, 8).translate(x, (deck - 3.4) / 2, z))
  const ribs: THREE.BufferGeometry[] = []
  for (const side of [-1, 1]) {
    const points = Array.from({ length: 49 }, (_, index) => {
      const x = west + index / 48 * (east - west)
      const arch = archAt(x)
      return new THREE.Vector3(x, arch.height, z + side * arch.half)
    })
    ribs.push(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points), 96, 1.7, 8, false))
  }
  for (const t of [0.3, 0.4, 0.5, 0.6, 0.7]) {
    const x = west + t * (east - west)
    const arch = archAt(x)
    structure.push(new THREE.BoxGeometry(1.2, 1.2, arch.half * 2).translate(x, arch.height, z))
  }
  const hangers: THREE.BufferGeometry[] = []
  for (let x = west + 20; x < east - 10; x += 20) {
    const arch = archAt(x)
    for (const side of [-1, 1]) {
      hangers.push(new THREE.BoxGeometry(0.3, arch.height - deck, 0.3).translate(x, (arch.height + deck) / 2, z + side * arch.half))
    }
  }
  const strips = [-1, 1].map(side =>
    new THREE.BoxGeometry(to - from, 0.3, 0.3).translate((from + to) / 2, deck - 0.5, z + side * width / 2))
  const crown = archAt((west + east) / 2)
  return {
    structure: merge(structure),
    ribs: merge(ribs),
    hangers: merge(hangers),
    strips: merge(strips),
    lights: [-1, 1].map(side => ({
      offset: [(west + east) / 2, crown.height + 2, z + side * crown.half] as const,
      color: AVIATION_RED, radius: 0.9, kind: 0 as const, trail: 0,
    })),
  }
}

/** Trunk height of every park tree; the foliage shader starts the crown above it. */
export const TREE_TRUNK_HEIGHT = 3.4

/** A lumpy leaf cluster: an icosphere whose radius swells and dips with smooth noise, with normals of the lumpy surface. */
function leafCluster(radius: number, detail: number, centre: THREE.Vector3, phase: number): THREE.BufferGeometry {
  const sphere = new THREE.IcosahedronGeometry(radius, detail)
  sphere.deleteAttribute('normal')
  sphere.deleteAttribute('uv')
  const cluster = mergeVertices(sphere)
  sphere.dispose()
  const positions = cluster.getAttribute('position')
  const point = new THREE.Vector3()
  for (let index = 0; index < positions.count; index += 1) {
    point.fromBufferAttribute(positions, index)
    const lumps = Math.sin(point.x * 1.9 + phase) * Math.sin(point.y * 1.6 + phase * 1.7) * Math.sin(point.z * 2.1 + phase * 2.3)
    point.multiplyScalar(1 + 0.2 * lumps).add(centre)
    positions.setXYZ(index, point.x, point.y, point.z)
  }
  cluster.computeVertexNormals()
  return cluster.toNonIndexed()
}

/**
 * A London plane tree, the riverside's street tree: a trunk forking into four limbs under a crown of six lumpy leaf
 * clusters.
 * @param random - seeded generator that varies the limbs and the crown between variants.
 * @returns geometry for instancing, base at y = 0, about 8 m tall.
 */
export function createTreeGeometry(random: () => number): THREE.BufferGeometry {
  const parts = [new THREE.CylinderGeometry(0.19, 0.3, TREE_TRUNK_HEIGHT, 10).translate(0, TREE_TRUNK_HEIGHT / 2, 0)]
  for (let limb = 0; limb < 4; limb += 1) {
    const length = 2.2 + random() * 0.8
    parts.push(new THREE.CylinderGeometry(0.06, 0.13, length, 6)
      .translate(0, length / 2, 0)
      .rotateZ(0.45 + random() * 0.3)
      .rotateY((limb + random() * 0.6) / 4 * Math.PI * 2)
      .translate(0, TREE_TRUNK_HEIGHT - 0.3, 0))
  }
  const crown = parts.map(part => {
    part.deleteAttribute('uv')
    return part.toNonIndexed()
  })
  for (const part of parts) part.dispose()
  crown.push(leafCluster(2.3, 2, new THREE.Vector3(0, 6.1, 0), random() * 6))
  for (let index = 0; index < 5; index += 1) {
    const angle = (index + random() * 0.5) / 5 * Math.PI * 2
    const reach = 1.7 + random() * 0.5
    const centre = new THREE.Vector3(Math.cos(angle) * reach, 4.8 + random() * 1.3, Math.sin(angle) * reach)
    crown.push(leafCluster(1.35 + random() * 0.45, index < 2 ? 2 : 1, centre, random() * 6))
  }
  return merge(crown)
}

/** Spinner lights: headlights, tail bar, thruster glows, and the hover glow beneath the hull. */
export const SPINNER_LIGHTS: readonly ModelLight[] = [
  { offset: [-0.5, -0.02, 2.25], color: [1.5, 1.45, 1.35], radius: 0.17, kind: 1, trail: 0.3 },
  { offset: [0.5, -0.02, 2.25], color: [1.5, 1.45, 1.35], radius: 0.17, kind: 1, trail: 0.3 },
  { offset: [0, 0.12, -2.26], color: [1.6, 0.06, 0.04], radius: 0.2, kind: 2, trail: 1.1 },
  { offset: [-1.12, -0.06, -1.76], color: [1.6, 0.6, 0.14], radius: 0.28, kind: 2, trail: 0.9 },
  { offset: [1.12, -0.06, -1.76], color: [1.6, 0.6, 0.14], radius: 0.28, kind: 2, trail: 0.9 },
  { offset: [0, -0.6, -0.5], color: [0.55, 0.24, 0.07], radius: 1.3, kind: 0, trail: 0 },
]

/** Hauler lights: headlights, amber corner markers, tail lights, and the thruster glow beneath the container. */
export const HAULER_LIGHTS: readonly ModelLight[] = [
  { offset: [-1.1, -0.3, 5.4], color: [1.6, 1.5, 1.35], radius: 0.24, kind: 1, trail: 0.4 },
  { offset: [1.1, -0.3, 5.4], color: [1.6, 1.5, 1.35], radius: 0.24, kind: 1, trail: 0.4 },
  { offset: [-1.85, 1.3, 4.8], color: [1.5, 0.7, 0.1], radius: 0.2, kind: 0, trail: 0 },
  { offset: [1.85, 1.3, 4.8], color: [1.5, 0.7, 0.1], radius: 0.2, kind: 0, trail: 0 },
  { offset: [-1.85, 1.3, -5.0], color: [1.5, 0.7, 0.1], radius: 0.2, kind: 0, trail: 0 },
  { offset: [1.85, 1.3, -5.0], color: [1.5, 0.7, 0.1], radius: 0.2, kind: 0, trail: 0 },
  { offset: [-1.4, 0.4, -5.1], color: [1.6, 0.06, 0.04], radius: 0.24, kind: 2, trail: 0.8 },
  { offset: [1.4, 0.4, -5.1], color: [1.6, 0.06, 0.04], radius: 0.24, kind: 2, trail: 0.8 },
  { offset: [0, -2.0, -1.2], color: [0.7, 0.28, 0.06], radius: 1.6, kind: 0, trail: 0 },
]

/** Cruise boat lights: masthead, port and starboard sidelights, and the stern light. */
export const BOAT_LIGHTS: readonly ModelLight[] = [
  { offset: [0, 12.4, 6], color: [1.5, 1.45, 1.35], radius: 0.35, kind: 0, trail: 0 },
  { offset: [-4.6, 2.8, 19], color: [1.6, 0.07, 0.05], radius: 0.3, kind: 1, trail: 0 },
  { offset: [4.6, 2.8, 19], color: [0.1, 1.4, 0.5], radius: 0.3, kind: 1, trail: 0 },
  { offset: [0, 3.2, -23.2], color: [1.4, 1.35, 1.25], radius: 0.3, kind: 2, trail: 0 },
]

/**
 * Two-seat spinner: a wedge hull with a drooping nose, glass canopy, twin thruster pods, and tail fins; +Z forward.
 * @returns geometry carrying `aGlow`.
 */
export function createSpinnerGeometry(): THREE.BufferGeometry {
  const hull = new THREE.BoxGeometry(1.9, 0.62, 4.4, 4, 2, 10)
  const position = hull.getAttribute('position')
  for (let index = 0; index < position.count; index += 1) {
    const x = position.getX(index)
    const y = position.getY(index)
    const z = position.getZ(index)
    const along = (z + 2.2) / 4.4
    const nose = smoothstep(0.55, 1, along)
    const tail = smoothstep(0.25, 0, along)
    position.setX(index, x * (1 - 0.42 * nose - 0.12 * tail))
    position.setY(index, (y > 0 ? y * (1 - 0.55 * nose) : y * (1 - 0.3 * nose)) - 0.05 * nose)
  }
  hull.computeVertexNormals()
  const parts = [glow(hull, [0, 0, 0])]
  const canopy = new THREE.SphereGeometry(1, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2).scale(0.62, 0.36, 1.25).translate(0, 0.27, 0.25)
  parts.push(glow(canopy, [0.02, 0.012, 0.008], 1))
  for (const side of [-1, 1]) {
    parts.push(glow(new THREE.CylinderGeometry(0.33, 0.29, 1.7, 16).rotateX(Math.PI / 2).translate(side * 1.12, -0.06, -0.8), [0, 0, 0]))
    const nozzle = new THREE.CylinderGeometry(0.27, 0.27, 0.05, 16).rotateX(Math.PI / 2).translate(side * 1.12, -0.06, -1.66)
    parts.push(glow(nozzle, [2.4, 0.9, 0.25]))
    parts.push(glow(new THREE.BoxGeometry(0.5, 0.03, 1.2).translate(side * 1.12, -0.37, -0.8), [1.0, 0.42, 0.12]))
    parts.push(glow(new THREE.BoxGeometry(0.42, 0.07, 0.05).translate(side * 0.5, -0.02, 2.17), [3.0, 2.9, 2.7]))
    parts.push(glow(new THREE.BoxGeometry(0.06, 0.5, 0.7).rotateZ(side * 0.35).translate(side * 0.45, 0.45, -1.8), [0, 0, 0]))
  }
  parts.push(glow(new THREE.BoxGeometry(1.4, 0.06, 0.04).translate(0, 0.12, -2.21), [2.8, 0.12, 0.08]))
  return merge(parts)
}

/**
 * Cargo hauler: a cab ahead of a ribbed container slung on four downward thrusters; +Z forward.
 * @returns geometry carrying `aGlow`.
 */
export function createHaulerGeometry(): THREE.BufferGeometry {
  const parts = [
    glow(new THREE.BoxGeometry(3.4, 2.0, 2.6).translate(0, 0.1, 4.0), [0, 0, 0]),
    glow(new THREE.BoxGeometry(3.0, 0.7, 0.05).translate(0, 0.55, 5.32), [0.03, 0.02, 0.012], 1),
    glow(new THREE.BoxGeometry(3.6, 2.6, 7.6).translate(0, 0.2, -1.3), [0, 0, 0]),
  ]
  for (let rib = 0; rib < 7; rib += 1) {
    parts.push(glow(new THREE.BoxGeometry(3.72, 2.7, 0.12).translate(0, 0.2, -4.7 + rib * 1.13), [0, 0, 0]))
  }
  for (const side of [-1, 1]) {
    for (const end of [-1, 1]) {
      parts.push(glow(new THREE.CylinderGeometry(0.5, 0.42, 0.7, 16).translate(side * 1.55, -1.45, -1.3 + end * 3.0), [0, 0, 0]))
      parts.push(glow(new THREE.CylinderGeometry(0.36, 0.36, 0.05, 16).translate(side * 1.55, -1.82, -1.3 + end * 3.0), [2.4, 0.9, 0.2]))
      parts.push(glow(new THREE.BoxGeometry(0.16, 0.16, 0.16).translate(side * 1.85, 1.3, end > 0 ? 4.8 : -5.0), [2.6, 1.3, 0.2]))
    }
    parts.push(glow(new THREE.BoxGeometry(0.6, 0.16, 0.05).translate(side * 1.1, -0.3, 5.32), [3.0, 2.9, 2.7]))
    parts.push(glow(new THREE.BoxGeometry(0.5, 0.18, 0.05).translate(side * 1.4, 0.4, -5.12), [2.8, 0.12, 0.08]))
  }
  return merge(parts)
}

/**
 * Huangpu cruise boat, 46 m long with its waterline at y = 0: a hull with a fine bow, three stepped cabin decks with
 * lit window bands, coloured LED strips along every deck edge, and a mast; +Z forward.
 * @returns geometry carrying `aGlow`.
 */
export function createBoatGeometry(): THREE.BufferGeometry {
  const hull = new THREE.BoxGeometry(10, 3.4, 46, 2, 2, 12).translate(0, 0.5, 0)
  const position = hull.getAttribute('position')
  for (let index = 0; index < position.count; index += 1) {
    const along = (position.getZ(index) + 23) / 46
    position.setX(index, position.getX(index) * (1 - 0.82 * smoothstep(0.72, 1, along) - 0.1 * smoothstep(0.08, 0, along)))
  }
  hull.computeVertexNormals()
  const parts = [glow(hull, [0, 0, 0])]
  const decks = [
    { width: 8.8, height: 2.6, depth: 34, base: 2.2, z: -2, led: [2.0, 0.22, 0.12] },
    { width: 7.6, height: 2.4, depth: 26, base: 4.8, z: -4, led: [2.0, 0.95, 0.32] },
    { width: 5.8, height: 2.0, depth: 15, base: 7.2, z: -6, led: [2.0, 1.3, 0.6] },
  ] as const
  for (const deck of decks) {
    const cabin = new THREE.BoxGeometry(deck.width, deck.height, deck.depth)
    parts.push(glow(cabin.translate(0, deck.base + deck.height / 2, deck.z), [0, 0, 0]))
    for (const side of [-1, 1]) {
      const band = new THREE.BoxGeometry(0.05, deck.height * 0.45, deck.depth * 0.88)
      parts.push(glow(band.translate(side * (deck.width / 2 + 0.03), deck.base + deck.height * 0.56, deck.z), [1.4, 1.0, 0.6]))
      const edge = new THREE.BoxGeometry(0.12, 0.12, deck.depth)
      parts.push(glow(edge.translate(side * deck.width / 2, deck.base + deck.height, deck.z), deck.led))
    }
    for (const end of [-1, 1]) {
      const edge = new THREE.BoxGeometry(deck.width, 0.12, 0.12)
      parts.push(glow(edge.translate(0, deck.base + deck.height, deck.z + end * deck.depth / 2), deck.led))
    }
  }
  parts.push(glow(new THREE.CylinderGeometry(0.12, 0.18, 3.2, 8).translate(0, 10.8, 6), [0, 0, 0]))
  return merge(parts)
}

/** Airship lights: fin-tip navigation lights and the gondola's downlight; local frame with the hull along X. */
export const BLIMP_LIGHTS: readonly ModelLight[] = [
  { offset: [-10.6, 4.2, 0], color: [1.6, 0.07, 0.05], radius: 0.4, kind: 0, trail: 0 },
  { offset: [-10.6, -4.2, 0], color: [1.4, 1.4, 1.3], radius: 0.35, kind: 0, trail: 0 },
  { offset: [-10.6, 0, 4.2], color: [0.1, 1.2, 0.8], radius: 0.35, kind: 0, trail: 0 },
  { offset: [-10.6, 0, -4.2], color: [1.6, 0.07, 0.05], radius: 0.35, kind: 0, trail: 0 },
  { offset: [11.9, 0, 0], color: [1.4, 1.4, 1.3], radius: 0.35, kind: 0, trail: 0 },
  { offset: [0, -6.0, 0], color: [1.0, 0.7, 0.45], radius: 0.9, kind: 0, trail: 0 },
]

/** Placement of the airship's advertising screen relative to its centre: +Z side, facing +Z. */
export const BLIMP_SCREEN = { y: 0.4, z: 4.9, width: 13, height: 4.4 } as const

/**
 * Advertising airship along X: an ellipsoid hull, cruciform tail fins, a lit gondola, and the screen's mounting frame.
 * @param length - hull length in metres.
 * @param radius - hull radius in metres.
 * @returns geometry carrying `aGlow`.
 */
export function createBlimpGeometry(length: number, radius: number): THREE.BufferGeometry {
  const half = length / 2
  const parts = [glow(new THREE.SphereGeometry(1, 48, 24).scale(half, radius, radius), [0, 0, 0])]
  const fin = radius * 0.55
  const fins = [[fin, 0, 0.16, 3.4], [-fin, 0, 0.16, 3.4], [0, fin, 3.4, 0.16], [0, -fin, 3.4, 0.16]] as const
  for (const [y, z, width, height] of fins) {
    parts.push(glow(new THREE.BoxGeometry(2.8, height, width).translate(-half + 1.6, y, z), [0, 0, 0]))
  }
  parts.push(glow(new THREE.BoxGeometry(5.2, 1.4, 2.0).translate(0, -radius - 0.55, 0), [0, 0, 0]))
  parts.push(glow(new THREE.BoxGeometry(4.6, 0.42, 2.06).translate(0, -radius - 0.4, 0), [1.4, 0.95, 0.55]))
  const frame = new THREE.BoxGeometry(BLIMP_SCREEN.width + 0.5, BLIMP_SCREEN.height + 0.5, 0.3)
  parts.push(glow(frame.translate(0, BLIMP_SCREEN.y, BLIMP_SCREEN.z - 0.2), [0, 0, 0]))
  parts.push(glow(new THREE.BoxGeometry(0.3, 0.3, 1.6).translate(-4, BLIMP_SCREEN.y, BLIMP_SCREEN.z - 1.1), [0, 0, 0]))
  parts.push(glow(new THREE.BoxGeometry(0.3, 0.3, 1.6).translate(4, BLIMP_SCREEN.y, BLIMP_SCREEN.z - 1.1), [0, 0, 0]))
  return merge(parts)
}
