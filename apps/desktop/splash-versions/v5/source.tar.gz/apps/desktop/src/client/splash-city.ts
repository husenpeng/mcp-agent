/** Deterministic layout, camera path, and traffic for the WebGL launch city; no DOM or WebGL access. */

/** A point in scene metres. */
export interface SplashVector {
  readonly x: number
  readonly y: number
  readonly z: number
}

/** Facade families resolved by the city shader. */
export const SPLASH_FACADE = { glass: 0, panel: 1, ribbon: 2, hero: 3 } as const

/** One facade family. */
export type SplashFacade = typeof SPLASH_FACADE[keyof typeof SPLASH_FACADE]

/** Steady accent lighting resolved by the city shader. */
export const SPLASH_TRIM = { none: 0, redCorners: 1, cyanCorners: 2, crownBand: 3, floorLines: 4, fins: 5 } as const

/** One accent lighting choice. */
export type SplashTrim = typeof SPLASH_TRIM[keyof typeof SPLASH_TRIM]

/** Tier footprints: rectangular boxes or circular, optionally tapering cylinders. */
export const SPLASH_FORM = { box: 0, round: 1 } as const

/** One tier footprint. */
export type SplashForm = typeof SPLASH_FORM[keyof typeof SPLASH_FORM]

/** Axis-aligned box: centre `x`/`z`, base height `y`, and extents in metres. */
export interface SplashBox {
  readonly x: number
  readonly y: number
  readonly z: number
  readonly width: number
  readonly height: number
  readonly depth: number
}

/** One building tier and the facade parameters the city shader reads. */
export interface SplashTier extends SplashBox {
  /** Stable per-building hash input in [0, 1). */
  readonly seed: number
  readonly facade: SplashFacade
  /** Share of rooms with their lights on, in [0, 1]. */
  readonly lit: number
  readonly trim: SplashTrim
  /** Shop fronts occupy the street-level band facing the avenue; only box tiers carry them. */
  readonly storefront: boolean
  readonly form: SplashForm
  /** Top-to-base footprint ratio; box tiers keep 1. */
  readonly taper: number
}

/** Vertical neon blade sign projecting over the avenue; its artwork faces +Z. */
export interface SplashSign {
  readonly x: number
  /** Height of the sign's lower edge. */
  readonly y: number
  readonly z: number
  readonly width: number
  readonly height: number
  /** Artwork slot in the sign atlas, below `SPLASH_SIGN_SLOTS`. */
  readonly slot: number
}

/** Advertising screen centred on `x`/`y`/`z`; `yaw` turns its +Z face around the vertical axis. */
export interface SplashScreen {
  readonly x: number
  readonly y: number
  readonly z: number
  readonly width: number
  readonly height: number
  readonly yaw: number
  /** Artwork slot in the screen atlas, below `SPLASH_SCREEN_SLOTS`. */
  readonly slot: number
}

/** Roof mast or spire standing on `y`, tapering to a steady obstruction light at its tip. */
export interface SplashAntenna {
  readonly x: number
  readonly y: number
  readonly z: number
  readonly height: number
  /** Base radius in metres. */
  readonly radius: number
}

/** The complete deterministic city. */
export interface SplashCityLayout {
  readonly tiers: readonly SplashTier[]
  readonly roofUnits: readonly SplashBox[]
  readonly antennas: readonly SplashAntenna[]
  readonly signs: readonly SplashSign[]
  readonly screens: readonly SplashScreen[]
}

/** Camera position, look-at target, and vertical field of view in degrees. */
export interface SplashCameraPose {
  readonly position: SplashVector
  readonly target: SplashVector
  readonly fov: number
}

/** A straight loop that craft and their lights follow. */
export interface SplashLane {
  /** Lane anchor; craft loop within `span / 2` metres of it along the travel direction. */
  readonly origin: SplashVector
  /** Unit horizontal travel direction. */
  readonly directionX: number
  readonly directionZ: number
  /** Metres per second; every craft on one lane shares it, so craft never overtake. */
  readonly speed: number
  /** Initial offset along the loop, in metres. */
  readonly phase: number
  /** Loop length in metres. */
  readonly span: number
  /** Phase of the slow vertical hover, in radians. */
  readonly bob: number
}

/** Modelled craft kinds. */
export const SPLASH_CRAFT = { spinner: 0, hauler: 1 } as const

/** One modelled craft kind. */
export type SplashCraftKind = typeof SPLASH_CRAFT[keyof typeof SPLASH_CRAFT]

/** A modelled flying craft. */
export interface SplashFlyer extends SplashLane {
  readonly kind: SplashCraftKind
  /** Linear paint albedo. */
  readonly paint: readonly [number, number, number]
}

/** A distant light-only craft. */
export interface SplashVehicle extends SplashLane {
  /** Trail length behind the light, in metres. */
  readonly trail: number
  /** Light radius in metres. */
  readonly radius: number
  /** Headlights face the viewer's end of the lane; tail lights face away. */
  readonly headlight: boolean
}

/** Artwork slots drawn into the blade-sign atlas. */
export const SPLASH_SIGN_SLOTS = 8

/** Artwork slots drawn into the screen atlas. */
export const SPLASH_SCREEN_SLOTS = 4

/** Distance from the avenue centreline to the first building line. */
export const SPLASH_AVENUE_FRONTAGE = 17

/** Avenue extent along Z; the landmark plaza begins past `end`. */
export const SPLASH_AVENUE = { start: 175, end: -205 } as const

/** Street lamps stand at ±`x` every `spacing` metres along the avenue. */
export const SPLASH_LAMPS = { x: 12.4, spacing: 26, height: 9.5 } as const

/** Landmark tower closing the avenue; `deck` is the crown deck height the projector stands on. */
export const SPLASH_TOWER = { x: 0, z: -238, deck: 150 } as const

/** Centre and width of the projected Tomato mark above the landmark tower. */
export const SPLASH_MARK = { x: 0, y: 186, z: -238, width: 48 } as const

/** Cross streets along X; the frontage, second row, and districts leave each corridor clear for traffic and the maglev. */
export const SPLASH_CROSS_STREETS = { north: 71, south: -113, rail: -159 } as const

/** Half-width of every cross-street corridor. */
export const SPLASH_CROSS_STREET_HALF_WIDTH = 6

/** Air-lane heights above the avenue; skybridges and the airship keep clear of them. */
export const SPLASH_AIR_LANES = [28, 72, 104] as const

/** Air-lane offsets from the avenue centreline: inbound craft fly at −X, outbound at +X. */
export const SPLASH_AIR_LANE_X = 10.5

/** Advertising airship hovering over the avenue below the camera's crane path and between air lanes. */
export const SPLASH_BLIMP = { x: 0, y: 50, z: -60, length: 24, radius: 4.6 } as const

/** Elevated maglev along the rail cross street: guideway height, train make-up, speed, and loop length. */
export const SPLASH_MAGLEV = { z: SPLASH_CROSS_STREETS.rail, height: 30, cars: 5, carLength: 17, gap: 1.2, speed: 32, span: 1100 } as const

/** Landmark towers around the plaza; districts keep each `clearance` radius free and every `view` corridor low. */
export const SPLASH_LANDMARKS = {
  /** Television tower of stacked glass spheres on three shafts. */
  pearl: { x: 160, z: -430, height: 318, clearance: 34, view: { from: 40, halfAngle: 0.1 } },
  /** Gate-shaped twin tower joined below its crown. */
  gate: { x: -146, z: -450, height: 250, clearance: 62, view: { from: 85, halfAngle: 0.16 } },
  /** Supertall with a rounded triangular plan twisting a third of a turn. */
  twist: { x: 136, z: -710, height: 400, radius: 30, clearance: 42, view: { from: 110, halfAngle: 0.08 } },
  /** Tapered tower with a trapezoidal opening below its crown. */
  opener: { x: -150, z: -760, height: 330, clearance: 46, view: { from: 140, halfAngle: 0.08 } },
} as const

/** Buildings past this Z and within `VISTA_RADIUS` of the resting camera stay below it, opening its view to the skyline. */
const VISTA_START_Z = -45
const VISTA_RADIUS = 150
const VISTA_HEIGHT = 136

interface CameraKey extends SplashCameraPose {
  /** Share of the camera move, in [0, 1]. */
  readonly at: number
}

/** Street-level glide, upward crane, and the resting composition with the mark in the upper third. */
const CAMERA_KEYS: readonly CameraKey[] = [
  { at: 0, position: { x: 0, y: 5.2, z: 130 }, target: { x: 0, y: 17, z: 20 }, fov: 62 },
  { at: 0.3, position: { x: 0.4, y: 8.5, z: 62 }, target: { x: 0, y: 40, z: -110 }, fov: 58 },
  { at: 0.54, position: { x: -0.5, y: 36, z: 14 }, target: { x: 0, y: 104, z: -210 }, fov: 52 },
  { at: 0.78, position: { x: 0.3, y: 116, z: -38 }, target: { x: 0, y: 150, z: -238 }, fov: 44 },
  { at: 1, position: { x: 0, y: 152, z: -70 }, target: { x: 0, y: 157, z: -238 }, fov: 40 },
]

function createRandom(seed: number): () => number {
  let state = seed | 0
  return () => {
    state = (state + 0x6d2b79f5) | 0
    let value = Math.imul(state ^ (state >>> 15), 1 | state)
    value = (value + Math.imul(value ^ (value >>> 7), 61 | value)) ^ value
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296
  }
}

/** Fisher-Yates shuffle in place. */
function shuffle(items: unknown[], random: () => number): void {
  for (let index = items.length - 1; index > 0; index -= 1) {
    const swap = Math.floor(random() * (index + 1))
    const item: unknown = items[index]
    items[index] = items[swap]
    items[swap] = item
  }
}

/** Cubic Hermite blend of one scalar between two keys. */
function hermite(from: number, to: number, fromSlope: number, toSlope: number, span: number, t: number): number {
  const t2 = t * t
  const t3 = t2 * t
  return (2 * t3 - 3 * t2 + 1) * from + (t3 - 2 * t2 + t) * span * fromSlope
    + (-2 * t3 + 3 * t2) * to + (t3 - t2) * span * toSlope
}

/** Catmull-Rom slope at key `index`; the first key keeps its travel speed and the last key comes to rest. */
function keySlope(read: (key: CameraKey) => number, index: number): number {
  const last = CAMERA_KEYS.length - 1
  if (index >= last) return 0
  const before = CAMERA_KEYS[Math.max(0, index - 1)]
  const after = CAMERA_KEYS[index + 1]
  if (before === undefined || after === undefined) return 0
  return (read(after) - read(before)) / (after.at - before.at)
}

/**
 * Sample the continuous crane shot.
 * @param progress - share of the camera move; values outside [0, 1] clamp to the first or resting pose.
 * @returns the camera pose at that point of the move.
 */
export function splashCameraAt(progress: number): SplashCameraPose {
  const at = Math.min(1, Math.max(0, progress))
  let index = 0
  while (index < CAMERA_KEYS.length - 2 && (CAMERA_KEYS[index + 1]?.at ?? 1) < at) index += 1
  const from = CAMERA_KEYS[index]
  const to = CAMERA_KEYS[index + 1]
  if (from === undefined || to === undefined) throw new Error('splash: camera keys are incomplete')
  const span = to.at - from.at
  const t = (at - from.at) / span
  const blend = (read: (key: CameraKey) => number): number =>
    hermite(read(from), read(to), keySlope(read, index), keySlope(read, index + 1), span, t)
  return {
    position: { x: blend(key => key.position.x), y: blend(key => key.position.y), z: blend(key => key.position.z) },
    target: { x: blend(key => key.target.x), y: blend(key => key.target.y), z: blend(key => key.target.z) },
    fov: blend(key => key.fov),
  }
}

/**
 * Eased share of a timeline phase.
 * @param elapsedMs - milliseconds since the timeline started.
 * @param startMs - phase start in milliseconds.
 * @param durationMs - phase length in milliseconds.
 * @returns 0 before the phase, 1 after it, and a smoothstep-eased value between.
 */
export function splashPhase(elapsedMs: number, startMs: number, durationMs: number): number {
  const value = Math.min(1, Math.max(0, (elapsedMs - startMs) / durationMs))
  return value * value * (3 - 2 * value)
}

/**
 * Centre of the maglev train along X.
 * @param seconds - seconds since the timeline started; the train is centred on the avenue at 1.6 s.
 * @returns the centre X, looping within `±SPLASH_MAGLEV.span / 2`.
 */
export function splashTrainX(seconds: number): number {
  const { speed, span } = SPLASH_MAGLEV
  return ((((seconds - 1.6) * speed + span / 2) % span) + span) % span - span / 2
}

/** Lowest camera height while the camera crosses `z`, or undefined where the camera never travels. */
function cameraHeightNear(z: number): number | undefined {
  let height: number | undefined
  for (let step = 0; step <= 400; step += 1) {
    const pose = splashCameraAt(step / 400)
    if (Math.abs(pose.position.z - z) > 6) continue
    height = Math.min(height ?? Infinity, pose.position.y)
  }
  return height
}

/** Centre of the first cross-street corridor overlapping the Z span from `top` down to `bottom`. */
function corridorWithin(top: number, bottom: number): number | undefined {
  return Object.values(SPLASH_CROSS_STREETS).find(centre =>
    centre + SPLASH_CROSS_STREET_HALF_WIDTH > bottom && centre - SPLASH_CROSS_STREET_HALF_WIDTH < top)
}

/** Whether a footprint centred on `x`/`z` with radius `reach` enters a landmark's clearance. */
function nearLandmark(x: number, z: number, reach: number): boolean {
  return Object.values(SPLASH_LANDMARKS).some(landmark => Math.hypot(x - landmark.x, z - landmark.z) < landmark.clearance + reach)
}

/**
 * Tallest height a building may reach without hiding a landmark from the resting camera: inside a landmark's view
 * corridor, and nearer than it, the building stays below the sightline to the landmark's `view.from` height; the limit
 * relaxes over 0.06 rad past the corridor edge.
 */
function sightlineCeiling(x: number, z: number, reach: number): number {
  const camera = splashCameraAt(1).position
  const distance = Math.hypot(x - camera.x, z - camera.z)
  const bearing = Math.atan2(x - camera.x, camera.z - z)
  let ceiling = Infinity
  for (const landmark of Object.values(SPLASH_LANDMARKS)) {
    const span = Math.hypot(landmark.x - camera.x, landmark.z - camera.z)
    if (distance + reach >= span) continue
    const offset = Math.abs(bearing - Math.atan2(landmark.x - camera.x, camera.z - landmark.z)) - Math.atan2(reach, distance)
    const relax = Math.min(1, Math.max(0, (offset - landmark.view.halfAngle) / 0.06))
    if (relax >= 1) continue
    const sightline = camera.y + (landmark.view.from - camera.y) * (distance + reach) / span
    ceiling = Math.min(ceiling, sightline + relax * relax * 400)
  }
  return ceiling
}

/** Height after the vista and sightline limits; never below `floor` metres. */
function limitHeight(height: number, x: number, z: number, reach: number, floor: number): number {
  const camera = splashCameraAt(1).position
  const vista = z < VISTA_START_Z && Math.hypot(x - camera.x, z - camera.z) < VISTA_RADIUS ? VISTA_HEIGHT : Infinity
  return Math.max(floor, Math.min(height, vista, sightlineCeiling(x, z, reach)))
}

interface CityDraft {
  readonly tiers: SplashTier[]
  readonly roofUnits: SplashBox[]
  readonly antennas: SplashAntenna[]
  readonly signs: SplashSign[]
  readonly screens: SplashScreen[]
}

interface Plot {
  readonly x: number
  readonly z: number
  readonly width: number
  readonly depth: number
  readonly height: number
  readonly storefront: boolean
}

function pickFacade(random: () => number): SplashFacade {
  const value = random()
  if (value < 0.46) return SPLASH_FACADE.glass
  if (value < 0.78) return SPLASH_FACADE.panel
  return SPLASH_FACADE.ribbon
}

function pickTrim(random: () => number, round: boolean): SplashTrim {
  const value = random()
  if (round) {
    if (value < 0.3) return SPLASH_TRIM.crownBand
    if (value < 0.55) return SPLASH_TRIM.floorLines
    if (value < 0.7) return SPLASH_TRIM.fins
    return SPLASH_TRIM.none
  }
  if (value < 0.05) return SPLASH_TRIM.redCorners
  if (value < 0.09) return SPLASH_TRIM.cyanCorners
  if (value < 0.18) return SPLASH_TRIM.crownBand
  if (value < 0.25) return SPLASH_TRIM.floorLines
  if (value < 0.3) return SPLASH_TRIM.fins
  return SPLASH_TRIM.none
}

/** Stack a podium, setbacks or a tapering drum, roof plant, and a mast or spire on one plot; returns the tiers it added. */
function addBuilding(city: CityDraft, random: () => number, plot: Plot): SplashTier[] {
  const seed = random()
  const round = !plot.storefront && plot.height > 46 && random() < 0.17
  const facade = round ? (random() < 0.6 ? SPLASH_FACADE.glass : SPLASH_FACADE.ribbon) : pickFacade(random)
  const lit = 0.08 + random() * 0.3
  const trim = pickTrim(random, round)
  const form = round ? SPLASH_FORM.round : SPLASH_FORM.box
  const added: SplashTier[] = []
  let base = 0
  let width = round ? Math.min(plot.width, plot.depth) : plot.width
  let depth = round ? width : plot.depth
  let tierCount = plot.height > 60 ? 2 + Math.floor(random() * 2) : random() < 0.4 ? 2 : 1
  if (round) tierCount = Math.min(tierCount, 2)
  if (!round && tierCount > 1 && random() < 0.55) {
    const podium = Math.min(plot.height * 0.4, 9 + random() * 10)
    added.push({
      x: plot.x, y: 0, z: plot.z, width, depth, height: podium, seed, facade: SPLASH_FACADE.panel,
      lit: Math.min(1, lit + 0.15), trim: SPLASH_TRIM.none, storefront: plot.storefront, form, taper: 1,
    })
    base = podium
    width *= 0.7 + random() * 0.18
    depth *= 0.7 + random() * 0.18
    tierCount -= 1
  }
  for (let tier = 0; tier < tierCount; tier += 1) {
    const remaining = plot.height - base
    const last = tier === tierCount - 1
    const height = last ? remaining : remaining * (0.58 + random() * 0.2)
    const taper = round ? 0.84 + random() * 0.16 : 1
    added.push({
      x: plot.x, y: base, z: plot.z, width, depth, height, seed, facade, lit,
      trim: last ? trim : SPLASH_TRIM.none, storefront: plot.storefront && base === 0, form, taper,
    })
    base += height
    const shrink = round ? taper * (0.82 + random() * 0.1) : 0.72 + random() * 0.16
    width *= shrink
    depth = round ? width : depth * (0.72 + random() * 0.16)
  }
  const top = added.at(-1)
  if (top === undefined) return added
  const roof = top.y + top.height
  const topWidth = top.width * top.taper
  const topDepth = top.depth * top.taper
  if (round && random() < 0.45) {
    city.antennas.push({ x: top.x, y: roof, z: top.z, height: plot.height * (0.12 + random() * 0.1), radius: topWidth * 0.12 })
  } else {
    const units = 1 + Math.floor(random() * 3)
    for (let unit = 0; unit < units; unit += 1) {
      const unitWidth = 1.6 + random() * Math.min(5, topWidth * 0.3)
      const unitDepth = 1.6 + random() * Math.min(5, topDepth * 0.3)
      const spread = round ? 0.5 : 1
      city.roofUnits.push({
        x: top.x + (random() - 0.5) * (topWidth - unitWidth - 1.5) * spread,
        y: roof,
        z: top.z + (random() - 0.5) * (topDepth - unitDepth - 1.5) * spread,
        width: unitWidth,
        height: 1.2 + random() * 2.4,
        depth: unitDepth,
      })
    }
    if (plot.height > 70 && random() < 0.55) {
      const spire = !round && plot.height > 110 && random() < 0.35
      city.antennas.push({
        x: top.x + (spire ? 0 : (random() - 0.5) * topWidth * 0.5),
        y: roof,
        z: top.z + (spire ? 0 : (random() - 0.5) * topDepth * 0.5),
        height: spire ? 18 + random() * 22 : 7 + random() * 16,
        radius: spire ? Math.min(topWidth, topDepth) * 0.09 : 0.22,
      })
    }
  }
  city.tiers.push(...added)
  return added
}

/** Shorten a run of buildings so it stops before a corridor; returns the usable length, or undefined to jump past it. */
function fitBeforeCorridor(z: number, length: number): { length: number } | { skipTo: number } {
  const corridor = corridorWithin(z, z - length)
  if (corridor === undefined) return { length }
  const clear = corridor + SPLASH_CROSS_STREET_HALF_WIDTH
  if (z - clear < 8) return { skipTo: corridor - SPLASH_CROSS_STREET_HALF_WIDTH - 1 }
  return { length: z - clear - 0.5 }
}

/** Avenue frontage on one side: shop fronts, blade signs, and facade screens facing the camera corridor. */
function addFrontage(city: CityDraft, random: () => number, side: -1 | 1): void {
  let z: number = SPLASH_AVENUE.start
  while (z > SPLASH_AVENUE.end + 12) {
    const fit = fitBeforeCorridor(z, Math.min(z - SPLASH_AVENUE.end, 14 + random() * 13))
    if ('skipTo' in fit) {
      z = fit.skipTo
      continue
    }
    const length = fit.length
    const centreZ = z - length / 2
    const width = 15 + random() * 13
    const setback = random() * 2.2
    const face = SPLASH_AVENUE_FRONTAGE + setback
    const towerward = Math.max(0, Math.min(1, (40 - centreZ) / 220))
    const x = side * (face + width / 2)
    const height = limitHeight(26 + random() ** 1.5 * 96 + towerward * 46, x, centreZ, Math.max(width, length) / 2, 24)
    const tiers = addBuilding(city, random, {
      x, z: centreZ, width, depth: length, height, storefront: true,
    })
    const street = tiers[0]
    if (street !== undefined && centreZ < 160 && centreZ > -150) {
      const count = random() < 0.8 ? 1 + Math.floor(random() * 2.4) : 0
      for (let index = 0; index < count; index += 1) {
        // Sign artwork slots are 1:4; heights follow widths so glyphs keep their proportions.
        const signWidth = 2.1 + random() * 0.6
        const signHeight = signWidth * (3.7 + random() * 0.5)
        const bottom = 5.5 + random() * Math.max(0, Math.min(34, street.height - signHeight - 7))
        if (bottom + signHeight > street.height - 1) continue
        city.signs.push({
          x: side * (face - signWidth / 2 - 0.35),
          y: bottom,
          z: centreZ + (index - (count - 1) / 2) * Math.min(5, length / Math.max(1, count)) + (random() - 0.5),
          width: signWidth,
          height: signHeight,
          slot: Math.floor(random() * SPLASH_SIGN_SLOTS),
        })
      }
    }
    if (street !== undefined && height > 46 && length > 16 && random() < 0.42 && centreZ < 120) {
      const screenWidth = Math.min(length - 4, 11 + random() * 9)
      const screenHeight = screenWidth * (0.5 + random() * 0.12)
      const screenY = Math.min(street.height - screenHeight / 2 - 3, 20 + screenHeight / 2 + random() * 26)
      if (screenY - screenHeight / 2 > 12) {
        city.screens.push({
          x: side * (face - 0.45), y: screenY, z: centreZ,
          width: screenWidth, height: screenHeight, yaw: -side * Math.PI / 2,
          slot: Math.floor(random() * SPLASH_SCREEN_SLOTS),
        })
      }
    }
    z -= length + (random() < 0.4 ? 4 + random() * 5 : 1.2)
  }
}

/** Taller second-row towers behind the frontage; some carry rooftop screens facing the camera. */
function addSecondRow(city: CityDraft, random: () => number, side: -1 | 1): void {
  let z = SPLASH_AVENUE.start - 10
  while (z > -300) {
    const fit = fitBeforeCorridor(z, 18 + random() * 14)
    if ('skipTo' in fit) {
      z = fit.skipTo
      continue
    }
    const length = fit.length
    const centreZ = z - length / 2
    const width = 18 + random() * 16
    const towerward = Math.max(0, Math.min(1, (60 - centreZ) / 300))
    const x = side * (44 + random() * 10 + width / 2)
    const height = limitHeight(50 + random() ** 1.3 * 110 + towerward * 60, x, centreZ, Math.max(width, length) / 2, 40)
    const tiers = addBuilding(city, random, {
      x, z: centreZ, width, depth: length, height, storefront: false,
    })
    const top = tiers.at(-1)
    if (top !== undefined && top.form === SPLASH_FORM.box && centreZ < -40 && random() < 0.35) {
      const screenWidth = Math.min(top.width - 2, 12 + random() * 8)
      const screenHeight = screenWidth * 0.48
      city.screens.push({
        x: top.x, y: top.y + top.height + 1.2 + screenHeight / 2, z: top.z + top.depth / 2 - 1,
        width: screenWidth, height: screenHeight, yaw: 0,
        slot: Math.floor(random() * SPLASH_SCREEN_SLOTS),
      })
    }
    z -= length + 3 + random() * 6
  }
}

/** Surrounding districts on a street grid whose gaps carry the cross streets, rising toward the landmark. */
function addDistricts(city: CityDraft, random: () => number): void {
  for (let gridX = -520; gridX <= 520; gridX += 46) {
    for (let gridZ = -780; gridZ <= 200; gridZ += 46) {
      if (Math.abs(gridX) < 96 && gridZ > -320) continue
      if (Math.hypot(gridX - SPLASH_TOWER.x, gridZ - SPLASH_TOWER.z) < 90) continue
      const buildings = 1 + Math.floor(random() * 2.2)
      for (let index = 0; index < buildings; index += 1) {
        const width = 12 + random() * (buildings === 1 ? 20 : 12)
        const depth = 12 + random() * (buildings === 1 ? 20 : 12)
        const x = gridX + (random() - 0.5) * (34 - width)
        const z = gridZ + (random() - 0.5) * (34 - depth)
        if (nearLandmark(x, z, Math.max(width, depth) / 2)) continue
        const toTower = Math.hypot(x - SPLASH_TOWER.x, z - SPLASH_TOWER.z)
        const spike = random() < 0.07 ? 70 + random() * 110 : 0
        const raw = 16 + random() ** 1.8 * 70 + 120 * Math.exp(-((toTower / 300) ** 2)) + spike
        const height = limitHeight(raw, x, z, Math.max(width, depth) / 2, 14)
        addBuilding(city, random, { x, z, width, depth, height, storefront: false })
      }
    }
  }
}

/** Distant megastructures that read as silhouettes through the haze. */
function addMegastructures(city: CityDraft, random: () => number): void {
  for (let index = 0; index < 14; index += 1) {
    const angle = -Math.PI * 0.92 + (index / 13) * Math.PI * 0.84 + (random() - 0.5) * 0.1
    const distance = 720 + random() * 420
    const width = 70 + random() * 70
    addBuilding(city, random, {
      x: SPLASH_TOWER.x + Math.cos(angle) * distance,
      z: SPLASH_TOWER.z + Math.sin(angle) * distance,
      width,
      depth: width * (0.7 + random() * 0.5),
      height: 260 + random() * 240,
      storefront: false,
    })
  }
}

/** The landmark the camera rises toward: a box plaza podium under a tapering drum; the projector deck carries the mark. */
function addLandmark(city: CityDraft): void {
  const { x, z, deck } = SPLASH_TOWER
  const tier = (
    y: number, width: number, height: number, facade: SplashFacade, trim: SplashTrim, form: SplashForm, taper: number,
  ): SplashTier => ({
    x, y, z, width, depth: width, height, seed: 0.618, facade, lit: 0.42, trim, storefront: false, form, taper,
  })
  city.tiers.push(
    tier(0, 72, 22, SPLASH_FACADE.panel, SPLASH_TRIM.crownBand, SPLASH_FORM.box, 1),
    tier(22, 38, 96, SPLASH_FACADE.hero, SPLASH_TRIM.none, SPLASH_FORM.round, 0.9),
    tier(118, 31, 22, SPLASH_FACADE.hero, SPLASH_TRIM.crownBand, SPLASH_FORM.round, 0.9),
    tier(140, 25, deck - 140, SPLASH_FACADE.hero, SPLASH_TRIM.crownBand, SPLASH_FORM.round, 0.96),
  )
}

/** Skybridge bottoms tried in order of preference; each is filtered against the camera, air lanes, and airship. */
const SKYBRIDGE_BOTTOMS = [12, 36, 48, 58, 82, 92, 112, 126, 140] as const
const SKYBRIDGE_THICKNESS = 4.6

/** Skybridges across the avenue where both frontages face each other, clear of the camera, air lanes, airship, signs, and screens. */
function addSkybridges(city: CityDraft, random: () => number): void {
  const street = (side: -1 | 1): SplashTier[] => city.tiers.filter(tier => tier.storefront && Math.sign(tier.x) === side)
  const placed: number[] = []
  for (const left of street(-1)) {
    for (const right of street(1)) {
      const north = Math.min(left.z + left.depth / 2, right.z + right.depth / 2) - 4
      const south = Math.max(left.z - left.depth / 2, right.z - right.depth / 2) + 4
      const z = (north + south) / 2
      if (north - south < 7 || z > splashCameraAt(0).position.z || placed.some(other => Math.abs(other - z) < 26)) continue
      const camera = cameraHeightNear(z)
      const nearBlimp = Math.abs(z - SPLASH_BLIMP.z) < 14
      const candidates = SKYBRIDGE_BOTTOMS.filter((bottom) => {
        const top = bottom + SKYBRIDGE_THICKNESS
        const middle = (bottom + top) / 2
        if (camera !== undefined && !(bottom > camera + 14 || top < camera - 18)) return false
        if (SPLASH_AIR_LANES.some(lane => lane > bottom - 5 && lane < top + 5)) return false
        if (city.signs.some(sign => Math.abs(sign.z - z) < 4.5 && sign.y < top + 1 && sign.y + sign.height > bottom - 1)) return false
        const screened = city.screens.some(screen =>
          Math.abs(screen.z - z) < screen.width / 2 + 3.5 && Math.abs(screen.y - middle) < screen.height / 2 + 3.5)
        if (screened) return false
        const blimpBottom = SPLASH_BLIMP.y - SPLASH_BLIMP.radius - 4
        const blimpTop = SPLASH_BLIMP.y + SPLASH_BLIMP.radius + 4
        return !nearBlimp || top < blimpBottom || bottom > blimpTop
      })
      shuffle(candidates, random)
      for (const bottom of candidates) {
        const top = bottom + SKYBRIDGE_THICKNESS
        // Each end sinks 1.5 m into the nearest tier that spans the bridge's height on that side.
        const ends = ([-1, 1] as const).map((side) => {
          const faces = city.tiers
            .filter(tier => Math.sign(tier.x) === side
              && Math.abs(tier.z - z) < tier.depth / 2 - 3
              && tier.y < bottom && tier.y + tier.height > top + 6)
            .map(tier => Math.abs(tier.x) - tier.width / 2)
          return faces.length === 0 ? undefined : side * (Math.min(...faces) + 1.5)
        })
        const [west, east] = ends
        if (west === undefined || east === undefined || east - west > SPLASH_AVENUE_FRONTAGE * 2 + 10) continue
        placed.push(z)
        city.tiers.push({
          x: (west + east) / 2, y: bottom, z, width: east - west, height: top - bottom, depth: 6.5,
          seed: random(), facade: SPLASH_FACADE.glass, lit: 0.55, trim: SPLASH_TRIM.none, storefront: false,
          form: SPLASH_FORM.box, taper: 1,
        })
        break
      }
    }
  }
}

/**
 * Build the seeded city: avenue frontage with signs and screens, second row, districts, skyline, and the plaza landmark.
 * The landmark plots in `SPLASH_LANDMARKS` and the corridors in `SPLASH_CROSS_STREETS` stay empty.
 * @returns the same layout on every call.
 */
export function splashCityLayout(): SplashCityLayout {
  const random = createRandom(0x70a704)
  const city: CityDraft = { tiers: [], roofUnits: [], antennas: [], signs: [], screens: [] }
  addFrontage(city, random, -1)
  addFrontage(city, random, 1)
  addSecondRow(city, random, -1)
  addSecondRow(city, random, 1)
  addDistricts(city, random)
  addMegastructures(city, random)
  addLandmark(city)
  addSkybridges(city, random)
  return city
}

const SPINNER_PAINTS: readonly (readonly [number, number, number])[] = [
  [0.05, 0.052, 0.06], [0.42, 0.43, 0.45], [0.3, 0.024, 0.028], [0.012, 0.012, 0.014], [0.03, 0.1, 0.18],
]
const HAULER_PAINTS: readonly (readonly [number, number, number])[] = [[0.4, 0.24, 0.04], [0.19, 0.19, 0.2]]

/**
 * Seeded modelled craft: spinners in both directions on every avenue air lane, spinners and haulers on the cross streets.
 * @returns the same craft on every call.
 */
export function splashFlyers(): SplashFlyer[] {
  const random = createRandom(0xf1e5)
  const flyers: SplashFlyer[] = []
  const lane = (
    origin: SplashVector, directionX: number, directionZ: number, count: number, span: number, speed: number, kind: SplashCraftKind,
  ): void => {
    const paints = kind === SPLASH_CRAFT.hauler ? HAULER_PAINTS : SPINNER_PAINTS
    for (let index = 0; index < count; index += 1) {
      flyers.push({
        origin, directionX, directionZ, speed, span, kind,
        phase: (index + 0.15 + random() * 0.6) * span / count,
        bob: random() * Math.PI * 2,
        paint: paints[Math.floor(random() * paints.length)] ?? [0.05, 0.05, 0.05],
      })
    }
  }
  const avenueCentre = (SPLASH_AVENUE.start + SPLASH_AVENUE.end + 30) / 2
  const avenueSpan = SPLASH_AVENUE.start - SPLASH_AVENUE.end + 50
  for (const height of SPLASH_AIR_LANES) {
    lane({ x: -SPLASH_AIR_LANE_X, y: height, z: avenueCentre }, 0, 1, 5, avenueSpan, 22 + random() * 6, SPLASH_CRAFT.spinner)
    lane({ x: SPLASH_AIR_LANE_X, y: height + 2.5, z: avenueCentre }, 0, -1, 5, avenueSpan, 18 + random() * 6, SPLASH_CRAFT.spinner)
  }
  const crossings: readonly (readonly [number, readonly number[], number | undefined])[] = [
    [SPLASH_CROSS_STREETS.north, [58, 94], 40],
    [SPLASH_CROSS_STREETS.south, [66, 98, 130], 46],
    [SPLASH_CROSS_STREETS.rail, [60, 110], undefined],
  ]
  for (const [z, heights, haulerHeight] of crossings) {
    for (const height of heights) {
      lane({ x: 0, y: height, z: z + 2.4 }, 1, 0, 6, 900, 28 + random() * 8, SPLASH_CRAFT.spinner)
      lane({ x: 0, y: height + 3, z: z - 2.4 }, -1, 0, 6, 900, 26 + random() * 8, SPLASH_CRAFT.spinner)
    }
    if (haulerHeight !== undefined) {
      lane({ x: 0, y: haulerHeight, z: z + 2 }, 1, 0, 3, 900, 13, SPLASH_CRAFT.hauler)
      lane({ x: 0, y: haulerHeight + 6, z: z - 2 }, -1, 0, 3, 900, 12, SPLASH_CRAFT.hauler)
    }
  }
  return flyers
}

/**
 * Seeded distant light-only traffic above the outer districts.
 * @returns the same vehicles on every call.
 */
export function splashTraffic(): SplashVehicle[] {
  const random = createRandom(0x5eed)
  const vehicles: SplashVehicle[] = []
  const lane = (origin: SplashVector, directionX: number, directionZ: number, count: number, span: number, headlight: boolean): void => {
    const speed = 30 + random() * 14
    for (let index = 0; index < count; index += 1) {
      vehicles.push({
        origin, directionX, directionZ, speed, span, headlight,
        phase: (index + random() * 0.7) * span / count,
        bob: random() * Math.PI * 2,
        trail: 5 + random() * 6,
        radius: 0.45,
      })
    }
  }
  // Lanes stay outside the landmark plots, and lanes crossing behind the mark fly below or above it in the resting shot.
  for (const [x, height] of [[-260, 150], [-340, 190], [-420, 230], [260, 165], [340, 205], [420, 250]] as const) {
    lane({ x, y: height, z: -300 }, 0, 1, 9, 900, true)
    lane({ x: x + 6, y: height + 4, z: -300 }, 0, -1, 9, 900, false)
  }
  for (const [z, height] of [[-380, 150], [-540, 290], [-660, 330]] as const) {
    lane({ x: 0, y: height, z }, 1, 0, 10, 1100, true)
    lane({ x: 0, y: height + 4, z: z - 6 }, -1, 0, 10, 1100, false)
  }
  return vehicles
}
