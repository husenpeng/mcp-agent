/** Canvas artwork for blade signs and advertising screens; neither shows the Tomato mark before its reveal. */

import * as THREE from 'three'
import { SPLASH_SCREEN_SLOTS, SPLASH_SIGN_SLOTS } from './splash-city.ts'

const CJK_FONT = '"PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Noto Sans CJK SC", sans-serif'
const LATIN_FONT = '"Montserrat", "Segoe UI", "Helvetica Neue", sans-serif'

interface NeonInk {
  readonly glow: string
  readonly core: string
}

const RED: NeonInk = { glow: '#ff2b3a', core: '#ffd9d4' }
const CYAN: NeonInk = { glow: '#29d6ff', core: '#e4fbff' }
const PINK: NeonInk = { glow: '#ff4fa0', core: '#ffe2ef' }
const AMBER: NeonInk = { glow: '#ffae2e', core: '#fff2d8' }
const MINT: NeonInk = { glow: '#3dffd0', core: '#e2fff6' }
const VIOLET: NeonInk = { glow: '#b58cff', core: '#efe6ff' }

/** Vertical sign artwork; `SPLASH_SIGN_SLOTS` entries, one per atlas column. */
const SIGN_ARTWORK: readonly { readonly glyphs: string; readonly ink: NeonInk; readonly caption: string }[] = [
  { glyphs: '夜市', ink: RED, caption: 'NIGHT MARKET' },
  { glyphs: '电子', ink: CYAN, caption: 'CYBER PARTS' },
  { glyphs: '拉面', ink: PINK, caption: 'RAMEN 24H' },
  { glyphs: '数据', ink: AMBER, caption: 'DATA BANK' },
  { glyphs: '霓虹', ink: RED, caption: 'NEON' },
  { glyphs: '网咖', ink: MINT, caption: 'NET CAFE' },
  { glyphs: '酒店', ink: VIOLET, caption: 'HOTEL' },
  { glyphs: '未来', ink: CYAN, caption: 'FUTURE' },
]

const SIGN_SLOT = { width: 256, height: 1024 } as const
const SCREEN_SLOT = { width: 1024, height: 512 } as const

function surface(width: number, height: number): { canvas: HTMLCanvasElement; context: CanvasRenderingContext2D } {
  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const context = canvas.getContext('2d')
  if (context === null) throw new Error('splash: signage canvas is unavailable')
  return { canvas, context }
}

/** Draw a glowing tube: a wide coloured halo under a pale core, so bloom reads it as lit glass. */
function neon(context: CanvasRenderingContext2D, ink: NeonInk, draw: (mode: 'stroke' | 'fill') => void, width: number): void {
  context.save()
  context.shadowColor = ink.glow
  context.shadowBlur = width * 3.2
  context.strokeStyle = ink.glow
  context.lineWidth = width
  context.lineJoin = 'round'
  context.lineCap = 'round'
  draw('stroke')
  context.shadowBlur = width * 1.2
  context.fillStyle = ink.core
  context.strokeStyle = ink.core
  context.lineWidth = width * 0.34
  draw('fill')
  context.restore()
}

function drawSign(context: CanvasRenderingContext2D, left: number, artwork: typeof SIGN_ARTWORK[number]): void {
  const { width, height } = SIGN_SLOT
  const inset = 14
  context.fillStyle = '#07040a'
  context.fillRect(left, 0, width, height)
  const panel = context.createLinearGradient(left, 0, left + width, 0)
  panel.addColorStop(0, '#0d0710')
  panel.addColorStop(0.5, '#160b17')
  panel.addColorStop(1, '#0d0710')
  context.fillStyle = panel
  context.fillRect(left + inset, inset, width - inset * 2, height - inset * 2)
  const frame = inset + 12
  neon(context, artwork.ink, () => { context.strokeRect(left + frame, frame, width - frame * 2, height - frame * 2) }, 7)
  const glyphs = Array.from(artwork.glyphs)
  const size = 168
  const top = 150
  const stepY = (height - 380) / Math.max(1, glyphs.length)
  context.textAlign = 'center'
  context.textBaseline = 'middle'
  context.font = `700 ${size}px ${CJK_FONT}`
  glyphs.forEach((glyph, index) => {
    const y = top + stepY * (index + 0.5)
    neon(context, artwork.ink, (mode) => {
      if (mode === 'stroke') context.strokeText(glyph, left + width / 2, y)
      else context.fillText(glyph, left + width / 2, y)
    }, 9)
  })
  context.save()
  context.translate(left + width / 2, height - 150)
  context.rotate(-Math.PI / 2)
  context.font = `600 34px ${LATIN_FONT}`
  context.fillStyle = artwork.ink.glow
  context.shadowColor = artwork.ink.glow
  context.shadowBlur = 14
  context.fillText(artwork.caption, 0, 0)
  context.restore()
}

/** Paint one screen slot; `index` selects the advertisement. */
function drawScreen(context: CanvasRenderingContext2D, left: number, top: number, index: number): void {
  const { width, height } = SCREEN_SLOT
  context.save()
  context.beginPath()
  context.rect(left, top, width, height)
  context.clip()
  context.translate(left, top)
  context.textBaseline = 'middle'
  if (index === 0) {
    const sky = context.createLinearGradient(0, 0, width, height)
    sky.addColorStop(0, '#3a0326')
    sky.addColorStop(0.55, '#1a0636')
    sky.addColorStop(1, '#03141f')
    context.fillStyle = sky
    context.fillRect(0, 0, width, height)
    for (let ring = 0; ring < 6; ring += 1) {
      context.strokeStyle = `rgba(255, 79, 160, ${0.5 - ring * 0.07})`
      context.lineWidth = 3
      context.beginPath()
      context.arc(780, 250, 70 + ring * 34, 0, Math.PI * 2)
      context.stroke()
    }
    context.font = `800 132px ${CJK_FONT}`
    context.fillStyle = '#fff4fb'
    context.shadowColor = '#ff4fa0'
    context.shadowBlur = 30
    context.fillText('未来已来', 70, 210)
    context.font = `600 40px ${LATIN_FONT}`
    context.fillStyle = '#ff9fd0'
    context.shadowBlur = 12
    context.fillText('THE FUTURE IS ONLINE', 76, 340)
  } else if (index === 1) {
    context.fillStyle = '#01141c'
    context.fillRect(0, 0, width, height)
    for (let line = 0; line < 7; line += 1) {
      context.strokeStyle = `rgba(41, 214, 255, ${0.75 - line * 0.09})`
      context.lineWidth = 3
      context.beginPath()
      for (let x = 0; x <= width; x += 8) {
        const y = 330 + Math.sin(x * 0.012 + line * 0.7) * (40 + line * 9) * Math.sin(x * 0.003 + 0.4)
        if (x === 0) context.moveTo(x, y)
        else context.lineTo(x, y)
      }
      context.stroke()
    }
    context.font = `800 120px ${LATIN_FONT}`
    context.fillStyle = '#e4fbff'
    context.shadowColor = '#29d6ff'
    context.shadowBlur = 28
    context.fillText('AI', 70, 150)
    context.font = `700 96px ${CJK_FONT}`
    context.fillText('智能驱动', 250, 150)
  } else if (index === 2) {
    const warm = context.createLinearGradient(0, 0, 0, height)
    warm.addColorStop(0, '#2b0605')
    warm.addColorStop(1, '#120203')
    context.fillStyle = warm
    context.fillRect(0, 0, width, height)
    for (let bar = 0; bar < 14; bar += 1) {
      const barHeight = 60 + ((bar * 37) % 11) * 22
      context.fillStyle = bar % 3 === 0 ? '#ffae2e' : '#ff3a2b'
      context.globalAlpha = 0.7
      context.fillRect(560 + bar * 30, height - 60 - barHeight, 18, barHeight)
    }
    context.globalAlpha = 1
    context.font = `800 150px ${LATIN_FONT}`
    context.fillStyle = '#fff2d8'
    context.shadowColor = '#ff6a2b'
    context.shadowBlur = 30
    context.fillText('24H', 70, 190)
    context.font = `700 92px ${CJK_FONT}`
    context.fillText('全天营业', 74, 350)
  } else {
    context.fillStyle = '#0a0216'
    context.fillRect(0, 0, width, height)
    context.strokeStyle = 'rgba(255, 79, 160, 0.55)'
    context.lineWidth = 2
    for (let line = 0; line <= 16; line += 1) {
      context.beginPath()
      context.moveTo(width / 2, 250)
      context.lineTo(-400 + line * 115, height)
      context.stroke()
    }
    for (let row = 0; row < 7; row += 1) {
      const y = 250 + (row / 6) ** 2 * (height - 250)
      context.beginPath()
      context.moveTo(0, y)
      context.lineTo(width, y)
      context.stroke()
    }
    context.font = `800 96px ${LATIN_FONT}`
    context.fillStyle = '#e4fbff'
    context.shadowColor = '#29d6ff'
    context.shadowBlur = 26
    context.fillText('NEURAL LINK', 70, 120)
    context.font = `700 64px ${CJK_FONT}`
    context.fillStyle = '#ffd6ea'
    context.shadowColor = '#ff4fa0'
    context.fillText('神经连接 · 即刻上线', 74, 210)
  }
  context.restore()
}

function atlasTexture(canvas: HTMLCanvasElement, anisotropy: number): THREE.CanvasTexture {
  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.anisotropy = anisotropy
  texture.needsUpdate = true
  return texture
}

/**
 * Paint every blade sign into one row of vertical slots.
 * @param anisotropy - anisotropic filtering level for grazing views down the avenue.
 * @returns the atlas texture and its column/row grid.
 */
export function createSignAtlas(anisotropy: number): { texture: THREE.CanvasTexture; grid: THREE.Vector2 } {
  const { canvas, context } = surface(SIGN_SLOT.width * SPLASH_SIGN_SLOTS, SIGN_SLOT.height)
  SIGN_ARTWORK.forEach((artwork, index) => { drawSign(context, index * SIGN_SLOT.width, artwork) })
  return { texture: atlasTexture(canvas, anisotropy), grid: new THREE.Vector2(SPLASH_SIGN_SLOTS, 1) }
}

/**
 * Paint every advertising screen into a two-column grid of slots.
 * @param anisotropy - anisotropic filtering level for grazing views down the avenue.
 * @returns the atlas texture and its column/row grid.
 */
export function createScreenAtlas(anisotropy: number): { texture: THREE.CanvasTexture; grid: THREE.Vector2 } {
  const columns = 2
  const rows = Math.ceil(SPLASH_SCREEN_SLOTS / columns)
  const { canvas, context } = surface(SCREEN_SLOT.width * columns, SCREEN_SLOT.height * rows)
  for (let index = 0; index < SPLASH_SCREEN_SLOTS; index += 1) {
    drawScreen(context, (index % columns) * SCREEN_SLOT.width, Math.floor(index / columns) * SCREEN_SLOT.height, index)
  }
  return { texture: atlasTexture(canvas, anisotropy), grid: new THREE.Vector2(columns, rows) }
}
