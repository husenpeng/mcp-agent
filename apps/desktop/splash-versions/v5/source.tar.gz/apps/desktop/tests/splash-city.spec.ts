import { describe, expect, it } from 'vitest'
import {
  SPLASH_AIR_LANES, SPLASH_AVENUE, SPLASH_AVENUE_FRONTAGE, SPLASH_CRAFT, SPLASH_CROSS_STREET_HALF_WIDTH, SPLASH_CROSS_STREETS,
  SPLASH_FORM, SPLASH_LANDMARKS, SPLASH_MAGLEV, SPLASH_TOWER, splashCameraAt, splashCityLayout, splashFlyers,
  splashPhase, splashTraffic, splashTrainX, type SplashTier,
} from '../src/client/splash-city.ts'

const layout = splashCityLayout()
const spansAvenue = (tier: SplashTier): boolean => Math.abs(tier.x) - tier.width / 2 < SPLASH_AVENUE_FRONTAGE
  && tier.z < SPLASH_AVENUE.start && tier.z > SPLASH_AVENUE.end
const isPlaza = (tier: SplashTier): boolean => tier.x === SPLASH_TOWER.x && tier.z === SPLASH_TOWER.z

describe('splash 3D city layout', () => {
  it('generates the same mixed city on every call', () => {
    expect(splashCityLayout()).toEqual(layout)
    expect(layout.tiers.length).toBeGreaterThan(600)
    expect(layout.tiers.some(tier => tier.form === SPLASH_FORM.round)).toBe(true)
    expect(layout.tiers.some(tier => tier.form === SPLASH_FORM.box && tier.storefront)).toBe(true)
    expect(layout.signs.length).toBeGreaterThan(10)
    expect(layout.screens.length).toBeGreaterThan(4)
    expect(layout.antennas.some(antenna => antenna.radius > 1)).toBe(true)
    for (const tier of layout.tiers) {
      expect(tier.width).toBeGreaterThan(0)
      expect(tier.depth).toBeGreaterThan(0)
      expect(tier.height).toBeGreaterThan(0)
      expect(tier.taper).toBeGreaterThan(0)
      expect(tier.taper).toBeLessThanOrEqual(1)
      if (tier.form === SPLASH_FORM.box) expect(tier.taper).toBe(1)
      else expect(tier.storefront).toBe(false)
    }
  })

  it('keeps the avenue open below its skybridges, and keeps every bridge clear of the air lanes', () => {
    const bridges = layout.tiers.filter(tier => spansAvenue(tier) && !isPlaza(tier))
    expect(bridges.length).toBeGreaterThan(0)
    for (const bridge of bridges) {
      expect(bridge.y).toBeGreaterThan(8)
      for (const lane of SPLASH_AIR_LANES) expect(lane < bridge.y - 4 || lane > bridge.y + bridge.height + 4).toBe(true)
    }
  })

  it('leaves the cross streets and landmark plots empty', () => {
    for (const tier of layout.tiers.filter(tier => !spansAvenue(tier) && !isPlaza(tier))) {
      for (const street of Object.values(SPLASH_CROSS_STREETS)) {
        const north = tier.z + tier.depth / 2 <= street - SPLASH_CROSS_STREET_HALF_WIDTH
        const south = tier.z - tier.depth / 2 >= street + SPLASH_CROSS_STREET_HALF_WIDTH
        expect(north || south).toBe(true)
      }
      for (const landmark of Object.values(SPLASH_LANDMARKS)) {
        expect(Math.hypot(tier.x - landmark.x, tier.z - landmark.z)).toBeGreaterThan(landmark.clearance)
      }
    }
  })

  it('keeps buildings near the resting camera below it so the final shot opens onto the skyline', () => {
    const rest = splashCameraAt(1).position
    const near = layout.tiers.filter(tier => tier.z < -45 && Math.hypot(tier.x - rest.x, tier.z - rest.z) < 150 && !spansAvenue(tier))
    expect(near.length).toBeGreaterThan(0)
    for (const tier of near) expect(tier.y + tier.height).toBeLessThan(rest.y)
  })
})

describe('splash camera and phases', () => {
  it('cranes from street level to the resting pose and clamps outside the move', () => {
    const start = splashCameraAt(0)
    const end = splashCameraAt(1)
    expect(start.position.y).toBeLessThan(10)
    expect(end.position.y).toBeGreaterThan(start.position.y + 120)
    expect(end.target.z).toBe(SPLASH_TOWER.z)
    expect(splashCameraAt(-1)).toEqual(start)
    expect(splashCameraAt(2)).toEqual(end)
  })

  it('eases a phase from 0 to 1 and holds outside it', () => {
    expect(splashPhase(0, 100, 200)).toBe(0)
    expect(splashPhase(200, 100, 200)).toBe(0.5)
    expect(splashPhase(250, 100, 200)).toBeGreaterThan(0.5)
    expect(splashPhase(900, 100, 200)).toBe(1)
  })
})

describe('splash traffic', () => {
  it('builds the same craft on every call, and craft sharing a lane share its speed', () => {
    const flyers = splashFlyers()
    expect(splashFlyers()).toEqual(flyers)
    expect(flyers.some(flyer => flyer.kind === SPLASH_CRAFT.spinner)).toBe(true)
    expect(flyers.some(flyer => flyer.kind === SPLASH_CRAFT.hauler)).toBe(true)
    const speeds = new Map<string, number>()
    for (const flyer of flyers) {
      const lane = `${flyer.origin.x},${flyer.origin.y},${flyer.origin.z},${flyer.directionX},${flyer.directionZ}`
      expect(speeds.get(lane) ?? flyer.speed).toBe(flyer.speed)
      speeds.set(lane, flyer.speed)
    }
    expect(splashTraffic()).toEqual(splashTraffic())
  })

  it('centres the maglev train on the avenue during the opening glide and loops within its span', () => {
    expect(splashTrainX(1.6)).toBeCloseTo(0)
    for (const seconds of [0, 3, 20, 400]) expect(Math.abs(splashTrainX(seconds))).toBeLessThanOrEqual(SPLASH_MAGLEV.span / 2)
  })
})
