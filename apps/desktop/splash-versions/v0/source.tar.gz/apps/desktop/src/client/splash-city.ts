/** Deterministic geometry for the WebGL launch city; no DOM or WebGL access. */

/** One tower's footprint, height, construction delay, and lighting character. */
export interface SplashTower {
  readonly x: number
  readonly z: number
  readonly width: number
  readonly depth: number
  readonly height: number
  readonly delay: number
  readonly accent: boolean
}

/** Build a seeded tower field with a clear central camera corridor. */
export function splashCityTowers(): SplashTower[] {
  let state = 0x70a704
  const random = (): number => {
    state = (state + 0x6d2b79f5) | 0
    let value = Math.imul(state ^ (state >>> 15), 1 | state)
    value = (value + Math.imul(value ^ (value >>> 7), 61 | value)) ^ value
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296
  }
  const towers: SplashTower[] = []
  for (let row = 0; row < 9; row += 1) {
    for (let column = -4; column <= 4; column += 1) {
      if (Math.abs(column) < 1 && row < 6) continue
      const x = column * 9 + (random() - 0.5) * 3
      const z = 22 - row * 12 + (random() - 0.5) * 4
      const centreBoost = Math.max(0, 1 - Math.abs(column) / 5)
      const height = 14 + random() * 32 + centreBoost * row * 2.8
      towers.push({
        x, z,
        width: 4 + random() * 3.5,
        depth: 4 + random() * 4,
        height,
        delay: row * 0.09 + random() * 0.45,
        accent: random() > 0.72,
      })
    }
  }
  return towers
}

/** Sample the continuous crane shot from street level to the suspended brand. */
export function splashCameraAt(progress: number): { x: number; y: number; z: number; targetY: number; targetZ: number } {
  const value = Math.min(1, Math.max(0, progress))
  const eased = value * value * (3 - 2 * value)
  return {
    x: Math.sin(value * Math.PI * 0.8) * 2.4,
    y: 3.8 + eased * 23,
    z: 50 - eased * 48,
    targetY: 4 + eased * 15,
    targetZ: -20 - eased * 15,
  }
}

/** Construction progress for one tower, independent of its geometry. */
export function splashTowerGrowth(elapsedMs: number, delaySeconds: number): number {
  const progress = Math.min(1, Math.max(0, elapsedMs / 1000 - delaySeconds) / 2.6)
  return 1 - (1 - progress) ** 3
}
