/** Splash animation timeline; the 3D scene and DOM wordmark share these boundaries. */

/** Phase boundaries in milliseconds from document start. */
export const SPLASH_TIMINGS = {
  /** Main tower construction; staggered towers may finish later. */
  cityRiseMs: 3600,
  /** Street-level flight and upward crane movement. */
  cameraMs: 5900,
  /** The brand remains absent until the city has established its scale. */
  markRevealMs: 4100,
  markMs: 1700,
  /** Geometric wordmark decoding follows the three-dimensional mark. */
  wordmarkDelayMs: 5650,
  wordmarkMs: 700,
  /** Final frame; the renderer reports completion here. */
  holdMs: 7200,
  /** Waiting indicator, measured from completion. */
  waitingDelayMs: 1500,
  /** Static final frame held under `prefers-reduced-motion`. */
  reducedMotionHoldMs: 400,
} as const

/**
 * When the renderer reports its animation complete.
 * @param reducedMotion - whether the document matches `prefers-reduced-motion: reduce`.
 * @returns the completion time in milliseconds from document start.
 */
export function splashAnimationDoneAt(reducedMotion: boolean): number {
  return reducedMotion ? SPLASH_TIMINGS.reducedMotionHoldMs : SPLASH_TIMINGS.holdMs
}

/**
 * When the waiting indicator fades in after the animation ends.
 * @param doneAtMs - completion time in milliseconds from document start.
 * @returns the indicator time in milliseconds from document start.
 */
export function splashWaitingAt(doneAtMs: number): number {
  return doneAtMs + SPLASH_TIMINGS.waitingDelayMs
}
