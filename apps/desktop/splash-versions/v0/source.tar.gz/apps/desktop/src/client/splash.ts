/** Startup splash: 3D city lifecycle, wordmark decode, skip, and completion handshake. */

import { SPLASH_TIMINGS, splashAnimationDoneAt } from './splash-timeline.ts'
import { decodeSplashText } from './splash-decode.ts'
import { startSplashScene } from './splash-scene.ts'
import type { SplashApi } from '../splash-api.ts'

declare global {
  interface Window {
    tomatoSplash?: SplashApi
  }
}

const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches

/**
 * Decode the visible brand name without changing its accessible label.
 * @param element - visual wordmark carrying its final value in `data-text`.
 * @returns finish resolves the target immediately; stop cancels work on unload.
 */
function startWordmarkDecode(element: HTMLElement | null): { finish(): void; stop(): void } {
  if (element === null || reducedMotion) return { finish: () => {}, stop: () => {} }
  const target = element.dataset.text ?? element.textContent ?? ''
  let delayTimer: number | undefined
  let frameTimer: number | undefined
  const clearTimers = (): void => {
    window.clearTimeout(delayTimer)
    if (frameTimer !== undefined) window.clearInterval(frameTimer)
  }
  const finish = (): void => {
    clearTimers()
    element.textContent = target
  }
  delayTimer = window.setTimeout(() => {
    const startedAt = performance.now()
    const render = (): void => {
      const progress = (performance.now() - startedAt) / SPLASH_TIMINGS.wordmarkMs
      element.textContent = decodeSplashText(target, progress)
      if (progress >= 1 && frameTimer !== undefined) {
        window.clearInterval(frameTimer)
        frameTimer = undefined
      }
    }
    render()
    frameTimer = window.setInterval(render, 40)
  }, SPLASH_TIMINGS.wordmarkDelayMs)
  return { finish, stop: clearTimers }
}

/**
 * Jump the document to its final frame and report completion once.
 * @param waiting - waiting indicator, revealed after `waitingDelayMs` when the shell has not exited yet.
 * @param doneAt - completion time in milliseconds from document start.
 * @param completeScene - resolves the 3D camera and pending decode before the final frame is exposed.
 * @returns the finish action used by skip input and the stop action used when the page is unloaded.
 */
function installCompletion(waiting: HTMLElement | null, doneAt: number, completeScene: () => void): { finish(): void; stop(): void } {
  let done = false
  let waitingTimer: number | undefined
  const doneTimer = window.setTimeout(() => { finish() }, doneAt)
  function finish(): void {
    if (done) return
    done = true
    window.clearTimeout(doneTimer)
    completeScene()
    document.documentElement.dataset.splash = 'done'
    waitingTimer = window.setTimeout(() => { waiting?.classList.add('visible') }, SPLASH_TIMINGS.waitingDelayMs)
    window.tomatoSplash?.notifyAnimationDone()
  }
  return {
    finish,
    stop: () => {
      window.clearTimeout(doneTimer)
      if (waitingTimer !== undefined) window.clearTimeout(waitingTimer)
    },
  }
}

const scene = startSplashScene(document.querySelector<HTMLCanvasElement>('#city-3d'), reducedMotion)
const wordmarkDecode = startWordmarkDecode(document.querySelector<HTMLElement>('.wordmark-name'))
const completeScene = (): void => {
  scene.finish()
  wordmarkDecode.finish()
}
const completion = installCompletion(
  document.querySelector<HTMLElement>('#waiting'),
  splashAnimationDoneAt(reducedMotion),
  completeScene,
)
const skip = (): void => { completion.finish() }
window.addEventListener('pointerdown', skip)
window.addEventListener('keydown', (event) => { if (event.key === 'Escape') skip() })
window.addEventListener('pagehide', () => {
  completion.stop()
  wordmarkDecode.stop()
  scene.stop()
}, { once: true })
