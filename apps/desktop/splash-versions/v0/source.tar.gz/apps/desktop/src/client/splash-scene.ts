/** Procedural WebGL night city and extruded Tomato mark for the desktop splash. */

import * as THREE from 'three'
import { SVGLoader } from 'three/addons/loaders/SVGLoader.js'
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js'
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js'
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js'
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js'
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js'
import { TOMATO_MARK_PATH } from '@tomato/brand/src/client/mark.ts'
import { SPLASH_TIMINGS } from './splash-timeline.ts'
import { splashCameraAt, splashCityTowers, splashTowerGrowth } from './splash-city.ts'

interface SplashScene {
  finish(): void
  stop(): void
}

interface TowerNode {
  readonly group: THREE.Group
  readonly delay: number
}

interface MarkNode {
  readonly group: THREE.Group
  readonly material: THREE.MeshPhysicalMaterial
}

interface BrandTowerNode {
  readonly group: THREE.Group
  readonly fieldMaterial: THREE.MeshBasicMaterial
}

const staticScene: SplashScene = { finish: () => {}, stop: () => {} }

function createMark(): MarkNode {
  const data = new SVGLoader().parse(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path d="${TOMATO_MARK_PATH}"/></svg>`)
  const geometries = data.paths.flatMap(path => path.toShapes().map(shape => new THREE.ExtrudeGeometry(shape, {
    depth: 2.4,
    bevelEnabled: true,
    bevelSegments: 4,
    bevelSize: 0.12,
    bevelThickness: 0.35,
    curveSegments: 10,
  })))
  const geometry = mergeGeometries(geometries, false)
  for (const part of geometries) part.dispose()
  if (geometry === null) throw new Error('splash: Tomato geometry could not be assembled')
  geometry.center()
  geometry.computeBoundingBox()
  const size = new THREE.Vector3()
  geometry.boundingBox?.getSize(size)
  // SVG Y grows downward; rotate the solid so the stem stays up without reversing face winding.
  geometry.rotateX(Math.PI)
  geometry.scale(11 / size.x, 11 / size.x, 11 / size.x)
  const material = new THREE.MeshPhysicalMaterial({
    color: 0xff2828,
    emissive: 0xff071c,
    emissiveIntensity: 1.15,
    metalness: 0.72,
    roughness: 0.2,
    clearcoat: 1,
    clearcoatRoughness: 0.12,
    transparent: true,
    opacity: 0,
  })
  const group = new THREE.Group()
  group.add(new THREE.Mesh(geometry, material))
  group.position.set(0, 18, -36)
  group.visible = false
  return { group, material }
}

function createWindows(width: number, height: number, depth: number, seed: number): THREE.BufferGeometry {
  const planes: THREE.BufferGeometry[] = []
  const columns = Math.max(3, Math.floor(width / 0.85))
  const rows = Math.min(28, Math.max(4, Math.floor(height / 1.35)))
  for (let row = 0; row < rows; row += 1) {
    for (let column = 0; column < columns; column += 1) {
      if ((row * 7 + column * 3 + seed) % 6 === 0) continue
      const plane = new THREE.PlaneGeometry(0.34 + (column % 3) * 0.07, 0.16)
      plane.translate((column - (columns - 1) / 2) * (width / columns), 0.75 + row * ((height - 1.2) / rows), depth / 2 + 0.025)
      planes.push(plane)
    }
    const sideColumns = Math.max(2, Math.floor(depth / 1.25))
    for (let column = 0; column < sideColumns; column += 1) {
      if ((row * 5 + column + seed) % 4 === 0) continue
      const plane = new THREE.PlaneGeometry(0.38, 0.16)
      plane.rotateY(Math.PI / 2)
      plane.translate(width / 2 + 0.025, 0.75 + row * ((height - 1.2) / rows), (column - (sideColumns - 1) / 2) * (depth / sideColumns))
      planes.push(plane)
    }
  }
  const geometry = mergeGeometries(planes, false)
  for (const plane of planes) plane.dispose()
  return geometry ?? new THREE.BufferGeometry()
}

/** Exterior mullions, floor plates, and side ribs give every tower a modeled facade. */
function createFacade(width: number, height: number, depth: number): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = []
  for (let index = 0; index < 5; index += 1) {
    const rib = new THREE.BoxGeometry(0.1, height, 0.16)
    rib.translate((index - 2) * width / 4.4, height / 2, depth / 2 + 0.08)
    parts.push(rib)
  }
  for (let index = 0; index < 3; index += 1) {
    const rib = new THREE.BoxGeometry(0.16, height, 0.1)
    rib.translate(width / 2 + 0.08, height / 2, (index - 1) * depth / 2.4)
    parts.push(rib)
  }
  for (let y = 3.6; y < height; y += 4.8) {
    const front = new THREE.BoxGeometry(width + 0.18, 0.09, 0.18)
    front.translate(0, y, depth / 2 + 0.09)
    parts.push(front)
    const side = new THREE.BoxGeometry(0.18, 0.09, depth + 0.18)
    side.translate(width / 2 + 0.09, y, 0)
    parts.push(side)
  }
  const geometry = mergeGeometries(parts, false)
  for (const part of parts) part.dispose()
  return geometry ?? new THREE.BufferGeometry()
}

function createSignMaterial(label: string, cyan: boolean): THREE.MeshBasicMaterial {
  const surface = document.createElement('canvas')
  surface.width = 512
  surface.height = 256
  const context = surface.getContext('2d')
  if (context === null) throw new Error('splash: signage canvas is unavailable')
  context.fillStyle = '#090208'
  context.fillRect(0, 0, 512, 256)
  context.strokeStyle = cyan ? '#55e6ff' : '#ff2828'
  context.lineWidth = 5
  context.strokeRect(10, 10, 492, 236)
  context.fillStyle = cyan ? '#a4f3ff' : '#ff5042'
  context.font = '600 54px monospace'
  context.textAlign = 'center'
  context.fillText(label, 256, 119)
  context.font = '22px monospace'
  context.fillText('NEURAL NETWORK // ACTIVE', 256, 172)
  context.fillRect(52, 201, 408, 3)
  const texture = new THREE.CanvasTexture(surface)
  texture.colorSpace = THREE.SRGBColorSpace
  return new THREE.MeshBasicMaterial({ map: texture, transparent: true, opacity: 0.9, side: THREE.DoubleSide, toneMapped: false })
}

function createCity(scene: THREE.Scene): TowerNode[] {
  const bodyMaterial = new THREE.MeshStandardMaterial({ color: 0x24111e, metalness: 0.65, roughness: 0.42, emissive: 0x310012, emissiveIntensity: 1.2 })
  const frameMaterial = new THREE.MeshStandardMaterial({ color: 0x57303d, metalness: 0.9, roughness: 0.24, emissive: 0x280008, emissiveIntensity: 0.45 })
  const equipmentMaterial = new THREE.MeshStandardMaterial({ color: 0x160e16, metalness: 0.86, roughness: 0.32 })
  const redWindows = new THREE.MeshBasicMaterial({ color: 0xff1828, transparent: true, opacity: 0.88, side: THREE.DoubleSide, toneMapped: false })
  const cyanWindows = new THREE.MeshBasicMaterial({ color: 0x55e6ff, transparent: true, opacity: 0.6, side: THREE.DoubleSide, toneMapped: false })
  const antennaMaterial = new THREE.MeshBasicMaterial({ color: 0xff5042 })
  const signLabels = ['TOMATO AI', 'KOL / LIVE', 'NEON CITY', 'DATA STREAM']
  return splashCityTowers().map((tower, index) => {
    const group = new THREE.Group()
    const body = new THREE.Mesh(new THREE.BoxGeometry(tower.width, tower.height, tower.depth), bodyMaterial)
    body.position.y = tower.height / 2
    group.add(body)
    group.add(new THREE.Mesh(createWindows(tower.width, tower.height, tower.depth, index), tower.accent ? cyanWindows : redWindows))
    group.add(new THREE.Mesh(createFacade(tower.width, tower.height, tower.depth), frameMaterial))
    const podium = new THREE.Mesh(new THREE.BoxGeometry(tower.width + 0.5, 0.7, tower.depth + 0.5), equipmentMaterial)
    podium.position.y = 0.35
    group.add(podium)
    let roof = tower.height
    if (tower.height > 28) {
      const crownHeight = 2.4 + index % 3
      const crown = new THREE.Mesh(new THREE.BoxGeometry(tower.width * 0.68, crownHeight, tower.depth * 0.68), bodyMaterial)
      crown.position.y = tower.height + crownHeight / 2
      group.add(crown)
      const roofLight = new THREE.Mesh(new THREE.BoxGeometry(tower.width * 0.72, 0.1, tower.depth * 0.72), antennaMaterial)
      roofLight.position.y = tower.height + crownHeight
      group.add(roofLight)
      roof += crownHeight
    }
    for (let unit = 0; unit < 2; unit += 1) {
      const equipment = new THREE.Mesh(new THREE.BoxGeometry(0.75 + unit * 0.18, 0.48, 0.65), equipmentMaterial)
      equipment.position.set((unit - 0.5) * tower.width * 0.38, roof + 0.24, -tower.depth * 0.15)
      group.add(equipment)
      const vent = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.04, 0.7), antennaMaterial)
      vent.position.set(equipment.position.x, roof + 0.5, equipment.position.z)
      group.add(vent)
    }
    if (tower.height > 23) {
      const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.06, 3.5, 5), antennaMaterial)
      mast.position.set(-tower.width * 0.18, roof + 1.75, 0)
      group.add(mast)
      const crossbar = new THREE.Mesh(new THREE.BoxGeometry(1.05, 0.045, 0.045), frameMaterial)
      crossbar.position.set(mast.position.x, roof + 2.35, 0)
      group.add(crossbar)
    }
    if (tower.accent) {
      const signWidth = tower.width * 0.82
      const signHeight = Math.min(3.8, tower.height * 0.17)
      const backing = new THREE.Mesh(new THREE.BoxGeometry(signWidth + 0.22, signHeight + 0.22, 0.16), frameMaterial)
      backing.position.set(0, tower.height * 0.66, tower.depth / 2 + 0.18)
      group.add(backing)
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(signWidth, signHeight), createSignMaterial(signLabels[index % signLabels.length] ?? 'TOMATO AI', index % 3 === 0))
      sign.position.set(0, tower.height * 0.66, tower.depth / 2 + 0.27)
      group.add(sign)
    }
    group.position.set(tower.x, 0, tower.z)
    group.scale.y = 0.001
    scene.add(group)
    return { group, delay: tower.delay }
  })
}

function createBrandTower(scene: THREE.Scene): BrandTowerNode {
  const group = new THREE.Group()
  const bodyMaterial = new THREE.MeshPhysicalMaterial({ color: 0x1c101b, metalness: 0.92, roughness: 0.25, clearcoat: 0.8 })
  const trimMaterial = new THREE.MeshStandardMaterial({ color: 0x6f2734, metalness: 0.88, roughness: 0.22, emissive: 0xff071c, emissiveIntensity: 0.28 })
  const body = new THREE.Mesh(new THREE.CylinderGeometry(4.1, 5.1, 16, 8), bodyMaterial)
  body.position.y = 8
  group.add(body)
  for (let index = 0; index < 8; index += 1) {
    const angle = index * Math.PI / 4
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.16, 14.8, 0.34), trimMaterial)
    fin.position.set(Math.sin(angle) * 4.35, 8.1, Math.cos(angle) * 4.35)
    fin.rotation.y = angle
    group.add(fin)
  }
  for (const [radius, height, y] of [[5.2, 0.5, 15.8], [4.6, 0.34, 16.25], [3.9, 0.5, 16.65]] as const) {
    const tier = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, height, 32), trimMaterial)
    tier.position.y = y
    group.add(tier)
  }
  const fieldMaterial = new THREE.MeshBasicMaterial({ color: 0xff1838, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, toneMapped: false })
  const field = new THREE.Mesh(new THREE.CylinderGeometry(3.4, 4.1, 8, 32, 1, true), fieldMaterial)
  field.position.y = 20.5
  group.add(field)
  group.position.z = -36
  group.scale.y = 0.001
  scene.add(group)
  return { group, fieldMaterial }
}

function createTraffic(scene: THREE.Scene): THREE.Mesh[] {
  const red = new THREE.MeshBasicMaterial({ color: 0xffb0a8 })
  const cyan = new THREE.MeshBasicMaterial({ color: 0x8cefff })
  return Array.from({ length: 14 }, (_, index) => {
    const vehicle = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 2.2 + index % 3), index % 4 === 0 ? cyan : red)
    vehicle.position.set((index % 2 === 0 ? -1 : 1) * (5 + (index % 5) * 6), 4 + (index % 6) * 2.8, 40 - index * 9)
    scene.add(vehicle)
    return vehicle
  })
}

function renderScene(canvas: HTMLCanvasElement, reducedMotion: boolean): SplashScene {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' })
  renderer.setPixelRatio(Math.min(1.5, window.devicePixelRatio || 1))
  renderer.toneMapping = THREE.ACESFilmicToneMapping
  renderer.toneMappingExposure = 1.15
  const scene = new THREE.Scene()
  scene.background = new THREE.Color(0x030105)
  scene.fog = new THREE.FogExp2(0x16030c, 0.004)
  const camera = new THREE.PerspectiveCamera(52, 1, 0.1, 260)
  const composer = new EffectComposer(renderer)
  composer.addPass(new RenderPass(scene, camera))
  composer.addPass(new UnrealBloomPass(new THREE.Vector2(1280, 760), 1.15, 0.65, 0.32))
  composer.addPass(new OutputPass())
  scene.add(new THREE.HemisphereLight(0x481423, 0x050308, 2.2))
  const key = new THREE.DirectionalLight(0xffb5aa, 4.5)
  key.position.set(-8, 26, 12)
  scene.add(key)
  const brandLight = new THREE.PointLight(0xff1828, 0, 90, 1.5)
  brandLight.position.set(0, 22, -24)
  scene.add(brandLight)
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(300, 300), new THREE.MeshStandardMaterial({ color: 0x050307, metalness: 0.8, roughness: 0.3 }))
  ground.rotation.x = -Math.PI / 2
  scene.add(ground)
  const grid = new THREE.GridHelper(240, 60, 0xff1828, 0x3a0712)
  grid.position.y = 0.025
  const gridMaterials = Array.isArray(grid.material) ? grid.material : [grid.material]
  for (const material of gridMaterials) {
    material.transparent = true
    material.opacity = 0.32
    material.depthWrite = false
  }
  scene.add(grid)
  const towers = createCity(scene)
  const brandTower = createBrandTower(scene)
  const traffic = createTraffic(scene)
  const mark = createMark()
  scene.add(mark.group)
  const startedAt = performance.now()
  let elapsed = reducedMotion ? SPLASH_TIMINGS.holdMs : 0
  let frame = 0
  let stopped = false

  const draw = (): void => {
    const seconds = elapsed / 1000
    for (const tower of towers) tower.group.scale.y = Math.max(0.001, splashTowerGrowth(elapsed, tower.delay))
    brandTower.group.scale.y = Math.max(0.001, splashTowerGrowth(elapsed, 0.7))
    for (const [index, vehicle] of traffic.entries()) {
      vehicle.position.z = 50 - ((seconds * (5 + index % 4) + index * 13) % 145)
    }
    const cameraPoint = splashCameraAt(elapsed / SPLASH_TIMINGS.cameraMs)
    camera.position.set(cameraPoint.x, cameraPoint.y, cameraPoint.z)
    camera.lookAt(0, cameraPoint.targetY, cameraPoint.targetZ)
    const reveal = Math.min(1, Math.max(0, (elapsed - SPLASH_TIMINGS.markRevealMs) / SPLASH_TIMINGS.markMs))
    const eased = reveal * reveal * (3 - 2 * reveal)
    mark.group.visible = reveal > 0
    mark.group.position.set(0, 14.8 + eased * 10.6, -36 + eased * 3.5)
    mark.group.scale.setScalar(0.52 + eased * 0.48)
    mark.group.rotation.y = -1.15 + eased * 1.23
    mark.material.opacity = Math.min(1, reveal * 2.2)
    mark.material.emissiveIntensity = 0.35 + eased * 0.8
    brandLight.position.set(0, 18 + eased * 8, -27)
    brandLight.intensity = eased * 1100
    brandTower.fieldMaterial.opacity = Math.sin(reveal * Math.PI) * 0.09 + eased * 0.025
    composer.render()
  }
  const tick = (): void => {
    if (stopped) return
    elapsed = Math.min(SPLASH_TIMINGS.holdMs, performance.now() - startedAt)
    draw()
    frame = requestAnimationFrame(tick)
  }
  const resize = (): void => {
    const width = window.innerWidth
    const height = window.innerHeight
    renderer.setSize(width, height, false)
    composer.setSize(width, height)
    camera.aspect = width / height
    camera.updateProjectionMatrix()
    if (reducedMotion) draw()
  }
  window.addEventListener('resize', resize)
  resize()
  if (reducedMotion) draw()
  else frame = requestAnimationFrame(tick)
  return {
    finish: () => {
      cancelAnimationFrame(frame)
      elapsed = SPLASH_TIMINGS.holdMs
      draw()
    },
    stop: () => {
      stopped = true
      cancelAnimationFrame(frame)
      window.removeEventListener('resize', resize)
      scene.traverse(object => {
        if (!(object instanceof THREE.Mesh)) return
        object.geometry.dispose()
        const materials = Array.isArray(object.material) ? object.material : [object.material]
        for (const material of materials) material.dispose()
      })
      composer.dispose()
      renderer.dispose()
    },
  }
}

/**
 * Start the procedural city, falling back to the static local brand when WebGL is unavailable.
 * @param canvas - target WebGL canvas; null selects the static fallback.
 * @param reducedMotion - render only the composed final frame when true.
 * @returns final-frame and disposal actions owned by the splash document.
 */
export function startSplashScene(canvas: HTMLCanvasElement | null, reducedMotion: boolean): SplashScene {
  if (canvas === null) {
    document.documentElement.dataset.scene = 'fallback'
    return staticScene
  }
  try {
    return renderScene(canvas, reducedMotion)
  } catch (error) {
    console.error('Tomato splash: WebGL initialization failed; using the static brand.', error)
    document.documentElement.dataset.scene = 'fallback'
    return staticScene
  }
}
