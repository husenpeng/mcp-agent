/**
 * Canvas artwork for blade signs and advertising screens: the modules of influencer marketing, from creator search to
 * campaign analytics. Neither shows the Tomato mark before its reveal.
 */

import * as THREE from 'three'
import { SPLASH_SCREEN_SLOTS, SPLASH_SIGN_SLOTS } from './splash-city.ts'

const CJK_FONT = '"PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Noto Sans CJK SC", sans-serif'
const LATIN_FONT = '"Montserrat", "Segoe UI", "Helvetica Neue", sans-serif'

interface NeonInk {
  readonly glow: string
  readonly core: string
}

const RED: NeonInk = { glow: '#ff2b3a', core: '#ffd9d4' }
const CYAN: NeonInk = { glow: '#29d6ff', core: '#e4fbff' }
const PINK: NeonInk = { glow: '#ff4fa0', core: '#ffe2ef' }
const AMBER: NeonInk = { glow: '#ffae2e', core: '#fff2d8' }
const MINT: NeonInk = { glow: '#3dffd0', core: '#e2fff6' }
const VIOLET: NeonInk = { glow: '#b58cff', core: '#efe6ff' }

/** Vertical sign artwork, one influencer-marketing module per atlas column; `SPLASH_SIGN_SLOTS` entries. */
const SIGN_ARTWORK: readonly { readonly glyphs: string; readonly ink: NeonInk; readonly caption: string }[] = [
  { glyphs: '达人搜索', ink: RED, caption: 'KOL SEARCH' },
  { glyphs: '达人画像', ink: CYAN, caption: 'PROFILE' },
  { glyphs: '受众洞察', ink: PINK, caption: 'AUDIENCE' },
  { glyphs: '假粉检测', ink: AMBER, caption: 'FAKE CHECK' },
  { glyphs: '一键建联', ink: MINT, caption: 'OUTREACH' },
  { glyphs: '种草投放', ink: RED, caption: 'CAMPAIGN' },
  { glyphs: '爆款追踪', ink: VIOLET, caption: 'TRENDING' },
  { glyphs: '数据复盘', ink: CYAN, caption: 'ANALYTICS' },
]

const SIGN_SLOT = { width: 256, height: 1024 } as const
const SCREEN_SLOT = { width: 1024, height: 512 } as const

function surface(width: number, height: number): { canvas: HTMLCanvasElement; context: CanvasRenderingContext2D } {
  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const context = canvas.getContext('2d')
  if (context === null) throw new Error('splash: signage canvas is unavailable')
  return { canvas, context }
}

/** Draw a glowing tube: a wide coloured halo under a pale core, so bloom reads it as lit glass. */
function neon(context: CanvasRenderingContext2D, ink: NeonInk, draw: (mode: 'stroke' | 'fill') => void, width: number): void {
  context.save()
  context.shadowColor = ink.glow
  context.shadowBlur = width * 3.2
  context.strokeStyle = ink.glow
  context.lineWidth = width
  context.lineJoin = 'round'
  context.lineCap = 'round'
  draw('stroke')
  context.shadowBlur = width * 1.2
  context.fillStyle = ink.core
  context.strokeStyle = ink.core
  context.lineWidth = width * 0.34
  draw('fill')
  context.restore()
}

function drawSign(context: CanvasRenderingContext2D, left: number, artwork: typeof SIGN_ARTWORK[number]): void {
  const { width, height } = SIGN_SLOT
  const inset = 14
  context.fillStyle = '#07040a'
  context.fillRect(left, 0, width, height)
  const panel = context.createLinearGradient(left, 0, left + width, 0)
  panel.addColorStop(0, '#0d0710')
  panel.addColorStop(0.5, '#160b17')
  panel.addColorStop(1, '#0d0710')
  context.fillStyle = panel
  context.fillRect(left + inset, inset, width - inset * 2, height - inset * 2)
  const frame = inset + 12
  neon(context, artwork.ink, () => { context.strokeRect(left + frame, frame, width - frame * 2, height - frame * 2) }, 7)
  // Glyphs stack down the panel; the module's English name runs along the foot, under a divider tube.
  const glyphs = Array.from(artwork.glyphs)
  const stepY = 720 / Math.max(1, glyphs.length)
  context.textAlign = 'center'
  context.textBaseline = 'middle'
  context.font = `700 ${Math.min(168, Math.floor(stepY * 0.84))}px ${CJK_FONT}`
  glyphs.forEach((glyph, index) => {
    const y = 80 + stepY * (index + 0.5)
    neon(context, artwork.ink, (mode) => {
      if (mode === 'stroke') context.strokeText(glyph, left + width / 2, y)
      else context.fillText(glyph, left + width / 2, y)
    }, 8)
  })
  neon(context, artwork.ink, () => {
    context.beginPath()
    context.moveTo(left + 62, 846)
    context.lineTo(left + width - 62, 846)
    context.stroke()
  }, 4)
  context.font = `600 26px ${LATIN_FONT}`
  context.fillStyle = artwork.ink.glow
  context.shadowColor = artwork.ink.glow
  context.shadowBlur = 12
  context.fillText(artwork.caption, left + width / 2, 900)
  context.shadowBlur = 0
}

/** Rounded panel fill used by the screens' interface cards. */
function card(context: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, fill: string): void {
  context.fillStyle = fill
  context.beginPath()
  context.roundRect(x, y, width, height, 18)
  context.fill()
}

function headline(context: CanvasRenderingContext2D, title: string, subtitle: string, glow: string, x: number): void {
  context.textAlign = 'left'
  context.font = `800 92px ${CJK_FONT}`
  context.fillStyle = '#ffffff'
  context.shadowColor = glow
  context.shadowBlur = 28
  context.fillText(title, x, 120)
  context.font = `600 34px ${CJK_FONT}`
  context.shadowBlur = 10
  context.fillStyle = glow
  context.fillText(subtitle, x + 4, 206)
  context.shadowBlur = 0
}

/** Creator search: a query bar over three matched creator cards with follower and engagement bars. */
function drawSearchScreen(context: CanvasRenderingContext2D, width: number, height: number): void {
  const sky = context.createLinearGradient(0, 0, width, height)
  sky.addColorStop(0, '#3a0326')
  sky.addColorStop(0.6, '#1a0636')
  sky.addColorStop(1, '#03141f')
  context.fillStyle = sky
  context.fillRect(0, 0, width, height)
  headline(context, 'AI 达人搜索', '全网达人 · 秒级匹配', '#ff4fa0', 56)
  card(context, 56, 262, 520, 70, 'rgba(255, 255, 255, 0.1)')
  context.strokeStyle = '#ff9fd0'
  context.lineWidth = 4
  context.beginPath()
  context.arc(96, 297, 16, 0, Math.PI * 2)
  context.moveTo(108, 309)
  context.lineTo(122, 323)
  context.stroke()
  context.font = `500 30px ${CJK_FONT}`
  context.fillStyle = '#ffe2ef'
  context.fillText('美妆 · 10万+粉丝 · 高互动', 140, 298)
  const tints = ['#ff4fa0', '#29d6ff', '#ffae2e']
  tints.forEach((tint, index) => {
    const y = 360 + index * 46
    card(context, 56, y, 520, 38, 'rgba(255, 255, 255, 0.06)')
    context.fillStyle = tint
    context.beginPath()
    context.arc(80, y + 19, 13, 0, Math.PI * 2)
    context.fill()
    context.fillStyle = 'rgba(255, 255, 255, 0.55)'
    context.fillRect(106, y + 12, 120, 14)
    context.fillStyle = tint
    context.fillRect(250, y + 14, 180 - index * 38, 10)
    context.fillRect(450, y + 14, 90 - index * 20, 10)
  })
  for (let ring = 0; ring < 6; ring += 1) {
    context.strokeStyle = `rgba(255, 79, 160, ${0.5 - ring * 0.07})`
    context.lineWidth = 3
    context.beginPath()
    context.arc(810, 270, 60 + ring * 32, 0, Math.PI * 2)
    context.stroke()
  }
  context.fillStyle = '#ffe2ef'
  context.beginPath()
  context.arc(810, 270, 34, 0, Math.PI * 2)
  context.fill()
}

/** Audience insight: a gender donut, an age histogram, and the share of genuine followers. */
function drawAudienceScreen(context: CanvasRenderingContext2D, width: number, height: number): void {
  context.fillStyle = '#01141c'
  context.fillRect(0, 0, width, height)
  headline(context, '受众洞察', '粉丝画像 · 真实度分析', '#29d6ff', 56)
  const segments = [[0.62, '#29d6ff'], [0.38, '#ff4fa0']] as const
  let start = -Math.PI / 2
  for (const [share, tint] of segments) {
    context.strokeStyle = tint
    context.lineWidth = 34
    context.beginPath()
    context.arc(190, 370, 84, start, start + share * Math.PI * 2)
    context.stroke()
    start += share * Math.PI * 2
  }
  context.textAlign = 'center'
  context.font = `700 40px ${LATIN_FONT}`
  context.fillStyle = '#e4fbff'
  context.fillText('62%', 190, 372)
  const ages = [0.34, 0.86, 1, 0.58, 0.3, 0.16]
  ages.forEach((age, index) => {
    const barHeight = 190 * age
    context.fillStyle = index === 2 ? '#3dffd0' : 'rgba(41, 214, 255, 0.75)'
    context.fillRect(370 + index * 62, 470 - barHeight, 40, barHeight)
  })
  context.textAlign = 'left'
  context.font = `600 30px ${CJK_FONT}`
  context.fillStyle = '#9feaff'
  context.fillText('真实粉丝', 780, 300)
  context.font = `800 96px ${LATIN_FONT}`
  context.fillStyle = '#e4fbff'
  context.shadowColor = '#29d6ff'
  context.shadowBlur = 24
  context.fillText('92%', 770, 390)
  context.shadowBlur = 0
}

/** Outreach: an AI-drafted invitation email and a send button. */
function drawOutreachScreen(context: CanvasRenderingContext2D, width: number, height: number): void {
  const warm = context.createLinearGradient(0, 0, 0, height)
  warm.addColorStop(0, '#2b0605')
  warm.addColorStop(1, '#120203')
  context.fillStyle = warm
  context.fillRect(0, 0, width, height)
  headline(context, '一键建联', 'AI 写邮件 · 批量触达达人', '#ffae2e', 56)
  card(context, 560, 56, 410, 400, 'rgba(255, 242, 216, 0.1)')
  context.font = `600 28px ${LATIN_FONT}`
  context.fillStyle = '#fff2d8'
  context.textAlign = 'left'
  context.fillText('To: creator@mail', 596, 110)
  context.fillStyle = 'rgba(255, 174, 46, 0.5)'
  context.fillRect(596, 136, 338, 3)
  const lines = [300, 338, 260, 320, 210, 290]
  lines.forEach((lineWidth, index) => {
    context.fillStyle = `rgba(255, 242, 216, ${0.55 - index * 0.05})`
    context.fillRect(596, 170 + index * 34, lineWidth, 12)
  })
  card(context, 596, 384, 160, 50, '#ff6a2b')
  context.font = `700 28px ${CJK_FONT}`
  context.fillStyle = '#ffffff'
  context.fillText('发送', 646, 410)
  for (let bar = 0; bar < 9; bar += 1) {
    const barHeight = 40 + ((bar * 37) % 11) * 12
    context.fillStyle = bar % 3 === 0 ? '#ffae2e' : '#ff3a2b'
    context.globalAlpha = 0.7
    context.fillRect(60 + bar * 48, height - 50 - barHeight, 30, barHeight)
  }
  context.globalAlpha = 1
}

/** Campaign analytics: a rising return curve over a perspective grid, also shown on the airship. */
function drawCampaignScreen(context: CanvasRenderingContext2D, width: number, height: number): void {
  context.fillStyle = '#0a0216'
  context.fillRect(0, 0, width, height)
  context.strokeStyle = 'rgba(255, 79, 160, 0.45)'
  context.lineWidth = 2
  for (let line = 0; line <= 16; line += 1) {
    context.beginPath()
    context.moveTo(width / 2, 280)
    context.lineTo(-400 + line * 115, height)
    context.stroke()
  }
  for (let row = 0; row < 6; row += 1) {
    const y = 280 + (row / 5) ** 2 * (height - 280)
    context.beginPath()
    context.moveTo(0, y)
    context.lineTo(width, y)
    context.stroke()
  }
  context.textAlign = 'left'
  context.font = `800 84px ${CJK_FONT}`
  context.fillStyle = '#e4fbff'
  context.shadowColor = '#29d6ff'
  context.shadowBlur = 26
  context.fillText('达人营销', 64, 100)
  context.font = `700 40px ${LATIN_FONT}`
  context.fillText('INFLUENCER MARKETING', 64, 176)
  context.font = `600 34px ${CJK_FONT}`
  context.fillStyle = '#ffd6ea'
  context.shadowColor = '#ff4fa0'
  context.fillText('种草投放 · 数据复盘', 66, 236)
  context.shadowBlur = 0
  const points = [[600, 300], [680, 270], [760, 280], [840, 200], [920, 150], [980, 80]] as const
  neon(context, PINK, () => {
    context.beginPath()
    points.forEach(([x, y], index) => {
      if (index === 0) context.moveTo(x, y)
      else context.lineTo(x, y)
    })
    context.stroke()
  }, 6)
  context.fillStyle = '#ffe2ef'
  for (const [x, y] of points) {
    context.beginPath()
    context.arc(x, y, 8, 0, Math.PI * 2)
    context.fill()
  }
  context.font = `800 54px ${LATIN_FONT}`
  context.fillText('ROI 3.6x', 700, 380)
}

/** Paint one screen slot; `index` selects the module. */
function drawScreen(context: CanvasRenderingContext2D, left: number, top: number, index: number): void {
  const { width, height } = SCREEN_SLOT
  context.save()
  context.beginPath()
  context.rect(left, top, width, height)
  context.clip()
  context.translate(left, top)
  context.textBaseline = 'middle'
  if (index === 0) drawSearchScreen(context, width, height)
  else if (index === 1) drawAudienceScreen(context, width, height)
  else if (index === 2) drawOutreachScreen(context, width, height)
  else drawCampaignScreen(context, width, height)
  context.restore()
}

function atlasTexture(canvas: HTMLCanvasElement, anisotropy: number): THREE.CanvasTexture {
  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.anisotropy = anisotropy
  texture.needsUpdate = true
  return texture
}

/**
 * Paint every blade sign into one row of vertical slots.
 * @param anisotropy - anisotropic filtering level for grazing views down the avenue.
 * @returns the atlas texture and its column/row grid.
 */
export function createSignAtlas(anisotropy: number): { texture: THREE.CanvasTexture; grid: THREE.Vector2 } {
  const { canvas, context } = surface(SIGN_SLOT.width * SPLASH_SIGN_SLOTS, SIGN_SLOT.height)
  SIGN_ARTWORK.forEach((artwork, index) => { drawSign(context, index * SIGN_SLOT.width, artwork) })
  return { texture: atlasTexture(canvas, anisotropy), grid: new THREE.Vector2(SPLASH_SIGN_SLOTS, 1) }
}

/**
 * Paint every advertising screen into a two-column grid of slots.
 * @param anisotropy - anisotropic filtering level for grazing views down the avenue.
 * @returns the atlas texture and its column/row grid.
 */
export function createScreenAtlas(anisotropy: number): { texture: THREE.CanvasTexture; grid: THREE.Vector2 } {
  const columns = 2
  const rows = Math.ceil(SPLASH_SCREEN_SLOTS / columns)
  const { canvas, context } = surface(SCREEN_SLOT.width * columns, SCREEN_SLOT.height * rows)
  for (let index = 0; index < SPLASH_SCREEN_SLOTS; index += 1) {
    drawScreen(context, (index % columns) * SCREEN_SLOT.width, Math.floor(index / columns) * SCREEN_SLOT.height, index)
  }
  return { texture: atlasTexture(canvas, anisotropy), grid: new THREE.Vector2(columns, rows) }
}
