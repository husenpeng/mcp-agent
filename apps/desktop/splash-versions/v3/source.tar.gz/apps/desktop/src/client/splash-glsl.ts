/** GLSL sources for the launch city: shared noise, sky, haze, and the building, ground, sky, prop, and panel surfaces. */

/**
 * Uniforms, hashes, noise, sky radiance, mark light, height haze, and lane placement shared by every city surface.
 * Materials that include it bind the shared `uTime`, `uDetail`, `uHazeScale`, `uHoloPos`, `uHolo`, `uFogDensity`, and
 * `uFogFalloff` uniform objects; a material may replace `uHazeScale` with its own.
 */
export const CITY_COMMON_GLSL = /* glsl */ `
uniform float uTime;
uniform float uDetail;
uniform float uHazeScale;
uniform vec3 uHoloPos;
uniform float uHolo;
uniform float uFogDensity;
uniform float uFogFalloff;

const vec3 HOLO_RGB = vec3(1.0, 0.075, 0.06);
const vec3 HAZE_LOW = vec3(0.2, 0.038, 0.052);
const vec3 HAZE_HIGH = vec3(0.028, 0.013, 0.042);

float hash11(float p) {
  p = fract(p * 0.1031);
  p *= p + 33.33;
  p *= p + p;
  return fract(p);
}

float hash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

float hash13(vec3 p3) {
  p3 = fract(p3 * 0.1031);
  p3 += dot(p3, p3.zyx + 31.32);
  return fract((p3.x + p3.y) * p3.z);
}

float valueNoise(vec2 p) {
  vec2 cell = floor(p);
  vec2 f = fract(p);
  vec2 blend = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(hash12(cell), hash12(cell + vec2(1.0, 0.0)), blend.x),
    mix(hash12(cell + vec2(0.0, 1.0)), hash12(cell + vec2(1.0, 1.0)), blend.x),
    blend.y);
}

float fbm(vec2 p, int octaves) {
  float value = 0.0;
  float amplitude = 0.5;
  for (int octave = 0; octave < 6; octave++) {
    if (octave >= octaves) break;
    value += amplitude * valueNoise(p);
    p = p * 2.03 + vec2(17.13, 9.71);
    amplitude *= 0.5;
  }
  return value;
}

// Coverage of a line of half-width halfWidth at signed offset; sub-pixel lines widen to one pixel at reduced energy.
float lineCoverage(float offset, float halfWidth, float pixel) {
  float shown = max(halfWidth, pixel);
  return clamp((shown - abs(offset)) / pixel + 0.5, 0.0, 1.0) * (halfWidth / shown);
}

// Periodic lines; once the period spans only a few pixels they resolve to their average so distant grids never shimmer.
float gridLine(float coord, float period, float halfWidth, float pixel) {
  float offset = mod(coord + 0.5 * period, period) - 0.5 * period;
  float average = 2.0 * halfWidth / period;
  return mix(average, lineCoverage(offset, halfWidth, pixel), smoothstep(2.5, 7.0, period / pixel));
}

// Polluted night sky: red horizon glow, under-lit cloud deck, and the mark's glint.
vec3 skyRadiance(vec3 origin, vec3 direction, int cloudOctaves) {
  float rise = direction.y;
  vec3 color = mix(HAZE_LOW * 1.08, vec3(0.052, 0.012, 0.038), smoothstep(0.0, 0.16, rise));
  color = mix(color, vec3(0.005, 0.005, 0.013), smoothstep(0.12, 0.62, rise));
  color = mix(color, HAZE_LOW * 0.8, smoothstep(0.0, -0.25, rise));
  if (cloudOctaves > 0 && rise > 0.0) {
    vec2 drift = vec2(uTime * 0.008, uTime * 0.003);
    float density = smoothstep(0.42, 0.86, fbm(direction.xz / (rise + 0.09) * 1.5 + drift, cloudOctaves));
    vec3 underside = mix(vec3(0.24, 0.046, 0.056), vec3(0.042, 0.018, 0.05), smoothstep(0.03, 0.4, rise));
    color = mix(color, underside, density * smoothstep(0.0, 0.12, rise) * 0.9);
  }
  float toward = max(dot(direction, normalize(uHoloPos - origin)), 0.0);
  color += HOLO_RGB * uHolo * 0.02 * pow(toward, 40.0);
  return color;
}

// Red light the lit mark casts on nearby surfaces.
vec3 holoLight(vec3 position, vec3 normal) {
  vec3 toLight = uHoloPos - position;
  float distanceSq = dot(toLight, toLight);
  return HOLO_RGB * uHolo * 3200.0 / (distanceSq + 1200.0) * max(dot(normal, toLight * inversesqrt(distanceSq)), 0.0);
}

// Night-city fill: warm bounce from the lit streets below, cool sky light from above.
vec3 cityAmbient(vec3 normal, float height) {
  vec3 street = mix(vec3(0.42, 0.11, 0.14), vec3(0.16, 0.08, 0.15), smoothstep(0.0, 180.0, height));
  return mix(street, vec3(0.1, 0.1, 0.2), normal.y * 0.5 + 0.5);
}

// Exponential height haze integrated along the eye ray; uHazeScale thins it for distant landmarks that must stay legible.
float hazeAmount(vec3 position) {
  vec3 ray = position - cameraPosition;
  float rayLength = length(ray);
  float originY = max(cameraPosition.y, 0.0);
  float rise = ray.y / max(rayLength, 1e-3) * uFogFalloff;
  float path = abs(rise) < 1e-5 ? rayLength : (1.0 - exp(-rayLength * rise)) / rise;
  return 1.0 - exp(-uFogDensity * uHazeScale * exp(-originY * uFogFalloff) * path);
}

vec3 hazeRadiance(vec3 position) {
  vec3 ray = position - cameraPosition;
  vec3 direction = ray / max(length(ray), 1e-3);
  float middle = max(cameraPosition.y, 0.0) + ray.y * 0.5;
  vec3 haze = mix(HAZE_LOW, HAZE_HIGH, smoothstep(0.0, 210.0, middle));
  float toward = max(dot(direction, normalize(uHoloPos - cameraPosition)), 0.0);
  return haze + HOLO_RGB * uHolo * 0.07 * pow(toward, 28.0);
}

vec3 applyHaze(vec3 color, vec3 position) {
  return mix(color, hazeRadiance(position), hazeAmount(position));
}

// Craft looping along a straight lane: lane = (origin, metres per second), motion = (direction x, direction z, phase, span).
// Craft shrink and dim within 24 m of either loop end, where they wrap.
vec3 lanePlacement(vec4 lane, vec4 motion, float bob, out vec3 forward, out vec3 right, out float presence) {
  forward = vec3(motion.x, 0.0, motion.y);
  right = vec3(motion.y, 0.0, -motion.x);
  float halfSpan = 0.5 * motion.w;
  float travelled = mod(motion.z + uTime * lane.w, motion.w) - halfSpan;
  presence = smoothstep(0.0, 24.0, halfSpan - abs(travelled));
  return lane.xyz + forward * travelled + vec3(0.0, sin(uTime * 0.8 + bob) * 0.3, 0.0);
}
`

/** Instanced building tiers: a unit box or cylinder with its base at y = 0, scaled, tapered, and placed per instance. */
export const FACADE_VERTEX_GLSL = /* glsl */ `
attribute vec3 aCenter;
attribute vec4 aSize;
attribute vec4 aStyle;
flat varying vec4 vStyle;
flat varying vec4 vSize;
flat varying float vBase;
varying vec3 vWorld;
varying vec3 vLocal;
varying vec3 vNormal;

void main() {
  vec3 local = position * aSize.xyz;
  vec3 surfaceNormal = normal;
  #ifdef RADIAL
  local.xz *= mix(1.0, aSize.w, position.y);
  float radius = 0.25 * (aSize.x + aSize.z);
  surfaceNormal.y += (1.0 - aSize.w) * radius / aSize.y * length(normal.xz);
  #endif
  vec3 world = aCenter + local;
  vStyle = aStyle;
  vSize = aSize;
  vBase = aCenter.y;
  vWorld = world;
  vLocal = local;
  vNormal = normalize(surfaceNormal);
  gl_Position = projectionMatrix * viewMatrix * vec4(world, 1.0);
}
`

/**
 * Facades: interior-mapped rooms behind tinted Fresnel glass, office floors lit in zones, residential windows lit
 * individually, mullions, spandrels, blinds, and steady accent lighting. `terrace` tiers are full-height clear glass in a
 * pale steel frame with garden roofs. Window detail resolves to its average once a window spans only a few pixels, so
 * distant facades never sparkle. `RADIAL` selects cylinder tiers.
 */
export const FACADE_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
flat varying vec4 vStyle;
flat varying vec4 vSize;
flat varying float vBase;
varying vec3 vWorld;
varying vec3 vLocal;
varying vec3 vNormal;

const float PI = 3.14159265;

// Room light: each building is warm or cool; rare rooms are lit by coloured screens. Terrace offices use neutral white.
vec3 roomLight(bool warm, bool neutral, float tone, float pick) {
  vec3 tint = neutral ? mix(vec3(1.0, 0.84, 0.66), vec3(0.94, 0.94, 0.92), tone)
    : warm ? mix(vec3(1.0, 0.54, 0.24), vec3(1.0, 0.74, 0.5), tone) : mix(vec3(0.62, 0.78, 1.0), vec3(0.88, 0.94, 1.0), tone);
  if (pick > 0.975) tint = pick > 0.988 ? vec3(1.0, 0.22, 0.55) : vec3(0.2, 0.88, 1.0);
  return tint * (0.09 + 0.3 * tone * tone + 0.06 * pick);
}

// Ray exit from inside a room box spanning [-1, 1]^3; the window is the z = -1 face.
vec3 roomRadiance(vec2 cellUv, vec3 direction, vec3 light, float lit, float hash) {
  vec3 origin = vec3(cellUv * 2.0 - 1.0, -1.0);
  vec3 inverse = 1.0 / (direction + vec3(1e-5));
  vec3 exits = abs(inverse) - origin * inverse;
  float t = min(min(exits.x, exits.y), exits.z);
  vec3 hit = origin + direction * t;
  float depth = hit.z * 0.5 + 0.5;
  float shade;
  if (t == exits.z) {
    shade = 0.42 + 0.16 * hit.y;
    float furniture = step(hit.y, -0.42) * step(0.3, fract(hit.x * 1.7 + hash * 5.0));
    shade *= 1.0 - 0.45 * furniture;
  } else if (t == exits.y) {
    if (direction.y > 0.0) {
      float fixture = (1.0 - smoothstep(0.36, 0.48, abs(hit.x))) * (1.0 - smoothstep(0.14, 0.24, abs(hit.z - 0.15)));
      shade = 0.55 + 1.1 * fixture;
    } else {
      shade = 0.12 + 0.12 * depth;
    }
  } else {
    shade = 0.24 + 0.16 * depth;
  }
  vec3 dark = vec3(0.003, 0.004, 0.007) * (0.5 + depth);
  return mix(dark, light * shade, lit);
}

vec3 wallRadiance(vec3 normal, vec3 view) {
  float seed = vStyle.x;
  int facade = int(vStyle.y + 0.5);
  float litRatio = vStyle.z;
  int trim = int(vStyle.w + 0.5);
  bool terrace = facade == 4;
  vec3 tangent = vec3(normal.z, 0.0, -normal.x);
  #ifdef RADIAL
  float radius = 0.25 * (vSize.x + vSize.z);
  float faceWidth = 2.0 * PI * radius;
  float u = (atan(vLocal.z / vSize.z, vLocal.x / vSize.x + 1e-6) + PI) * radius;
  float faceId = 0.0;
  #else
  float faceWidth = abs(normal.x) > 0.5 ? vSize.z : vSize.x;
  float u = dot(vLocal, tangent) + faceWidth * 0.5;
  float faceId = dot(floor(normal + 0.5), vec3(1.0, 0.0, 2.0)) + 3.0;
  #endif
  float y = vWorld.y;
  bool office = facade != 1;
  bool warm = terrace || hash11(seed * 41.3) < 0.55;

  float floorHeight = terrace ? 5.75 : 3.3 + 0.8 * hash11(seed * 71.3 + 0.17);
  float targetCell = facade == 1 ? 2.1 + 0.9 * hash11(seed * 13.7) : terrace ? 1.6 : 1.45 + 0.55 * hash11(seed * 29.3);
  float cellWidth = faceWidth / max(1.0, floor(faceWidth / targetCell + 0.5));
  vec2 coord = vec2(u / cellWidth, y / floorHeight);
  vec2 cell = floor(coord);
  vec2 cellUv = fract(coord);
  vec2 pixel = max(fwidth(coord), vec2(1e-5));
  float detail = smoothstep(1.8, 5.5, 1.0 / max(pixel.x, pixel.y));

  vec4 window = facade == 1 ? vec4(0.2, 0.3, 0.8, 0.82)
    : facade == 2 ? vec4(0.0, 0.4, 1.0, 0.9)
    : facade == 3 ? vec4(0.05, 0.16, 0.95, 0.97)
    : terrace ? vec4(0.025, 0.07, 0.975, 0.985)
    : vec4(0.03, 0.18, 0.97, 0.97);
  vec2 inside = smoothstep(window.xy - pixel, window.xy + pixel, cellUv)
    * (1.0 - smoothstep(window.zw - pixel, window.zw + pixel, cellUv));
  float windowMask = inside.x * inside.y;
  float windowArea = (window.z - window.x) * (window.w - window.y);

  float floorBias = hash12(vec2(cell.y, seed * 113.0 + faceId));
  float zoneCells = 3.0 + floor(hash11(seed * 7.7) * 5.0);
  float zone = floor(cell.x / zoneCells);
  float zoneHash = hash13(vec3(cell.y, zone, seed * 53.0 + faceId));
  float zoneTone = hash13(vec3(zone, cell.y, seed * 29.0 + faceId + 5.0));
  float roomHash = hash13(vec3(cell, seed * 197.0 + faceId * 7.0));
  float lit = office
    ? step(zoneHash, litRatio * (0.35 + 1.3 * floorBias)) * step(0.1, roomHash)
    : step(roomHash, litRatio * (0.5 + floorBias));
  float brightness = terrace ? 1.35 : 1.0;

  vec3 reflected = reflect(view, normal);
  float cosine = clamp(-dot(view, normal), 0.0, 1.0);
  float f0 = facade == 1 ? 0.04 : terrace ? 0.06 : 0.1;
  float fresnel = f0 + (1.0 - f0) * pow(1.0 - cosine, 5.0);
  vec3 glassTint = terrace ? vec3(0.9, 0.95, 1.0) : hash11(seed * 3.3) < 0.5 ? vec3(0.72, 0.84, 1.0) : vec3(1.0, 0.84, 0.7);
  vec3 sky = skyRadiance(vWorld, reflected, 0) * glassTint;

  vec3 albedo;
  float sheen;
  if (facade == 1) {
    float grime = fbm(vec2(u * 0.3, y * 0.04) + seed * 31.0, 3);
    float seam = lineCoverage(cellUv.x - 0.5, 0.012, pixel.x) * 0.5;
    albedo = vec3(0.055, 0.05, 0.052) * (0.6 + 0.8 * grime) * (1.0 - seam);
    sheen = 0.06;
  } else if (facade == 2) {
    albedo = vec3(0.03, 0.032, 0.038);
    sheen = 0.35;
  } else if (facade == 3) {
    albedo = vec3(0.012, 0.01, 0.014);
    sheen = 0.5;
  } else if (terrace) {
    albedo = vec3(0.16, 0.165, 0.17);
    sheen = 0.3;
  } else {
    albedo = vec3(0.018, 0.02, 0.026);
    sheen = 0.45;
  }
  vec3 structure = albedo * (cityAmbient(normal, y) + holoLight(vWorld, normal))
    + sky * (0.04 + 0.5 * pow(1.0 - cosine, 5.0)) * sheen;

  vec3 averageTint = terrace ? vec3(1.0, 0.86, 0.7) : warm ? vec3(1.0, 0.62, 0.34) : vec3(0.74, 0.86, 1.0);
  vec3 averageGlass = averageTint * litRatio * 0.13 * brightness * (1.0 - fresnel) + sky * fresnel;
  vec3 color = mix(structure, averageGlass, windowArea);
  float sharp = detail * uDetail;
  if (sharp > 0.0) {
    vec3 light = roomLight(warm, terrace, zoneTone, roomHash) * brightness;
    float roomDepth = cellWidth * 1.25 + 1.6;
    vec3 roomDirection = vec3(dot(view, tangent) / (0.5 * cellWidth), view.y / (0.5 * floorHeight), -dot(view, normal) / (0.5 * roomDepth));
    vec3 room = roomRadiance(cellUv, roomDirection, light, lit, roomHash);
    float blindHash = hash13(vec3(cell.yx, seed * 7.0 + faceId + 3.0));
    float blindLevel = mix(window.y, window.w, 0.2 + 0.7 * fract(blindHash * 7.31));
    float blinds = step(blindHash, terrace ? 0.0 : 0.16) * smoothstep(blindLevel - pixel.y, blindLevel + pixel.y, cellUv.y);
    float slats = mix(1.0, 0.72 + 0.28 * step(0.35, fract(cellUv.y * floorHeight * 5.0)), smoothstep(40.0, 80.0, 1.0 / pixel.y));
    room = mix(room, mix(vec3(0.008), light * (0.18 + 0.3 * cellUv.y), lit) * slats, blinds);
    vec3 glass = room * (1.0 - fresnel) + sky * fresnel;
    // Wide glazing splits into two panes.
    float pane = office && cellWidth > 1.4 ? lineCoverage(cellUv.x - 0.5, terrace ? 0.008 : 0.012, pixel.x) : 0.0;
    color = mix(color, mix(structure, glass, windowMask * (1.0 - pane)), sharp);
  }

  float pixelU = max(fwidth(u), 1e-4);
  float pixelY = max(fwidth(y), 1e-4);
  if (terrace) {
    // Each 11.5 m module reads as a framed cube: pale corner posts and slabs, with warm light washing each slab edge.
    #ifdef RADIAL
    float frame = gridLine(y - vBase, 11.5, 0.32, pixelY);
    #else
    float frame = max(lineCoverage(min(u, faceWidth - u), 0.38, pixelU), gridLine(y - vBase, 11.5, 0.32, pixelY));
    #endif
    color = mix(color, albedo * 1.6 * (cityAmbient(normal, y) + holoLight(vWorld, normal)), frame);
    color += vec3(1.0, 0.8, 0.55) * 0.3 * gridLine(y - vBase - 0.55, 11.5, 0.06, pixelY);
  }
  if (facade == 3) color += vec3(1.0, 0.06, 0.05) * 1.2 * gridLine(u, cellWidth * 4.0, 0.1, pixelU);
  if (trim == 1 || trim == 2) {
    #ifdef RADIAL
    float quarter = faceWidth * 0.25;
    float offset = mod(u, quarter);
    float edge = min(offset, quarter - offset);
    #else
    float edge = min(u, faceWidth - u);
    #endif
    vec3 strip = trim == 1 ? vec3(1.0, 0.07, 0.06) * 1.5 : vec3(0.1, 0.72, 1.0) * 1.25;
    color += strip * lineCoverage(edge - 0.12, 0.07, pixelU);
  } else if (trim == 3) {
    float below = vBase + vSize.y - y;
    color += vec3(1.0, 0.07, 0.06) * 1.5 * lineCoverage(below - 0.6, 0.22, pixelY);
  } else if (trim == 4) {
    vec3 led = hash11(seed * 5.1) < 0.5 ? vec3(0.15, 0.75, 1.0) : vec3(0.9, 0.95, 1.0);
    color += led * 0.5 * gridLine(y - floorHeight * window.y * 0.5, floorHeight * 2.0, 0.06, pixelY);
  } else if (trim == 5) {
    vec3 led = hash11(seed * 9.7) < 0.6 ? vec3(0.15, 0.75, 1.0) : vec3(1.0, 0.2, 0.5);
    color += led * 0.55 * gridLine(u, cellWidth * 3.0, 0.07, pixelU);
  }
  return color;
}

// Garden terrace: planting beds between paved paths, low bollard lights at the path crossings, and a lit balustrade.
vec3 gardenRoof(vec2 world, float seed, float rim) {
  vec2 pixel = max(fwidth(world), vec2(1e-4));
  float beds = smoothstep(0.38, 0.62, valueNoise(world * 0.16 + seed * 37.0));
  vec3 plant = vec3(0.012, 0.03, 0.014) * (0.55 + 0.9 * fbm(world * 0.9 + seed * 11.0, 2));
  vec3 paving = vec3(0.06, 0.057, 0.052);
  float path = max(gridLine(world.x, 7.0, 0.8, pixel.x), gridLine(world.y, 7.0, 0.8, pixel.y));
  vec3 surface = mix(plant, paving, clamp(path + (1.0 - beds) * 0.55, 0.0, 1.0));
  float bollards = gridLine(world.x, 7.0, 0.22, pixel.x) * gridLine(world.y, 7.0, 0.22, pixel.y);
  return surface * (vec3(0.16, 0.08, 0.14) + holoLight(vWorld, vec3(0.0, 1.0, 0.0)))
    + vec3(1.0, 0.72, 0.42) * (1.6 * bollards + 0.25 * rim);
}

vec3 roofRadiance() {
  float seed = vStyle.x;
  #ifdef RADIAL
  vec2 footprint = vLocal.xz / (0.5 * vSize.xz * vSize.w);
  float edge = 0.5 * min(vSize.x, vSize.z) * vSize.w * (1.0 - length(footprint));
  #else
  vec2 sides = 0.5 * vSize.xz - abs(vLocal.xz);
  float edge = min(sides.x, sides.y);
  #endif
  float rim = 1.0 - smoothstep(0.0, 0.6, edge);
  if (int(vStyle.y + 0.5) == 4) return gardenRoof(vWorld.xz, seed, rim);
  float grime = fbm(vWorld.xz * 0.12 + seed * 40.0, 3);
  vec3 albedo = vec3(0.045, 0.042, 0.046) * (0.65 + 0.6 * grime);
  vec3 color = albedo * (vec3(0.16, 0.08, 0.14) + holoLight(vWorld, vec3(0.0, 1.0, 0.0))) * (1.0 + 0.8 * rim);
  // Helipads mark some large roofs; the ring stays faint so roofs never compete with the mark.
  float pad = step(24.0, min(vSize.x, vSize.z)) * step(0.72, hash11(seed * 17.0));
  float radius = length(vLocal.xz);
  float pixel = max(fwidth(radius), 1e-4);
  color += vec3(0.2, 0.75, 1.0) * 0.32 * pad * (lineCoverage(radius - 6.5, 0.16, pixel) + 0.5 * lineCoverage(radius - 5.6, 0.08, pixel));
  return color;
}

// Bridge and cantilever undersides carry rows of cool panel lights.
vec3 soffitRadiance() {
  float pixel = max(fwidth(vLocal.x), 1e-4);
  float row = fract(vLocal.x / 3.0 + 0.5) * 3.0 - 1.5;
  float inside = step(abs(vLocal.z), 0.32 * vSize.z);
  return vec3(0.012) + vec3(0.6, 0.85, 1.0) * 0.9 * lineCoverage(row, 0.25, pixel) * inside;
}

void main() {
  vec3 normal = normalize(vNormal);
  vec3 view = normalize(vWorld - cameraPosition);
  vec3 color;
  if (normal.y > 0.5) color = roofRadiance();
  else if (normal.y < -0.5) color = soffitRadiance();
  else color = wallRadiance(normal, view);
  gl_FragColor = vec4(applyHaze(color, vWorld), 1.0);
}
`

/** Ground plane projected into the reflector's mirrored render. */
export const GROUND_VERTEX_GLSL = /* glsl */ `
uniform mat4 textureMatrix;
varying vec4 vReflection;
varying vec3 vWorld;

void main() {
  vReflection = textureMatrix * vec4(position, 1.0);
  vec4 world = modelMatrix * vec4(position, 1.0);
  vWorld = world.xyz;
  gl_Position = projectionMatrix * viewMatrix * world;
}
`

/**
 * The ground plane: the river between `uRiver.x` and `uRiver.y` is a rippled mirror whose vertical blur draws lights
 * into columns; the land is wet paving with puddle mirrors, Longteng Avenue's lanes and lamp pools, and the riverside
 * park's runway path with bollard pools. `color`, `tDiffuse`, and `textureMatrix` are bound by `Reflector`.
 */
export const GROUND_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
uniform vec3 color;
uniform sampler2D tDiffuse;
uniform vec4 uStreet;
uniform vec4 uRiver;
uniform vec2 uAvenue;
varying vec4 vReflection;
varying vec3 vWorld;

vec3 mirror(vec2 uv, float spread, float lod) {
  vec3 sum = vec3(0.0);
  float weight = 0.0;
  for (int tap = -3; tap <= 3; tap++) {
    float offset = float(tap) / 3.0;
    float tapWeight = exp(-offset * offset * 2.0);
    sum += textureLod(tDiffuse, uv + vec2(0.0, offset * spread), lod).rgb * tapWeight;
    weight += tapWeight;
  }
  return sum / weight;
}

void main() {
  vec3 p = vWorld;
  vec3 view = normalize(p - cameraPosition);
  vec2 pixel = max(fwidth(p.xz), vec2(1e-4));
  float cosine = clamp(-view.y, 0.0, 1.0);
  float grainDetail = 1.0 - smoothstep(0.2, 0.8, max(pixel.x, pixel.y) * 1.2);
  vec2 screen = vReflection.xy / vReflection.w;

  if (p.x > uRiver.x && p.x < uRiver.y) {
    vec2 swell = vec2(valueNoise(p.xz * vec2(0.03, 0.011) + vec2(0.0, uTime * 0.12)),
      valueNoise(p.xz * vec2(0.026, 0.009) + vec2(4.0, -uTime * 0.1))) - 0.5;
    vec2 chop = vec2(valueNoise(p.xz * 0.32 + uTime * 0.5), valueNoise(p.xz * 0.32 + 9.0 - uTime * 0.45)) - 0.5;
    vec3 reflection = mirror(screen + swell * 0.016 + chop * 0.005 * grainDetail, 0.03, 1.2);
    float fresnel = 0.02 + 0.98 * pow(1.0 - cosine, 5.0);
    vec3 deep = vec3(0.003, 0.008, 0.012) * (0.7 + 0.6 * valueNoise(p.xz * 0.015));
    vec3 radiance = deep * (vec3(0.3, 0.12, 0.16) + holoLight(p, vec3(0.0, 1.0, 0.0))) + reflection * color * mix(0.42, 1.0, fresnel);
    gl_FragColor = vec4(applyHaze(radiance, p), 1.0);
    return;
  }

  float across = abs(p.x);
  float onAvenue = step(uAvenue.y, p.z) * step(p.z, uAvenue.x);
  float road = onAvenue * (1.0 - smoothstep(uRiver.z - pixel.x, uRiver.z + pixel.x, across));
  float park = step(uStreet.z, p.x) * step(p.x, uStreet.w);

  float puddle = smoothstep(0.5, 0.62, fbm(p.xz * 0.045 + vec2(3.1, 7.7), 4));
  float grain = mix(0.5, fbm(p.xz * 1.2, 3), grainDetail);
  float wet = mix(0.45, 1.0, puddle) * (1.0 - 0.4 * (1.0 - road));
  float roughness = mix(0.5, 0.03, puddle);
  vec2 ripple = vec2(valueNoise(p.xz * 1.6 + uTime * 0.25), valueNoise(p.xz * 1.6 + 9.2 - uTime * 0.25)) - 0.5;
  vec3 reflection = mirror(screen + ripple * 0.005 * (1.0 - 0.7 * puddle) * grainDetail, roughness * 0.05, roughness * 4.0);
  float fresnel = 0.05 + 0.95 * pow(1.0 - cosine, 4.0);

  vec3 albedo = mix(vec3(0.05, 0.048, 0.052), vec3(0.02, 0.019, 0.022), road) * (0.7 + 0.6 * grain);
  albedo *= 1.0 - 0.35 * (1.0 - road) * max(gridLine(p.x, 1.5, 0.02, pixel.x), gridLine(p.z, 1.5, 0.02, pixel.y)) * grainDetail;
  float wear = smoothstep(0.25, 0.6, valueNoise(p.xz * vec2(2.0, 0.4)));
  float dash = smoothstep(0.0, pixel.y / 9.0 + 0.002, 0.42 - fract(p.z / 9.0));
  float lanes = ((lineCoverage(across - 3.35, 0.08, pixel.x) + lineCoverage(across - 6.75, 0.08, pixel.x)) * dash
    + lineCoverage(across - 9.55, 0.09, pixel.x)) * road;
  float centre = lineCoverage(across - 0.22, 0.06, pixel.x) * road;
  albedo = mix(albedo, vec3(0.42), lanes * wear);
  albedo = mix(albedo, vec3(0.5, 0.36, 0.08), centre * wear);
  albedo = mix(albedo, vec3(0.12), lineCoverage(across - uRiver.z, 0.08, pixel.x) * onAvenue);

  // The riverside park keeps a dark runway strip with a dashed centre line and edge lines.
  float runwayX = p.x - uRiver.w;
  float runway = park * (1.0 - smoothstep(7.0 - pixel.x, 7.0 + pixel.x, abs(runwayX)));
  albedo = mix(albedo, vec3(0.022, 0.021, 0.024) * (0.7 + 0.6 * grain), runway);
  float runwayPaint = runway * (lineCoverage(runwayX, 0.25, pixel.x) * step(0.55, fract(p.z / 24.0))
    + lineCoverage(abs(runwayX) - 6.4, 0.12, pixel.x));
  albedo = mix(albedo, vec3(0.5), runwayPaint * wear);

  vec3 light = vec3(0.3, 0.08, 0.1);
  float lampZ = p.z - uStreet.y * floor(p.z / uStreet.y + 0.5);
  float lampX = across - uStreet.x;
  light += vec3(1.0, 0.72, 0.46) * 2.4 * exp(-(lampX * lampX + lampZ * lampZ) / 32.0) * onAvenue;
  float bollardZ = p.z - 18.0 * floor(p.z / 18.0 + 0.5);
  float bollardX = p.x - (uRiver.w - 10.0);
  light += vec3(1.0, 0.78, 0.55) * 1.2 * exp(-(bollardX * bollardX + bollardZ * bollardZ) / 10.0) * park;
  light += vec3(1.0, 0.85, 0.65) * 0.6 * exp(-max(uRiver.x - p.x, 0.0) / 3.0) * park;
  light += holoLight(p, vec3(0.0, 1.0, 0.0));

  float shine = wet * (1.0 - 0.6 * clamp(lanes + centre + runwayPaint, 0.0, 1.0));
  vec3 radiance = albedo * light * (1.0 - 0.5 * shine) + reflection * color * fresnel * shine;
  radiance += vec3(0.1, 0.75, 1.0) * 1.1 * lineCoverage(p.x, 0.05, pixel.x) * step(0.5, fract(p.z / 4.0)) * road;
  gl_FragColor = vec4(applyHaze(radiance, p), 1.0);
}
`

/** Sky dome centred on the rendering camera. */
export const SKY_VERTEX_GLSL = /* glsl */ `
varying vec3 vDirection;

void main() {
  vDirection = position;
  gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);
}
`

/** Sky dome radiance; the mirrored ground render uses a cheaper cloud deck. */
export const SKY_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
varying vec3 vDirection;

void main() {
  gl_FragColor = vec4(skyRadiance(cameraPosition, normalize(vDirection), uDetail > 0.5 ? 5 : 2), 1.0);
}
`

/** Instanced or single props placed by their model and instance matrices. */
export const SOLID_VERTEX_GLSL = /* glsl */ `
varying vec3 vWorld;
varying vec3 vNormal;

void main() {
  mat4 model = modelMatrix;
  #ifdef USE_INSTANCING
  model = model * instanceMatrix;
  #endif
  vec4 world = model * vec4(position, 1.0);
  vWorld = world.xyz;
  vNormal = normalize(mat3(model) * normal);
  gl_Position = projectionMatrix * viewMatrix * world;
}
`

/** Painted metal or foliage lit by city glow and the mark, plus a uniform emissive term. */
export const SOLID_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
uniform vec3 uAlbedo;
uniform vec3 uEmissive;
uniform float uSheen;
varying vec3 vWorld;
varying vec3 vNormal;

void main() {
  vec3 normal = normalize(vNormal);
  vec3 view = normalize(vWorld - cameraPosition);
  float cosine = clamp(abs(dot(view, normal)), 0.0, 1.0);
  vec3 sky = skyRadiance(vWorld, reflect(view, normal), 0);
  vec3 color = uAlbedo * (cityAmbient(normal, vWorld.y) + holoLight(vWorld, normal))
    + sky * uSheen * (0.04 + 0.96 * pow(1.0 - cosine, 5.0)) + uEmissive;
  gl_FragColor = vec4(applyHaze(color, vWorld), 1.0);
}
`

/** Instanced screen quads turned by a per-instance yaw; `uPanelOffset` moves every instance together. */
export const PANEL_VERTEX_GLSL = /* glsl */ `
uniform vec3 uPanelOffset;
attribute vec4 aPanel;
attribute vec4 aShape;
flat varying vec2 vPanel;
varying vec2 vUv;
varying vec3 vWorld;

void main() {
  float c = cos(aPanel.w);
  float s = sin(aPanel.w);
  vec2 local = position.xy * aShape.xy;
  vec3 world = aPanel.xyz + uPanelOffset + vec3(local.x * c, local.y, -local.x * s);
  vPanel = aShape.zw;
  vUv = uv;
  vWorld = world;
  gl_Position = projectionMatrix * viewMatrix * vec4(world, 1.0);
}
`

/** Emissive atlas artwork with fine scan lines and a slow brightness sweep. */
export const PANEL_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
uniform sampler2D uAtlas;
uniform vec2 uGrid;
flat varying vec2 vPanel;
varying vec2 vUv;
varying vec3 vWorld;

void main() {
  float column = mod(vPanel.x, uGrid.x);
  float row = floor(vPanel.x / uGrid.x);
  vec2 uv = vec2((column + vUv.x) / uGrid.x, 1.0 - (row + 1.0 - vUv.y) / uGrid.y);
  vec3 color = texture2D(uAtlas, uv).rgb;
  float lineCoord = vUv.y * 90.0;
  float lines = 1.0 - 0.14 * smoothstep(0.4, 0.9, abs(fract(lineCoord) - 0.5) * 2.0) * (1.0 - smoothstep(0.3, 0.7, fwidth(lineCoord)));
  float sweep = 0.86 + 0.14 * smoothstep(0.82, 1.0, 1.0 - abs(fract(vUv.y * 0.6 - uTime * 0.07) - 0.5) * 2.0);
  gl_FragColor = vec4(applyHaze(color * lines * sweep * vPanel.y, vWorld), 1.0);
}
`
