/** GLSL sources for the landmark towers and the flying craft, train, and airship. */

import { CITY_COMMON_GLSL } from './splash-glsl.ts'

/** Landmark meshes placed by their model matrix; `BAKED` meshes carry facade coordinates in `aFacade`. */
export const LANDMARK_VERTEX_GLSL = /* glsl */ `
varying vec3 vWorld;
varying vec3 vNormal;
#ifdef BAKED
attribute vec2 aFacade;
varying vec2 vFacade;
#endif

void main() {
  vec4 world = modelMatrix * vec4(position, 1.0);
  vWorld = world.xyz;
  vNormal = normalize(mat3(modelMatrix) * normal);
  #ifdef BAKED
  vFacade = aFacade;
  #endif
  gl_Position = projectionMatrix * viewMatrix * world;
}
`

/**
 * Landmark surfaces, selected by one define: `PEARL_SPHERE` (glass spheres with LED parallels), `PEARL_COLUMN`
 * (shafts with LED strips and rings), `TWIST` (twisting curtain wall with a helix of corner light), `PLANAR` (the
 * opener's facade), `BAKED` with `CRYSTAL` (leaning glass towers with louvres) or `TANK` (ribbed steel tanks), and
 * `TRANSLUCENT` (frosted channel-glass boxes lit from within). Angular coordinates put their branch cut on +X, the side
 * facing away from the camera.
 */
export const LANDMARK_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
uniform float uSeed;
uniform vec2 uAxis;
uniform float uRadius;
uniform float uTwistRate;
varying vec3 vWorld;
varying vec3 vNormal;
#ifdef BAKED
varying vec2 vFacade;
#endif

const float PI = 3.14159265;
const vec3 PEARL_PINK = vec3(1.0, 0.16, 0.42);
const vec3 LED_CYAN = vec3(0.18, 0.82, 1.0);

// Glass curtain wall with office floors lit in zones; resolves to its average when cells span a few pixels.
vec3 curtainWall(float u, float y, float cellWidth, float floorHeight, float litRatio, bool warm, vec3 normal, vec3 view) {
  vec2 coord = vec2(u / cellWidth, y / floorHeight);
  vec2 cell = floor(coord);
  vec2 cellUv = fract(coord);
  vec2 pixel = max(fwidth(coord), vec2(1e-5));
  float detail = smoothstep(1.8, 5.5, 1.0 / max(pixel.x, pixel.y)) * uDetail;
  vec2 inside = smoothstep(vec2(0.04, 0.18) - pixel, vec2(0.04, 0.18) + pixel, cellUv)
    * (1.0 - smoothstep(vec2(0.96) - pixel, vec2(0.96) + pixel, cellUv));
  float zone = floor(cell.x / 5.0);
  float zoneHash = hash13(vec3(cell.y, zone, uSeed * 53.0));
  float tone = hash13(vec3(zone, cell.y, uSeed * 29.0 + 5.0));
  float lit = step(zoneHash, litRatio * (0.35 + 1.3 * hash12(vec2(cell.y, uSeed * 113.0))))
    * step(0.1, hash13(vec3(cell, uSeed * 197.0)));
  vec3 tint = warm ? mix(vec3(1.0, 0.54, 0.24), vec3(1.0, 0.74, 0.5), tone) : mix(vec3(0.62, 0.78, 1.0), vec3(0.88, 0.94, 1.0), tone);
  vec3 room = tint * (0.09 + 0.3 * tone * tone) * lit * (0.75 + 0.25 * cellUv.y);
  float cosine = clamp(-dot(view, normal), 0.0, 1.0);
  float fresnel = 0.1 + 0.9 * pow(1.0 - cosine, 5.0);
  vec3 sky = skyRadiance(vWorld, reflect(view, normal), 0) * vec3(0.78, 0.86, 1.0);
  vec3 frame = vec3(0.02, 0.022, 0.028) * (cityAmbient(normal, y) + holoLight(vWorld, normal)) + sky * 0.25;
  vec3 glass = room * (1.0 - fresnel) + sky * fresnel;
  vec3 average = mix(frame, tint * litRatio * 0.12 * (1.0 - fresnel) + sky * fresnel, 0.75);
  return mix(average, mix(frame, glass, inside.x * inside.y), detail);
}

vec3 metal(vec3 normal, vec3 view, vec3 albedo, float sheen) {
  float cosine = clamp(abs(dot(view, normal)), 0.0, 1.0);
  vec3 sky = skyRadiance(vWorld, reflect(view, normal), 0);
  return albedo * (cityAmbient(normal, vWorld.y) + holoLight(vWorld, normal)) + sky * sheen * (0.05 + 0.95 * pow(1.0 - cosine, 5.0));
}

void main() {
  vec3 normal = normalize(vNormal);
  vec3 view = normalize(vWorld - cameraPosition);
  vec3 color;
  #if defined(PEARL_SPHERE)
  float latitude = asin(clamp(normal.y, -1.0, 1.0));
  // The epsilon keeps atan defined at the poles, whose normals have no horizontal part.
  float longitude = atan(-normal.z, -normal.x + 1e-6);
  vec2 coord = vec2(longitude / (2.0 * PI) * 40.0, latitude / PI * 20.0);
  vec2 cell = floor(coord);
  vec2 pixel = max(fwidth(coord), vec2(1e-4));
  float cosine = clamp(-dot(view, normal), 0.0, 1.0);
  float fresnel = 0.08 + 0.92 * pow(1.0 - cosine, 5.0);
  vec3 sky = skyRadiance(vWorld, reflect(view, normal), 0);
  float glow = step(hash12(cell + uSeed * 17.0), 0.34) * (0.4 + 0.6 * hash12(cell.yx + 3.0));
  float panelDetail = smoothstep(2.0, 6.0, 1.0 / max(pixel.x, pixel.y));
  vec3 inner = PEARL_PINK * 0.2 * mix(0.37, glow, panelDetail) * (0.6 + 0.4 * smoothstep(-0.6, 0.6, normal.y));
  vec3 glass = inner * (1.0 - fresnel) + sky * fresnel;
  float frame = max(gridLine(coord.x, 1.0, 0.035, pixel.x), gridLine(coord.y, 1.0, 0.035, pixel.y));
  color = mix(glass, metal(normal, view, vec3(0.05), 0.4), frame);
  color += PEARL_PINK * 1.35 * gridLine(coord.y, 3.0, 0.06, pixel.y);
  color += LED_CYAN * 1.1 * lineCoverage(latitude, 0.02, max(fwidth(latitude), 1e-4));
  #elif defined(PEARL_COLUMN)
  float angle = atan(-normal.z, -normal.x + 1e-6);
  float strips = gridLine(angle, 2.0 * PI / 3.0, 0.07, max(fwidth(angle), 1e-4));
  float rings = gridLine(vWorld.y, 18.0, 0.22, max(fwidth(vWorld.y), 1e-4));
  color = metal(normal, view, vec3(0.06, 0.058, 0.064), 0.55) + LED_CYAN * 0.85 * strips + PEARL_PINK * 1.0 * rings;
  #elif defined(TWIST)
  vec2 offset = vWorld.xz - uAxis;
  float angle = atan(-offset.y, -offset.x + 1e-6) - uTwistRate * vWorld.y;
  float u = angle * uRadius;
  if (normal.y > 0.6) {
    color = metal(normal, view, vec3(0.04), 0.2);
  } else {
    color = curtainWall(u, vWorld.y, 1.8, 4.2, 0.3, false, normal, view);
    float angularPixel = max(fwidth(angle), 1e-4);
    color += vec3(0.75, 0.95, 1.0) * 1.25 * gridLine(angle - PI / 3.0, 2.0 * PI / 3.0, 0.011, angularPixel);
    color += LED_CYAN * 0.8 * gridLine(vWorld.y, 52.0, 0.3, max(fwidth(vWorld.y), 1e-4));
  }
  #elif defined(PLANAR)
  if (normal.y > 0.7) {
    color = metal(normal, view, vec3(0.04), 0.2);
  } else if (normal.y < -0.7) {
    float pixel = max(fwidth(vWorld.x), 1e-4);
    color = vec3(0.012) + vec3(0.6, 0.85, 1.0) * 0.7 * gridLine(vWorld.x, 3.0, 0.2, pixel);
  } else {
    vec3 tangent = normalize(vec3(normal.z, 0.0, -normal.x));
    float u = dot(vWorld, tangent);
    color = curtainWall(u, vWorld.y, 1.7, 4.0, 0.34, hash11(uSeed) < 0.5, normal, view);
    color += vec3(0.85, 0.92, 1.0) * 0.32 * gridLine(vWorld.y, 12.0, 0.08, max(fwidth(vWorld.y), 1e-4));
  }
  #elif defined(CRYSTAL)
  if (normal.y > 0.6) {
    color = metal(normal, view, vec3(0.03, 0.045, 0.03), 0.15);
  } else {
    // Clear crystal glazing with offices behind it, aluminium louvres every third of a floor, and lit slab edges.
    color = curtainWall(vFacade.x, vFacade.y, 1.5, 4.3, 0.4, false, normal, view) * vec3(0.9, 1.0, 1.08);
    float pixel = max(fwidth(vFacade.y), 1e-4);
    color = mix(color, metal(normal, view, vec3(0.12, 0.125, 0.13), 0.5), 0.55 * gridLine(vFacade.y, 4.3 / 3.0, 0.045, pixel));
    color += vec3(0.85, 0.93, 1.0) * 0.32 * gridLine(vFacade.y, 4.3, 0.07, pixel);
  }
  #elif defined(TANK)
  if (normal.y > 0.6) {
    color = metal(normal, view, vec3(0.05), 0.2);
  } else {
    // White-painted steel plates: horizontal and vertical seams, and warm light spilling from the glazed base band.
    vec2 pixel = max(fwidth(vFacade), vec2(1e-4));
    float seams = max(gridLine(vFacade.y, 2.4, 0.04, pixel.y), gridLine(vFacade.x, 8.0, 0.04, pixel.x));
    color = metal(normal, view, vec3(0.2, 0.2, 0.205) * (1.0 - 0.5 * seams), 0.3);
    float band = 1.0 - smoothstep(2.6, 3.2, vFacade.y);
    color = mix(color, vec3(1.0, 0.7, 0.42) * 0.55, band);
    color += vec3(1.0, 0.72, 0.45) * 0.55 * exp(-max(vFacade.y - 3.2, 0.0) / 2.5) * (1.0 - band);
  }
  #elif defined(TRANSLUCENT)
  // Roofs and the undersides the mirrored ground render sees have no horizontal tangent.
  if (abs(normal.y) > 0.6) {
    color = metal(normal, view, vec3(0.04), 0.2);
  } else {
    // Channel glass glowing from within: brighter near the floor, darker joints between the channels.
    vec3 tangent = normalize(vec3(normal.z, 0.0, -normal.x));
    float u = dot(vWorld, tangent);
    float pixelU = max(fwidth(u), 1e-4);
    float channels = gridLine(u, 0.55, 0.06, pixelU);
    float mullions = gridLine(u, 6.6, 0.18, pixelU);
    float glow = 0.05 + 0.08 * (1.0 - smoothstep(0.0, 14.0, vWorld.y)) + 0.03 * valueNoise(vec2(u * 0.25, vWorld.y * 0.18));
    color = vec3(1.0, 0.84, 0.64) * glow * (1.0 - 0.5 * channels) * (1.0 - 0.7 * mullions);
  }
  #endif
  gl_FragColor = vec4(applyHaze(color, vWorld), 1.0);
}
`

/**
 * Craft hulls. `LANE` instances follow their lane like `CRAFT_LIGHT_VERTEX_GLSL` lights do; otherwise the model matrix
 * places the mesh and `uPaint` colours it. `aGlow` carries per-vertex emission in rgb and glass coverage in alpha.
 */
export const CRAFT_VERTEX_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
attribute vec4 aGlow;
varying vec3 vWorld;
varying vec3 vNormal;
varying vec4 vGlow;
varying vec3 vPaint;
#ifdef LANE
attribute vec4 aLane;
attribute vec4 aMotion;
attribute vec4 aCraft;
#else
uniform vec3 uPaint;
#endif

void main() {
  #ifdef LANE
  vec3 forward;
  vec3 right;
  float presence;
  vec3 origin = lanePlacement(aLane, aMotion, aCraft.w, forward, right, presence);
  vec3 local = position * presence;
  vec3 world = origin + right * local.x + vec3(0.0, local.y, 0.0) + forward * local.z;
  vNormal = normalize(right * normal.x + vec3(0.0, normal.y, 0.0) + forward * normal.z);
  vPaint = aCraft.rgb;
  #else
  vec3 world = (modelMatrix * vec4(position, 1.0)).xyz;
  vNormal = normalize(mat3(modelMatrix) * normal);
  vPaint = uPaint;
  #endif
  vWorld = world;
  vGlow = aGlow;
  gl_Position = projectionMatrix * viewMatrix * vec4(world, 1.0);
}
`

/** Clear-coated paint or tinted glass reflecting the sky, lit by the city, plus per-vertex emission. */
export const CRAFT_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
varying vec3 vWorld;
varying vec3 vNormal;
varying vec4 vGlow;
varying vec3 vPaint;

void main() {
  vec3 normal = normalize(vNormal);
  vec3 view = normalize(vWorld - cameraPosition);
  float cosine = clamp(abs(dot(view, normal)), 0.0, 1.0);
  float glass = vGlow.a;
  float fresnel = mix(0.05, 0.08, glass) + (1.0 - mix(0.05, 0.08, glass)) * pow(1.0 - cosine, 5.0);
  vec3 sky = skyRadiance(vWorld, reflect(view, normal), 0);
  vec3 paint = mix(vPaint, vec3(0.006, 0.008, 0.012), glass);
  vec3 color = paint * (cityAmbient(normal, vWorld.y) + holoLight(vWorld, normal)) * (1.0 - fresnel)
    + sky * fresnel * mix(0.7, 1.0, glass) + vGlow.rgb;
  gl_FragColor = vec4(applyHaze(color, vWorld), 1.0);
}
`
