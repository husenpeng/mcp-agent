/** Deterministic layout, camera path, and traffic for the Xuhui Riverside launch scene; no DOM or WebGL access. */

/** A point in scene metres; +Y is up and −Z points downstream (north) along the Huangpu. */
export interface SplashVector {
  readonly x: number
  readonly y: number
  readonly z: number
}

/** Facade families resolved by the city shader; `terrace` is full-height glass with garden roofs. */
export const SPLASH_FACADE = { glass: 0, panel: 1, ribbon: 2, hero: 3, terrace: 4 } as const

/** One facade family. */
export type SplashFacade = typeof SPLASH_FACADE[keyof typeof SPLASH_FACADE]

/** Steady accent lighting resolved by the city shader. */
export const SPLASH_TRIM = { none: 0, redCorners: 1, cyanCorners: 2, crownBand: 3, floorLines: 4, fins: 5 } as const

/** One accent lighting choice. */
export type SplashTrim = typeof SPLASH_TRIM[keyof typeof SPLASH_TRIM]

/** Tier footprints: rectangular boxes or circular, optionally tapering cylinders. */
export const SPLASH_FORM = { box: 0, round: 1 } as const

/** One tier footprint. */
export type SplashForm = typeof SPLASH_FORM[keyof typeof SPLASH_FORM]

/** Axis-aligned box: centre `x`/`z`, base height `y`, and extents in metres. */
export interface SplashBox {
  readonly x: number
  readonly y: number
  readonly z: number
  readonly width: number
  readonly height: number
  readonly depth: number
}

/** One building tier and the facade parameters the city shader reads. */
export interface SplashTier extends SplashBox {
  /** Stable per-building hash input in [0, 1). */
  readonly seed: number
  readonly facade: SplashFacade
  /** Share of rooms with their lights on, in [0, 1]. */
  readonly lit: number
  readonly trim: SplashTrim
  readonly form: SplashForm
  /** Top-to-base footprint ratio; box tiers keep 1. */
  readonly taper: number
}

/** Advertising screen centred on `x`/`y`/`z`; `yaw` turns its +Z face around the vertical axis. */
export interface SplashScreen {
  readonly x: number
  readonly y: number
  readonly z: number
  readonly width: number
  readonly height: number
  readonly yaw: number
  /** Artwork slot in the screen atlas, below `SPLASH_SCREEN_SLOTS`. */
  readonly slot: number
}

/** Roof mast or spire standing on `y`, tapering to a steady obstruction light at its tip. */
export interface SplashAntenna {
  readonly x: number
  readonly y: number
  readonly z: number
  readonly height: number
  /** Base radius in metres. */
  readonly radius: number
}

/** The complete deterministic city. */
export interface SplashCityLayout {
  readonly tiers: readonly SplashTier[]
  readonly roofUnits: readonly SplashBox[]
  readonly antennas: readonly SplashAntenna[]
  readonly screens: readonly SplashScreen[]
}

/** Camera position, look-at target, and vertical field of view in degrees. */
export interface SplashCameraPose {
  readonly position: SplashVector
  readonly target: SplashVector
  readonly fov: number
}

/** A straight loop that craft and their lights follow. */
export interface SplashLane {
  /** Lane anchor; craft loop within `span / 2` metres of it along the travel direction. */
  readonly origin: SplashVector
  /** Unit horizontal travel direction. */
  readonly directionX: number
  readonly directionZ: number
  /** Metres per second; every craft on one lane shares it, so craft never overtake. */
  readonly speed: number
  /** Initial offset along the loop, in metres. */
  readonly phase: number
  /** Loop length in metres. */
  readonly span: number
  /** Phase of the slow vertical hover, in radians. */
  readonly bob: number
}

/** Modelled craft kinds; boats keep to the river surface. */
export const SPLASH_CRAFT = { spinner: 0, hauler: 1, boat: 2 } as const

/** One modelled craft kind. */
export type SplashCraftKind = typeof SPLASH_CRAFT[keyof typeof SPLASH_CRAFT]

/** A modelled craft. */
export interface SplashFlyer extends SplashLane {
  readonly kind: SplashCraftKind
  /** Linear paint albedo. */
  readonly paint: readonly [number, number, number]
}

/** A light-only vehicle. */
export interface SplashVehicle extends SplashLane {
  /** Trail length behind the light, in metres. */
  readonly trail: number
  /** Light radius in metres. */
  readonly radius: number
  /** Headlights face the viewer's end of the lane; tail lights face away. */
  readonly headlight: boolean
}

/** One SANAA-style tower of the X plot: elliptical plan, height, and the horizontal offset of its roof. */
export interface SplashLeaningTower {
  readonly x: number
  readonly z: number
  /** Plan semi-axes along the tower's own X and Z before `yaw`. */
  readonly radiusX: number
  readonly radiusZ: number
  readonly yaw: number
  readonly height: number
  /** Roof offset from the base centre; the walls lean toward it. */
  readonly leanX: number
  readonly leanZ: number
}

/** A painted steel tank of the riverside art centre. */
export interface SplashTank {
  readonly x: number
  readonly z: number
  readonly radius: number
  readonly height: number
}

/** Artwork slots drawn into the screen atlas. */
export const SPLASH_SCREEN_SLOTS = 4

/** The Huangpu between its banks (X) and along its course (Z); the water plane is y = 0. */
export const SPLASH_RIVER = { west: 70, east: 500, south: 900, north: -3600 } as const

/** Longteng Avenue runs along Z centred on x = 0; its carriageway spans ±`halfWidth`, sidewalks 2 m more. */
export const SPLASH_AVENUE = { start: 760, end: -1700, halfWidth: 10 } as const

/** Riverside park between the avenue's east sidewalk and the river's west bank. */
export const SPLASH_PROMENADE = { from: 12, to: SPLASH_RIVER.west } as const

/** Avenue lamps stand at ±`x` every `spacing` metres. */
export const SPLASH_LAMPS = { x: 12.4, spacing: 30, height: 9.5 } as const

/** The three Alibaba plots along the avenue, south to north; districts keep each footprint (plus 8 m) clear. */
export const SPLASH_CAMPUS = {
  /** Seven leaning crystal towers around a courtyard. */
  x: { minX: -152, maxX: -22, minZ: -150, maxZ: 44 },
  /** A transparent box hollowed on three sides around a public atrium. */
  d: { minX: -118, maxX: -26, minZ: -268, maxZ: -176 },
  /** Building 8: stacked cube modules with staggered roof terraces, cantilevers, and a central atrium. */
  z: { minX: -134, maxX: -24, minZ: -400, maxZ: -290 },
} as const

/** Building 8's projector module: the roof the beam and the mark rise from. */
export const SPLASH_HERO = { x: -57, z: -345, deck: 46 } as const

/** Centre and width of the projected Tomato mark above Building 8. */
export const SPLASH_MARK = { x: -57, y: 92, z: -345, width: 46 } as const

/** Lujiazui on the east bank downstream; each landmark model is scaled to its real proportion. */
export const SPLASH_LANDMARKS = {
  /** Television tower of stacked glass spheres on three shafts. */
  pearl: { x: 610, z: -2700, scale: 1.4 },
  /** Supertall with a rounded triangular plan twisting a third of a turn. */
  twist: { x: 830, z: -2960, radius: 30, scale: 1.45 },
  /** Tapered tower with a trapezoidal opening below its crown. */
  opener: { x: 915, z: -3070, scale: 1.4 },
} as const

/** Arch bridge across the river downstream of the campus: deck height, arch rise above the deck, and deck extent along X. */
export const SPLASH_BRIDGE = { z: -1450, deck: 46, rise: 104, width: 28, from: -60, to: 640 } as const

/** Advertising airship hovering over the avenue beyond Building 8, upper right of the resting shot. */
export const SPLASH_BLIMP = { x: 60, y: 118, z: -420, length: 24, radius: 4.6 } as const

/** Glass boxes of the riverside museum: centre, footprint, and pinwheel yaw. */
export const SPLASH_MUSEUM = [
  { x: 30, z: 318, width: 26, depth: 34, yaw: 0.12 },
  { x: 52, z: 338, width: 34, depth: 24, yaw: 0.12 },
  { x: 30, z: 362, width: 26, depth: 32, yaw: 0.12 },
] as const

/** Glass box height of the riverside museum. */
export const SPLASH_MUSEUM_HEIGHT = 17

/** The seven towers of the X plot, arranged around a courtyard that opens toward the river; each leans 7–11°. */
export const SPLASH_LEANING_TOWERS: readonly SplashLeaningTower[] = [
  { x: -50, z: 18, radiusX: 13, radiusZ: 19, yaw: 0.35, height: 61, leanX: -7, leanZ: -5 },
  { x: -97, z: 26, radiusX: 16, radiusZ: 12, yaw: -0.2, height: 48, leanX: 5, leanZ: -8 },
  { x: -134, z: -14, radiusX: 11, radiusZ: 17, yaw: 0.1, height: 42, leanX: 8, leanZ: 3 },
  { x: -130, z: -74, radiusX: 15, radiusZ: 13, yaw: 0.5, height: 55, leanX: 7, leanZ: 5 },
  { x: -92, z: -128, radiusX: 17, radiusZ: 11, yaw: -0.15, height: 38, leanX: 3, leanZ: 7 },
  { x: -46, z: -114, radiusX: 12, radiusZ: 16, yaw: 0.25, height: 52, leanX: -5, leanZ: 7 },
  { x: -42, z: -50, radiusX: 10, radiusZ: 14, yaw: -0.3, height: 34, leanX: -6, leanZ: 2 },
]

/** Steel tanks of the riverside art centre on the park between the avenue and the river. */
export const SPLASH_TANKS: readonly SplashTank[] = [
  { x: 36, z: 150, radius: 13, height: 16 },
  { x: 57, z: 182, radius: 9, height: 13 },
  { x: 32, z: 208, radius: 11, height: 18 },
  { x: 54, z: 238, radius: 12, height: 15 },
  { x: 30, z: 262, radius: 8, height: 12 },
]

interface CameraKey extends SplashCameraPose {
  /** Share of the camera move, in [0, 1]. */
  readonly at: number
}

/**
 * A low glide over the river past the X and D plots, a crane up Building 8's river facade while its projector powers
 * on, and a pull back that rests on Building 8, the river, the bridge, and Lujiazui in one frame.
 */
const CAMERA_KEYS: readonly CameraKey[] = [
  { at: 0, position: { x: 150, y: 4.5, z: 560 }, target: { x: 98, y: 11, z: 330 }, fov: 58 },
  { at: 0.28, position: { x: 122, y: 5.5, z: 236 }, target: { x: 46, y: 16, z: 34 }, fov: 56 },
  { at: 0.52, position: { x: 74, y: 9, z: -66 }, target: { x: -18, y: 26, z: -262 }, fov: 54 },
  { at: 0.74, position: { x: 9, y: 44, z: -248 }, target: { x: -58, y: 58, z: -322 }, fov: 50 },
  { at: 1, position: { x: 30, y: 90, z: -200 }, target: { x: -11, y: 64, z: -497 }, fov: 50 },
]

function createRandom(seed: number): () => number {
  let state = seed | 0
  return () => {
    state = (state + 0x6d2b79f5) | 0
    let value = Math.imul(state ^ (state >>> 15), 1 | state)
    value = (value + Math.imul(value ^ (value >>> 7), 61 | value)) ^ value
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296
  }
}

/** Cubic Hermite blend of one scalar between two keys. */
function hermite(from: number, to: number, fromSlope: number, toSlope: number, span: number, t: number): number {
  const t2 = t * t
  const t3 = t2 * t
  return (2 * t3 - 3 * t2 + 1) * from + (t3 - 2 * t2 + t) * span * fromSlope
    + (-2 * t3 + 3 * t2) * to + (t3 - t2) * span * toSlope
}

/** Catmull-Rom slope at key `index`; the first key keeps its travel speed and the last key comes to rest. */
function keySlope(read: (key: CameraKey) => number, index: number): number {
  const last = CAMERA_KEYS.length - 1
  if (index >= last) return 0
  const before = CAMERA_KEYS[Math.max(0, index - 1)]
  const after = CAMERA_KEYS[index + 1]
  if (before === undefined || after === undefined) return 0
  return (read(after) - read(before)) / (after.at - before.at)
}

/**
 * Sample the continuous camera move.
 * @param progress - share of the camera move; values outside [0, 1] clamp to the first or resting pose.
 * @returns the camera pose at that point of the move.
 */
export function splashCameraAt(progress: number): SplashCameraPose {
  const at = Math.min(1, Math.max(0, progress))
  let index = 0
  while (index < CAMERA_KEYS.length - 2 && (CAMERA_KEYS[index + 1]?.at ?? 1) < at) index += 1
  const from = CAMERA_KEYS[index]
  const to = CAMERA_KEYS[index + 1]
  if (from === undefined || to === undefined) throw new Error('splash: camera keys are incomplete')
  const span = to.at - from.at
  const t = (at - from.at) / span
  const blend = (read: (key: CameraKey) => number): number =>
    hermite(read(from), read(to), keySlope(read, index), keySlope(read, index + 1), span, t)
  return {
    position: { x: blend(key => key.position.x), y: blend(key => key.position.y), z: blend(key => key.position.z) },
    target: { x: blend(key => key.target.x), y: blend(key => key.target.y), z: blend(key => key.target.z) },
    fov: blend(key => key.fov),
  }
}

/**
 * Eased share of a timeline phase.
 * @param elapsedMs - milliseconds since the timeline started.
 * @param startMs - phase start in milliseconds.
 * @param durationMs - phase length in milliseconds.
 * @returns 0 before the phase, 1 after it, and a smoothstep-eased value between.
 */
export function splashPhase(elapsedMs: number, startMs: number, durationMs: number): number {
  const value = Math.min(1, Math.max(0, (elapsedMs - startMs) / durationMs))
  return value * value * (3 - 2 * value)
}

/** Whether a footprint centred on `x`/`z` with radius `reach` enters a campus plot or its 8 m margin. */
function onCampus(x: number, z: number, reach: number): boolean {
  return Object.values(SPLASH_CAMPUS).some(plot =>
    x + reach > plot.minX - 8 && x - reach < plot.maxX + 8 && z + reach > plot.minZ - 8 && z - reach < plot.maxZ + 8)
}

/** Whether a footprint reaches the avenue, the riverside park, the river, or the bridge's landing on either bank. */
function offLimits(x: number, z: number, reach: number): boolean {
  if (x + reach > -SPLASH_AVENUE.halfWidth - 6 && x - reach < SPLASH_RIVER.east + 30) return true
  const nearDeck = Math.abs(z - SPLASH_BRIDGE.z) < SPLASH_BRIDGE.width / 2 + reach + 6
  return nearDeck && x + reach > SPLASH_BRIDGE.from - 40 && x - reach < SPLASH_BRIDGE.to + 20
}

interface CityDraft {
  readonly tiers: SplashTier[]
  readonly roofUnits: SplashBox[]
  readonly antennas: SplashAntenna[]
  readonly screens: SplashScreen[]
}

interface Plot {
  readonly x: number
  readonly z: number
  readonly width: number
  readonly depth: number
  readonly height: number
}

function pickFacade(random: () => number): SplashFacade {
  const value = random()
  if (value < 0.46) return SPLASH_FACADE.glass
  if (value < 0.78) return SPLASH_FACADE.panel
  return SPLASH_FACADE.ribbon
}

function pickTrim(random: () => number, round: boolean): SplashTrim {
  const value = random()
  if (round) {
    if (value < 0.3) return SPLASH_TRIM.crownBand
    if (value < 0.55) return SPLASH_TRIM.floorLines
    if (value < 0.7) return SPLASH_TRIM.fins
    return SPLASH_TRIM.none
  }
  if (value < 0.05) return SPLASH_TRIM.redCorners
  if (value < 0.09) return SPLASH_TRIM.cyanCorners
  if (value < 0.18) return SPLASH_TRIM.crownBand
  if (value < 0.25) return SPLASH_TRIM.floorLines
  if (value < 0.3) return SPLASH_TRIM.fins
  return SPLASH_TRIM.none
}

/** Stack a podium, setbacks or a tapering drum, roof plant, and a mast or spire on one plot; returns the tiers it added. */
function addBuilding(city: CityDraft, random: () => number, plot: Plot): SplashTier[] {
  const seed = random()
  const round = plot.height > 46 && random() < 0.17
  const facade = round ? (random() < 0.6 ? SPLASH_FACADE.glass : SPLASH_FACADE.ribbon) : pickFacade(random)
  const lit = 0.08 + random() * 0.3
  const trim = pickTrim(random, round)
  const form = round ? SPLASH_FORM.round : SPLASH_FORM.box
  const added: SplashTier[] = []
  let base = 0
  let width = round ? Math.min(plot.width, plot.depth) : plot.width
  let depth = round ? width : plot.depth
  let tierCount = plot.height > 60 ? 2 + Math.floor(random() * 2) : random() < 0.4 ? 2 : 1
  if (round) tierCount = Math.min(tierCount, 2)
  if (!round && tierCount > 1 && random() < 0.55) {
    const podium = Math.min(plot.height * 0.4, 9 + random() * 10)
    added.push({
      x: plot.x, y: 0, z: plot.z, width, depth, height: podium, seed, facade: SPLASH_FACADE.panel,
      lit: Math.min(1, lit + 0.15), trim: SPLASH_TRIM.none, form, taper: 1,
    })
    base = podium
    width *= 0.7 + random() * 0.18
    depth *= 0.7 + random() * 0.18
    tierCount -= 1
  }
  for (let tier = 0; tier < tierCount; tier += 1) {
    const remaining = plot.height - base
    const last = tier === tierCount - 1
    const height = last ? remaining : remaining * (0.58 + random() * 0.2)
    const taper = round ? 0.84 + random() * 0.16 : 1
    added.push({
      x: plot.x, y: base, z: plot.z, width, depth, height, seed, facade, lit, trim: last ? trim : SPLASH_TRIM.none, form, taper,
    })
    base += height
    const shrink = round ? taper * (0.82 + random() * 0.1) : 0.72 + random() * 0.16
    width *= shrink
    depth = round ? width : depth * (0.72 + random() * 0.16)
  }
  const top = added.at(-1)
  if (top === undefined) return added
  const roof = top.y + top.height
  const topWidth = top.width * top.taper
  const topDepth = top.depth * top.taper
  if (round && random() < 0.45) {
    city.antennas.push({ x: top.x, y: roof, z: top.z, height: plot.height * (0.12 + random() * 0.1), radius: topWidth * 0.12 })
  } else {
    const units = 1 + Math.floor(random() * 3)
    for (let unit = 0; unit < units; unit += 1) {
      const unitWidth = 1.6 + random() * Math.min(5, topWidth * 0.3)
      const unitDepth = 1.6 + random() * Math.min(5, topDepth * 0.3)
      const spread = round ? 0.5 : 1
      city.roofUnits.push({
        x: top.x + (random() - 0.5) * (topWidth - unitWidth - 1.5) * spread,
        y: roof,
        z: top.z + (random() - 0.5) * (topDepth - unitDepth - 1.5) * spread,
        width: unitWidth,
        height: 1.2 + random() * 2.4,
        depth: unitDepth,
      })
    }
    if (plot.height > 70 && random() < 0.55) {
      const spire = !round && plot.height > 110 && random() < 0.35
      city.antennas.push({
        x: top.x + (spire ? 0 : (random() - 0.5) * topWidth * 0.5),
        y: roof,
        z: top.z + (spire ? 0 : (random() - 0.5) * topDepth * 0.5),
        height: spire ? 18 + random() * 22 : 7 + random() * 16,
        radius: spire ? Math.min(topWidth, topDepth) * 0.09 : 0.22,
      })
    }
  }
  city.tiers.push(...added)
  return added
}

/** Height map of Building 8 in 11.5 m levels: columns run west from the river facade, rows north from the south facade. */
const HERO_LEVELS: readonly (readonly number[])[] = [
  [2, 3, 3, 4, 4],
  [2, 3, 4, 4, 4],
  [3, 4, 0, 4, 3],
  [2, 3, 4, 4, 3],
  [1, 2, 3, 3, 4],
]
const HERO_MODULE = 22
const HERO_LEVEL = 11.5

/**
 * Building 8: cube modules stacked to the height map, a central atrium crossed by collaboration bridges, and
 * cantilevered top modules over the south and river facades. Every roof is a garden terrace.
 */
function addHero(city: CityDraft): void {
  const { maxX, maxZ } = SPLASH_CAMPUS.z
  const terrace = (x: number, y: number, z: number, width: number, height: number, depth: number, seed: number): void => {
    city.tiers.push({
      x, y, z, width, height, depth, seed, facade: SPLASH_FACADE.terrace, lit: 0.62, trim: SPLASH_TRIM.none,
      form: SPLASH_FORM.box, taper: 1,
    })
  }
  HERO_LEVELS.forEach((row, rowIndex) => {
    row.forEach((levels, column) => {
      if (levels === 0) return
      const x = maxX - HERO_MODULE / 2 - column * HERO_MODULE
      const z = maxZ - HERO_MODULE / 2 - rowIndex * HERO_MODULE
      terrace(x, 0, z, HERO_MODULE, levels * HERO_LEVEL, HERO_MODULE, 0.41 + rowIndex * 0.013 + column * 0.007)
    })
  })
  const atriumX = maxX - HERO_MODULE * 2.5
  const atriumZ = maxZ - HERO_MODULE * 2.5
  terrace(atriumX, 16, atriumZ, HERO_MODULE, 3.2, 5, 0.47)
  terrace(atriumX, 27.5, atriumZ, 5, 3.2, HERO_MODULE, 0.48)
  for (const column of [3, 4]) {
    terrace(maxX - HERO_MODULE / 2 - column * HERO_MODULE, 3 * HERO_LEVEL, maxZ + 3.5, HERO_MODULE, HERO_LEVEL, 7, 0.44)
  }
  terrace(maxX + 3, 2 * HERO_LEVEL, maxZ - HERO_MODULE * 2.5, 6, HERO_LEVEL, HERO_MODULE, 0.45)
}

/**
 * The Alibaba headquarters: a back block, two wings lifted over open ground, and a top bridge across the river front,
 * framing an atrium whose terraces step down toward the river.
 */
function addHeadquarters(city: CityDraft): void {
  const glass = (x: number, y: number, z: number, width: number, height: number, depth: number, trim: SplashTrim): void => {
    city.tiers.push({
      x, y, z, width, height, depth, seed: 0.73, facade: SPLASH_FACADE.terrace, lit: 0.55, trim, form: SPLASH_FORM.box, taper: 1,
    })
  }
  const { minX, maxX, minZ, maxZ } = SPLASH_CAMPUS.d
  const centreZ = (minZ + maxZ) / 2
  const wing = 28
  glass(minX + wing / 2, 0, centreZ, wing, 56, maxZ - minZ, SPLASH_TRIM.floorLines)
  for (const z of [minZ + wing / 2, maxZ - wing / 2]) {
    glass((minX + wing + maxX) / 2, 22, z, maxX - minX - wing, 34, wing, SPLASH_TRIM.floorLines)
  }
  glass(maxX - 13, 40, centreZ, 26, 16, maxZ - minZ - wing * 2, SPLASH_TRIM.floorLines)
  const steps = [[18, 30], [14, 18], [12, 7]] as const
  let x = minX + wing
  for (const [width, height] of steps) {
    glass(x + width / 2, 0, centreZ, width, height, maxZ - minZ - wing * 2, SPLASH_TRIM.none)
    x += width
  }
  glass(minX + wing + 13, 0, minZ + wing / 2, 26, 6, wing - 6, SPLASH_TRIM.none)
}

/** The West Bund behind the campus: riverside mid-rise, inland blocks rising to towers, and the AI twin towers. */
function addWestBund(city: CityDraft, random: () => number): void {
  for (let gridX = -890; gridX <= -30; gridX += 44) {
    for (let gridZ = -1720; gridZ <= 720; gridZ += 44) {
      const buildings = 1 + Math.floor(random() * 2.2)
      for (let index = 0; index < buildings; index += 1) {
        const width = 12 + random() * (buildings === 1 ? 20 : 12)
        const depth = 12 + random() * (buildings === 1 ? 20 : 12)
        const x = gridX + (random() - 0.5) * (32 - width)
        const z = gridZ + (random() - 0.5) * (32 - depth)
        const reach = Math.max(width, depth) / 2
        if (onCampus(x, z, reach) || offLimits(x, z, reach)) continue
        // Mid-rise lines the river; towers only rise inland, so the resting shot keeps a low skyline behind Building 8.
        const inland = Math.min(1, Math.max(0, (-x - 160) / 520))
        const spike = random() < inland * 0.07 ? 50 + random() * 100 : 0
        addBuilding(city, random, { x, z, width, depth, height: 16 + random() ** 1.7 * (28 + inland * 60) + spike })
      }
    }
  }
  for (const [x, z, height] of [[-318, -1140, 232], [-352, -1206, 204]] as const) {
    const section = (y: number, size: number, sectionHeight: number, seed: number, facade: SplashFacade, trim: SplashTrim): SplashTier =>
      ({ x, y, z, width: size, height: sectionHeight, depth: size, seed, facade, lit: 0.38, trim, form: SPLASH_FORM.box, taper: 1 })
    city.tiers.push(
      section(0, 44, 24, 0.91, SPLASH_FACADE.panel, SPLASH_TRIM.crownBand),
      section(24, 34, height - 64, 0.92, SPLASH_FACADE.glass, SPLASH_TRIM.fins),
      section(height - 40, 26, 40, 0.93, SPLASH_FACADE.hero, SPLASH_TRIM.crownBand),
    )
    city.antennas.push({ x, y: height, z, height: 26, radius: 1.6 })
  }
  // Rooftop screens north of the campus face the river.
  for (const tier of city.tiers) {
    if (city.screens.length >= 7) break
    if (tier.y !== 0 || tier.z > -460 || tier.z < -1000 || tier.x < -150 || tier.height < 40 || tier.form !== SPLASH_FORM.box) continue
    const width = Math.min(tier.depth - 2, 12 + random() * 6)
    const height = width * 0.5
    city.screens.push({
      x: tier.x + tier.width / 2 - 1, y: tier.height + 1.5 + height / 2, z: tier.z, width, height,
      yaw: Math.PI / 2, slot: city.screens.length % SPLASH_SCREEN_SLOTS,
    })
  }
}

/** Pudong across the river: the low Expo riverside upstream of the bridge and the Lujiazui towers downstream. */
function addPudong(city: CityDraft, random: () => number): void {
  for (let gridX = SPLASH_RIVER.east + 44; gridX <= 1500; gridX += 50) {
    for (let gridZ = -2300; gridZ <= 720; gridZ += 50) {
      if (random() < 0.35) continue
      const width = 14 + random() * 22
      const depth = 14 + random() * 22
      const x = gridX + (random() - 0.5) * (36 - width)
      const z = gridZ + (random() - 0.5) * (36 - depth)
      if (offLimits(x, z, Math.max(width, depth) / 2)) continue
      addBuilding(city, random, { x, z, width, depth, height: 14 + random() ** 2 * 60 })
    }
  }
  for (let index = 0; index < 22; index += 1) {
    const x = 380 + random() * 700
    const z = -2620 - random() * 680
    const clear = Object.values(SPLASH_LANDMARKS).every(landmark => Math.hypot(x - landmark.x, z - landmark.z) > 70)
    if (!clear || x < SPLASH_RIVER.east + 20) continue
    const width = 30 + random() * 26
    addBuilding(city, random, { x, z, width, depth: width * (0.8 + random() * 0.4), height: 140 + random() ** 1.4 * 200 })
  }
}

/**
 * Build the seeded city: the three Alibaba plots, the West Bund behind them, and Pudong across the river.
 * Buildings stay off the avenue, the riverside park, the river, and the bridge landings.
 * @returns the same layout on every call.
 */
export function splashCityLayout(): SplashCityLayout {
  const random = createRandom(0x70a704)
  const city: CityDraft = { tiers: [], roofUnits: [], antennas: [], screens: [] }
  addHero(city)
  addHeadquarters(city)
  addWestBund(city, random)
  addPudong(city, random)
  return city
}

const SPINNER_PAINTS: readonly (readonly [number, number, number])[] = [
  [0.05, 0.052, 0.06], [0.42, 0.43, 0.45], [0.3, 0.024, 0.028], [0.012, 0.012, 0.014], [0.03, 0.1, 0.18],
]
const HAULER_PAINTS: readonly (readonly [number, number, number])[] = [[0.4, 0.24, 0.04], [0.19, 0.19, 0.2]]
const BOAT_PAINTS: readonly (readonly [number, number, number])[] = [[0.42, 0.42, 0.44], [0.05, 0.06, 0.09], [0.32, 0.03, 0.04]]

/**
 * Seeded modelled craft: spinners over the river and the avenue, haulers over the river, and cruise boats on it.
 * @returns the same craft on every call.
 */
export function splashFlyers(): SplashFlyer[] {
  const random = createRandom(0xf1e5)
  const flyers: SplashFlyer[] = []
  const lane = (
    origin: SplashVector, directionZ: number, count: number, span: number, speed: number, kind: SplashCraftKind,
  ): void => {
    const paints = kind === SPLASH_CRAFT.hauler ? HAULER_PAINTS : kind === SPLASH_CRAFT.boat ? BOAT_PAINTS : SPINNER_PAINTS
    for (let index = 0; index < count; index += 1) {
      flyers.push({
        origin, directionX: 0, directionZ, speed, span, kind,
        phase: (index + 0.15 + random() * 0.6) * span / count,
        bob: random() * Math.PI * 2,
        paint: paints[Math.floor(random() * paints.length)] ?? [0.05, 0.05, 0.05],
      })
    }
  }
  const course = (SPLASH_AVENUE.start + SPLASH_AVENUE.end) / 2
  const span = SPLASH_AVENUE.start - SPLASH_AVENUE.end
  // River lanes fly under the bridge deck; haulers pass between the deck and the arch.
  for (const [x, height] of [[132, 26], [300, 30], [430, 22]] as const) {
    lane({ x, y: height, z: course }, -1, 7, span, 24 + random() * 6, SPLASH_CRAFT.spinner)
    lane({ x: x + 18, y: height + 6, z: course }, 1, 7, span, 21 + random() * 6, SPLASH_CRAFT.spinner)
  }
  lane({ x: 236, y: 62, z: course }, -1, 4, span, 13, SPLASH_CRAFT.hauler)
  lane({ x: 256, y: 70, z: course }, 1, 4, span, 12, SPLASH_CRAFT.hauler)
  for (const height of [62, 78]) {
    lane({ x: -4, y: height, z: course }, -1, 5, span, 22 + random() * 5, SPLASH_CRAFT.spinner)
    lane({ x: 4, y: height + 3, z: course }, 1, 5, span, 20 + random() * 5, SPLASH_CRAFT.spinner)
  }
  for (const [x, direction] of [[196, -1], [262, 1], [384, -1]] as const) {
    lane({ x, y: 0, z: course }, direction, 4, span, 7 + random() * 2, SPLASH_CRAFT.boat)
  }
  return flyers
}

/**
 * Seeded light-only traffic: cars on the avenue and the bridge deck, and distant craft over both banks.
 * @returns the same vehicles on every call.
 */
export function splashTraffic(): SplashVehicle[] {
  const random = createRandom(0x5eed)
  const vehicles: SplashVehicle[] = []
  const lane = (
    origin: SplashVector, directionX: number, directionZ: number, count: number, span: number, speed: number, trail: number, radius: number,
  ): void => {
    for (let index = 0; index < count; index += 1) {
      const phase = (index + random() * 0.7) * span / count
      const bob = random() * Math.PI * 2
      // Cars carry a pair of lights 1.4 m apart that share one phase.
      for (const side of radius < 0.3 ? [-0.7, 0.7] : [0]) {
        const sideX = directionZ !== 0 ? side : 0
        const sideZ = directionX !== 0 ? side : 0
        vehicles.push({
          origin: { x: origin.x + sideX, y: origin.y, z: origin.z + sideZ }, directionX, directionZ, speed, span, phase, bob, trail, radius,
          headlight: directionZ > 0 || directionX < 0,
        })
      }
    }
  }
  const course = (SPLASH_AVENUE.start + SPLASH_AVENUE.end) / 2
  const span = SPLASH_AVENUE.start - SPLASH_AVENUE.end
  for (const x of [-6.6, -3.3]) lane({ x, y: 0.75, z: course }, 0, 1, 14, span, 13 + random() * 5, 1.4, 0.16)
  for (const x of [3.3, 6.6]) lane({ x, y: 0.75, z: course }, 0, -1, 14, span, 13 + random() * 5, 1.4, 0.15)
  const deckCentre = (SPLASH_BRIDGE.from + SPLASH_BRIDGE.to) / 2
  const deckSpan = SPLASH_BRIDGE.to - SPLASH_BRIDGE.from
  for (const offset of [-5, 5]) {
    lane({ x: deckCentre, y: SPLASH_BRIDGE.deck + 0.9, z: SPLASH_BRIDGE.z + offset }, offset < 0 ? 1 : -1, 0, 10, deckSpan, 15, 1.4, 0.18)
  }
  for (const [x, height] of [[-260, 150], [-420, 190], [-600, 230], [760, 120], [980, 160]] as const) {
    lane({ x, y: height, z: -500 }, 0, 1, 9, 2400, 34, 7, 0.45)
    lane({ x: x + 8, y: height + 5, z: -500 }, 0, -1, 9, 2400, 30, 7, 0.45)
  }
  return vehicles
}
