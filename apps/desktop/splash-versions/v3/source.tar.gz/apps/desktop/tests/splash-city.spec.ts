import { describe, expect, it } from 'vitest'
import {
  SPLASH_AVENUE, SPLASH_CAMPUS, SPLASH_CRAFT, SPLASH_FACADE, SPLASH_FORM, SPLASH_HERO, SPLASH_LANDMARKS,
  SPLASH_LEANING_TOWERS, SPLASH_MARK, SPLASH_MUSEUM, SPLASH_PROMENADE, SPLASH_RIVER, SPLASH_TANKS, splashCameraAt,
  splashCityLayout, splashFlyers, splashPhase, splashTraffic, type SplashTier,
} from '../src/client/splash-city.ts'

const layout = splashCityLayout()
const insidePlot = (tier: SplashTier, plot: { minX: number; maxX: number; minZ: number; maxZ: number }, margin: number): boolean =>
  tier.x - tier.width / 2 >= plot.minX - margin && tier.x + tier.width / 2 <= plot.maxX + margin
  && tier.z - tier.depth / 2 >= plot.minZ - margin && tier.z + tier.depth / 2 <= plot.maxZ + margin

describe('splash riverside layout', () => {
  it('generates the same mixed city on every call', () => {
    expect(splashCityLayout()).toEqual(layout)
    expect(layout.tiers.length).toBeGreaterThan(400)
    expect(layout.tiers.some(tier => tier.form === SPLASH_FORM.round)).toBe(true)
    expect(layout.tiers.some(tier => tier.facade === SPLASH_FACADE.terrace)).toBe(true)
    expect(layout.screens.length).toBeGreaterThan(0)
    for (const tier of layout.tiers) {
      expect(tier.width).toBeGreaterThan(0)
      expect(tier.depth).toBeGreaterThan(0)
      expect(tier.height).toBeGreaterThan(0)
      if (tier.form === SPLASH_FORM.box) expect(tier.taper).toBe(1)
    }
  })

  it('keeps every building off the avenue, the riverside park, and the river', () => {
    for (const tier of layout.tiers) {
      const west = tier.x + tier.width / 2 <= -SPLASH_AVENUE.halfWidth - 2
      const east = tier.x - tier.width / 2 >= SPLASH_RIVER.east
      expect(west || east).toBe(true)
    }
  })

  it('builds Building 8 from terrace modules inside its plot, with the projector deck on its highest roof', () => {
    const hero = layout.tiers.filter(tier => tier.facade === SPLASH_FACADE.terrace && insidePlot(tier, SPLASH_CAMPUS.z, 8))
    expect(hero.length).toBeGreaterThan(20)
    expect(Math.max(...hero.map(tier => tier.y + tier.height))).toBe(SPLASH_HERO.deck)
    const deck = hero.find(tier => Math.abs(tier.x - SPLASH_HERO.x) < 1 && Math.abs(tier.z - SPLASH_HERO.z) < 1)
    expect(deck && deck.y + deck.height).toBe(SPLASH_HERO.deck)
    expect(SPLASH_MARK.x).toBe(SPLASH_HERO.x)
    expect(SPLASH_MARK.z).toBe(SPLASH_HERO.z)
    expect(SPLASH_MARK.y - SPLASH_MARK.width * 0.35).toBeGreaterThan(SPLASH_HERO.deck + 20)
  })

  it('keeps district buildings out of the campus plots and places the riverside landmarks where they belong', () => {
    for (const tier of layout.tiers.filter(tier => tier.facade !== SPLASH_FACADE.terrace)) {
      for (const plot of Object.values(SPLASH_CAMPUS)) {
        const apart = tier.x + tier.width / 2 < plot.minX || tier.x - tier.width / 2 > plot.maxX
          || tier.z + tier.depth / 2 < plot.minZ || tier.z - tier.depth / 2 > plot.maxZ
        expect(apart).toBe(true)
      }
    }
    for (const tower of SPLASH_LEANING_TOWERS) {
      expect(tower.x).toBeGreaterThan(SPLASH_CAMPUS.x.minX)
      expect(tower.x).toBeLessThan(SPLASH_CAMPUS.x.maxX)
      expect(tower.z).toBeGreaterThan(SPLASH_CAMPUS.x.minZ)
      expect(tower.z).toBeLessThan(SPLASH_CAMPUS.x.maxZ)
    }
    for (const tank of [...SPLASH_TANKS, ...SPLASH_MUSEUM]) {
      expect(tank.x).toBeGreaterThan(SPLASH_PROMENADE.from)
      expect(tank.x).toBeLessThan(SPLASH_PROMENADE.to)
    }
    for (const landmark of Object.values(SPLASH_LANDMARKS)) expect(landmark.x).toBeGreaterThan(SPLASH_RIVER.east)
  })
})

describe('splash camera and phases', () => {
  it('glides low over the river, then rests above the avenue beside Building 8', () => {
    const start = splashCameraAt(0)
    const end = splashCameraAt(1)
    expect(start.position.y).toBeLessThan(10)
    expect(start.position.x).toBeGreaterThan(SPLASH_RIVER.west)
    expect(start.position.x).toBeLessThan(SPLASH_RIVER.east)
    expect(end.position.y).toBeGreaterThan(SPLASH_HERO.deck + 30)
    expect(splashCameraAt(-1)).toEqual(start)
    expect(splashCameraAt(2)).toEqual(end)
  })

  it('never passes through a building or below 3 m', () => {
    const collisions: string[] = []
    for (let step = 0; step <= 600; step += 1) {
      const { position } = splashCameraAt(step / 600)
      if (position.y <= 3) collisions.push(`${step}: below 3 m`)
      const hit = layout.tiers.find(tier =>
        Math.abs(position.x - tier.x) < tier.width / 2 + 4 && Math.abs(position.z - tier.z) < tier.depth / 2 + 4
        && position.y > tier.y - 4 && position.y < tier.y + tier.height + 4)
      if (hit) collisions.push(`${step}: inside the tier at ${hit.x}, ${hit.z}`)
    }
    expect(collisions).toEqual([])
  })

  it('eases a phase from 0 to 1 and holds outside it', () => {
    expect(splashPhase(0, 100, 200)).toBe(0)
    expect(splashPhase(200, 100, 200)).toBe(0.5)
    expect(splashPhase(250, 100, 200)).toBeGreaterThan(0.5)
    expect(splashPhase(900, 100, 200)).toBe(1)
  })
})

describe('splash traffic', () => {
  it('builds the same craft on every call, and craft sharing a lane share its speed', () => {
    const flyers = splashFlyers()
    expect(splashFlyers()).toEqual(flyers)
    for (const kind of Object.values(SPLASH_CRAFT)) expect(flyers.some(flyer => flyer.kind === kind)).toBe(true)
    const speeds = new Map<string, number>()
    for (const flyer of flyers) {
      const lane = `${flyer.origin.x},${flyer.origin.y},${flyer.origin.z},${flyer.directionX},${flyer.directionZ}`
      expect(speeds.get(lane) ?? flyer.speed).toBe(flyer.speed)
      speeds.set(lane, flyer.speed)
    }
    expect(splashTraffic()).toEqual(splashTraffic())
  })

  it('keeps boats on the river surface between the banks', () => {
    for (const boat of splashFlyers().filter(flyer => flyer.kind === SPLASH_CRAFT.boat)) {
      expect(boat.origin.y).toBe(0)
      expect(boat.origin.x).toBeGreaterThan(SPLASH_RIVER.west + 20)
      expect(boat.origin.x).toBeLessThan(SPLASH_RIVER.east - 20)
    }
  })
})
