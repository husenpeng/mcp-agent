/** Procedural WebGL night city with a projector-lit Tomato mark for the desktop splash. */

import * as THREE from 'three'
import { Reflector } from 'three/addons/objects/Reflector.js'
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js'
import { SPLASH_TIMINGS } from './splash-timeline.ts'
import {
  SPLASH_AVENUE, SPLASH_AVENUE_FRONTAGE, SPLASH_LAMPS, SPLASH_MARK, SPLASH_TOWER,
  splashCameraAt, splashCityLayout, splashPhase, splashTraffic, type SplashCityLayout,
} from './splash-city.ts'
import {
  BEAM_FRAGMENT_GLSL, BEAM_VERTEX_GLSL, FACADE_FRAGMENT_GLSL, FACADE_VERTEX_GLSL, GROUND_FRAGMENT_GLSL,
  GROUND_VERTEX_GLSL, LIGHT_FRAGMENT_GLSL, MARK_FRAGMENT_GLSL, MARK_VERTEX_GLSL, PANEL_FRAGMENT_GLSL,
  PANEL_VERTEX_GLSL, POINT_LIGHT_VERTEX_GLSL, RAIN_VERTEX_GLSL, SKY_FRAGMENT_GLSL, SKY_VERTEX_GLSL,
  SOLID_FRAGMENT_GLSL, SOLID_VERTEX_GLSL, TRAFFIC_VERTEX_GLSL,
} from './splash-glsl.ts'
import {
  createIgnitionTexture, createMarkGeometry, MARK_FIELD_SIZE, markIgnitionField, markIgnitionSeed, rasterizeMark,
} from './splash-mark.ts'
import { createScreenAtlas, createSignAtlas } from './splash-signage.ts'
import { createSplashPost } from './splash-post.ts'

/** Lifecycle of the running scene, owned by the splash document. */
export interface SplashScene {
  /** Jump to the resting composition with the mark lit. */
  finish(): void
  /** Stop rendering and release GPU resources. */
  stop(): void
}

/** Uniform objects shared by every city material; assigning `.value` updates all of them. */
interface SharedUniforms {
  readonly uTime: { value: number }
  readonly uHoloPos: { value: THREE.Vector3 }
  readonly uHolo: { value: number }
  readonly uFogDensity: { value: number }
  readonly uFogFalloff: { value: number }
}

/** Animated controls of the landmark crown, beam, and mark. */
interface Landmark {
  readonly objects: readonly THREE.Object3D[]
  /**
   * Apply one timeline sample.
   * @param timeline - milliseconds on the splash timeline.
   * @param ambient - free-running seconds for idle motion.
   */
  update(timeline: number, ambient: number): void
  dispose(): void
}

const staticScene: SplashScene = { finish: () => {}, stop: () => {} }

/** Rain stays out of the mirrored ground render. */
const RAIN_LAYER = 1
const CLEAR_COLOR = 0x030105
const MAX_PIXEL_RATIO = 1.5
const MIN_PIXEL_RATIO = 0.8

function cityMaterial(
  shared: SharedUniforms,
  vertexShader: string,
  fragmentShader: string,
  uniforms: Record<string, { value: unknown }> = {},
  options: THREE.ShaderMaterialParameters = {},
): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({ ...options, vertexShader, fragmentShader, uniforms: { ...shared, ...uniforms } })
}

function solidMaterial(shared: SharedUniforms, albedo: number, sheen: number, emissive = new THREE.Color(0, 0, 0)): THREE.ShaderMaterial {
  return cityMaterial(shared, SOLID_VERTEX_GLSL, SOLID_FRAGMENT_GLSL, {
    uAlbedo: { value: new THREE.Color(albedo, albedo * 0.96, albedo * 1.04) },
    uEmissive: { value: emissive },
    uSheen: { value: sheen },
  })
}

/** Unit quad instanced once per entry of `attributes`. */
function instancedQuad(count: number, attributes: Record<string, THREE.InstancedBufferAttribute>): THREE.InstancedBufferGeometry {
  const quad = new THREE.PlaneGeometry(1, 1)
  const geometry = new THREE.InstancedBufferGeometry()
  geometry.index = quad.index
  geometry.setAttribute('position', quad.getAttribute('position'))
  geometry.setAttribute('uv', quad.getAttribute('uv'))
  for (const [name, attribute] of Object.entries(attributes)) geometry.setAttribute(name, attribute)
  geometry.instanceCount = count
  return geometry
}

/** Light capsules size themselves in pixels, so each draw reads the pixel size of the target it renders into. */
function bindViewport(mesh: THREE.Mesh, material: THREE.ShaderMaterial, viewport: { value: THREE.Vector2 }): void {
  mesh.frustumCulled = false
  mesh.onBeforeRender = (renderer) => {
    const target = renderer.getRenderTarget()
    if (target === null) renderer.getDrawingBufferSize(viewport.value)
    else viewport.value.set(target.width, target.height)
    material.uniformsNeedUpdate = true
  }
}

function lightMesh(
  shared: SharedUniforms,
  viewport: { value: THREE.Vector2 },
  vertexShader: string,
  geometry: THREE.InstancedBufferGeometry,
  uniforms: Record<string, { value: unknown }> = {},
): THREE.Mesh {
  const material = cityMaterial(shared, vertexShader, LIGHT_FRAGMENT_GLSL, { uViewport: viewport, ...uniforms }, {
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    transparent: true,
  })
  const mesh = new THREE.Mesh(geometry, material)
  bindViewport(mesh, material, viewport)
  return mesh
}

function createCity(layout: SplashCityLayout, shared: SharedUniforms): THREE.Mesh {
  const box = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0)
  const geometry = new THREE.InstancedBufferGeometry()
  geometry.index = box.index
  geometry.setAttribute('position', box.getAttribute('position'))
  geometry.setAttribute('normal', box.getAttribute('normal'))
  const count = layout.tiers.length
  const centres = new Float32Array(count * 3)
  const sizes = new Float32Array(count * 3)
  const styles = new Float32Array(count * 4)
  const storefronts = new Float32Array(count)
  layout.tiers.forEach((tier, index) => {
    centres.set([tier.x, tier.y, tier.z], index * 3)
    sizes.set([tier.width, tier.height, tier.depth], index * 3)
    styles.set([tier.seed, tier.facade, tier.lit, tier.trim], index * 4)
    storefronts[index] = tier.storefront ? 1 : 0
  })
  geometry.setAttribute('aCenter', new THREE.InstancedBufferAttribute(centres, 3))
  geometry.setAttribute('aSize', new THREE.InstancedBufferAttribute(sizes, 3))
  geometry.setAttribute('aStyle', new THREE.InstancedBufferAttribute(styles, 4))
  geometry.setAttribute('aStorefront', new THREE.InstancedBufferAttribute(storefronts, 1))
  geometry.instanceCount = count
  const mesh = new THREE.Mesh(geometry, cityMaterial(shared, FACADE_VERTEX_GLSL, FACADE_FRAGMENT_GLSL))
  mesh.frustumCulled = false
  return mesh
}

function createGround(shared: SharedUniforms): Reflector {
  const reflector = new Reflector(new THREE.PlaneGeometry(2800, 2800), {
    textureWidth: 1,
    textureHeight: 1,
    clipBias: 0.003,
    color: 0xd9d3df,
    multisample: 4,
    shader: {
      name: 'SplashGround',
      uniforms: {
        color: { value: null },
        tDiffuse: { value: null },
        textureMatrix: { value: null },
        uStreet: { value: new THREE.Vector4(SPLASH_LAMPS.x, SPLASH_LAMPS.spacing, 0, SPLASH_AVENUE_FRONTAGE) },
        uAvenue: { value: new THREE.Vector2(SPLASH_AVENUE.start + 15, SPLASH_AVENUE.end - 10) },
      },
      vertexShader: GROUND_VERTEX_GLSL,
      fragmentShader: GROUND_FRAGMENT_GLSL,
    },
  })
  const material = reflector.material
  if (!(material instanceof THREE.ShaderMaterial)) throw new Error('splash: ground reflector has no shader material')
  // Reflector clones its shader uniforms; reattach the shared objects so one assignment drives every surface.
  Object.assign(material.uniforms, shared)
  const texture = reflector.getRenderTarget().texture
  texture.generateMipmaps = true
  texture.minFilter = THREE.LinearMipmapLinearFilter
  reflector.rotation.x = -Math.PI / 2
  reflector.position.set(0, 0, -300)
  return reflector
}

function createSky(shared: SharedUniforms): THREE.Mesh {
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(1600, 48, 24),
    cityMaterial(shared, SKY_VERTEX_GLSL, SKY_FRAGMENT_GLSL, {}, { side: THREE.BackSide, depthTest: false, depthWrite: false }),
  )
  sky.renderOrder = -1
  sky.frustumCulled = false
  sky.onBeforeRender = (_renderer, _scene, camera) => {
    sky.position.copy(camera.position)
    sky.updateMatrixWorld()
  }
  return sky
}

function placeBoxes(mesh: THREE.InstancedMesh, boxes: readonly { position: THREE.Vector3; scale: THREE.Vector3; yaw?: number }[]): THREE.InstancedMesh {
  const matrix = new THREE.Matrix4()
  const rotation = new THREE.Quaternion()
  const up = new THREE.Vector3(0, 1, 0)
  boxes.forEach((box, index) => {
    rotation.setFromAxisAngle(up, box.yaw ?? 0)
    mesh.setMatrixAt(index, matrix.compose(box.position, rotation, box.scale))
  })
  mesh.instanceMatrix.needsUpdate = true
  return mesh
}

/** Lamp post with an arm reaching toward the road along -X. */
function lampGeometry(): THREE.BufferGeometry {
  const height = SPLASH_LAMPS.height
  const parts = [
    new THREE.BoxGeometry(0.22, height, 0.22).translate(0, height / 2, 0),
    new THREE.BoxGeometry(2.4, 0.14, 0.16).translate(-1.15, height - 0.1, 0),
    new THREE.BoxGeometry(0.9, 0.2, 0.42).translate(-2.1, height - 0.25, 0),
  ]
  const merged = mergeGeometries(parts, false)
  for (const part of parts) part.dispose()
  if (merged === null) throw new Error('splash: lamp geometry could not be assembled')
  return merged
}

function lampPositions(): { x: number; z: number; side: -1 | 1 }[] {
  const lamps: { x: number; z: number; side: -1 | 1 }[] = []
  for (let z = SPLASH_AVENUE.start; z > SPLASH_AVENUE.end; z -= SPLASH_LAMPS.spacing) {
    lamps.push({ x: -SPLASH_LAMPS.x, z, side: -1 }, { x: SPLASH_LAMPS.x, z, side: 1 })
  }
  return lamps
}

function createProps(layout: SplashCityLayout, shared: SharedUniforms): THREE.Object3D[] {
  const metal = solidMaterial(shared, 0.05, 0.25)
  const units = placeBoxes(
    new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), metal, layout.roofUnits.length),
    layout.roofUnits.map(unit => ({
      position: new THREE.Vector3(unit.x, unit.y, unit.z),
      scale: new THREE.Vector3(unit.width, unit.height, unit.depth),
    })),
  )
  const masts = placeBoxes(
    new THREE.InstancedMesh(new THREE.CylinderGeometry(0.1, 0.22, 1, 6).translate(0, 0.5, 0), metal, layout.antennas.length),
    layout.antennas.map(mast => ({
      position: new THREE.Vector3(mast.x, mast.y, mast.z),
      scale: new THREE.Vector3(1, mast.height, 1),
    })),
  )
  const lamps = lampPositions()
  const posts = placeBoxes(
    new THREE.InstancedMesh(lampGeometry(), metal, lamps.length),
    lamps.map(lamp => ({
      position: new THREE.Vector3(lamp.x, 0, lamp.z),
      scale: new THREE.Vector3(1, 1, 1),
      yaw: lamp.side > 0 ? 0 : Math.PI,
    })),
  )
  const housings = placeBoxes(
    new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), metal, layout.signs.length + layout.screens.length),
    [
      ...layout.signs.map(sign => ({
        position: new THREE.Vector3(sign.x, sign.y + sign.height / 2, sign.z - 0.24),
        scale: new THREE.Vector3(sign.width + 0.26, sign.height + 0.26, 0.42),
      })),
      ...layout.screens.map(screen => ({
        position: new THREE.Vector3(
          screen.x - Math.sin(screen.yaw) * 0.25, screen.y, screen.z - Math.cos(screen.yaw) * 0.25,
        ),
        scale: new THREE.Vector3(screen.width + 0.5, screen.height + 0.5, 0.4),
        yaw: screen.yaw,
      })),
    ],
  )
  return [units, masts, posts, housings]
}

function createPointLights(layout: SplashCityLayout, shared: SharedUniforms, viewport: { value: THREE.Vector2 }): THREE.Mesh {
  const lights: { x: number; y: number; z: number; color: [number, number, number]; radius: number }[] = []
  for (const mast of layout.antennas) {
    lights.push({ x: mast.x, y: mast.y + mast.height, z: mast.z, color: [1.6, 0.08, 0.06], radius: 0.55 })
  }
  for (const lamp of lampPositions()) {
    lights.push({ x: lamp.x - lamp.side * 2.1, y: SPLASH_LAMPS.height - 0.42, z: lamp.z, color: [1.8, 1.25, 0.8], radius: 0.4 })
  }
  for (const [dx, dz] of [[-12, -12], [12, -12], [-12, 12], [12, 12]] as const) {
    lights.push({ x: SPLASH_TOWER.x + dx, y: SPLASH_TOWER.deck + 0.6, z: SPLASH_TOWER.z + dz, color: [1.8, 0.1, 0.08], radius: 0.6 })
  }
  const heads = new Float32Array(lights.length * 3)
  const colors = new Float32Array(lights.length * 4)
  lights.forEach((light, index) => {
    heads.set([light.x, light.y, light.z], index * 3)
    colors.set([...light.color, light.radius], index * 4)
  })
  return lightMesh(shared, viewport, POINT_LIGHT_VERTEX_GLSL, instancedQuad(lights.length, {
    aHead: new THREE.InstancedBufferAttribute(heads, 3),
    aLight: new THREE.InstancedBufferAttribute(colors, 4),
  }))
}

function createTraffic(shared: SharedUniforms, viewport: { value: THREE.Vector2 }): THREE.Mesh {
  const vehicles = splashTraffic()
  const lanes = new Float32Array(vehicles.length * 4)
  const motion = new Float32Array(vehicles.length * 4)
  const trails = new Float32Array(vehicles.length * 4)
  vehicles.forEach((vehicle, index) => {
    lanes.set([vehicle.origin.x, vehicle.origin.y, vehicle.origin.z, vehicle.speed], index * 4)
    motion.set([vehicle.directionX, vehicle.directionZ, vehicle.phase, vehicle.span], index * 4)
    trails.set([vehicle.trail, vehicle.radius, vehicle.headlight ? 1 : 0, 0], index * 4)
  })
  return lightMesh(shared, viewport, TRAFFIC_VERTEX_GLSL, instancedQuad(vehicles.length, {
    aLane: new THREE.InstancedBufferAttribute(lanes, 4),
    aMotion: new THREE.InstancedBufferAttribute(motion, 4),
    aTrail: new THREE.InstancedBufferAttribute(trails, 4),
  }))
}

function createRain(shared: SharedUniforms, viewport: { value: THREE.Vector2 }): THREE.Mesh {
  const count = 2400
  const drops = new Float32Array(count * 4)
  let state = 0x2a17
  for (let index = 0; index < drops.length; index += 1) {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0
    drops[index] = state / 4294967296
  }
  const rain = lightMesh(shared, viewport, RAIN_VERTEX_GLSL, instancedQuad(count, {
    aDrop: new THREE.InstancedBufferAttribute(drops, 4),
  }), { uRainBox: { value: new THREE.Vector3(56, 40, 56) }, uRain: { value: 1 } })
  rain.layers.set(RAIN_LAYER)
  return rain
}

function createPanels(
  shared: SharedUniforms,
  panels: readonly { x: number; y: number; z: number; yaw: number; width: number; height: number; slot: number }[],
  atlas: { texture: THREE.Texture; grid: THREE.Vector2 },
  glow: number,
  screen: boolean,
): THREE.Mesh {
  const placement = new Float32Array(panels.length * 4)
  const shape = new Float32Array(panels.length * 4)
  panels.forEach((panel, index) => {
    placement.set([panel.x, panel.y, panel.z, panel.yaw], index * 4)
    shape.set([panel.width, panel.height, panel.slot, glow], index * 4)
  })
  const mesh = new THREE.Mesh(
    instancedQuad(panels.length, {
      aPanel: new THREE.InstancedBufferAttribute(placement, 4),
      aShape: new THREE.InstancedBufferAttribute(shape, 4),
    }),
    cityMaterial(shared, PANEL_VERTEX_GLSL, PANEL_FRAGMENT_GLSL, {
      uAtlas: { value: atlas.texture },
      uGrid: { value: atlas.grid },
      uScreen: { value: screen ? 1 : 0 },
    }),
  )
  mesh.frustumCulled = false
  return mesh
}

/** Crown ring, projector, beams, and the mark whose strokes light up from the beam's contact point. */
function createLandmark(shared: SharedUniforms): Landmark {
  const { x, z, deck } = SPLASH_TOWER
  const metal = solidMaterial(shared, 0.04, 0.4)
  const ringGlow = new THREE.Color(0, 0, 0)
  const ring = new THREE.Mesh(new THREE.TorusGeometry(13.5, 0.5, 12, 160), solidMaterial(shared, 0.03, 0.2, ringGlow))
  ring.rotation.x = Math.PI / 2
  ring.position.set(x, deck + 0.9, z)
  const innerGlow = new THREE.Color(0, 0, 0)
  const innerRing = new THREE.Mesh(new THREE.TorusGeometry(5.6, 0.22, 10, 96), solidMaterial(shared, 0.03, 0.2, innerGlow))
  innerRing.rotation.x = Math.PI / 2
  innerRing.position.set(x, deck + 2.5, z)
  const housing = new THREE.Mesh(new THREE.CylinderGeometry(3.1, 4.4, 2.7, 48), metal)
  housing.position.set(x, deck + 1.35, z)
  const lensGlow = new THREE.Color(0, 0, 0)
  const lens = new THREE.Mesh(new THREE.CircleGeometry(2.7, 48), solidMaterial(shared, 0.02, 0.1, lensGlow))
  lens.rotation.x = -Math.PI / 2
  lens.position.set(x, deck + 2.72, z)
  const fins = placeBoxes(
    new THREE.InstancedMesh(new THREE.BoxGeometry(0.34, 3.2, 3.4).translate(0, 1.6, 0), metal, 12),
    Array.from({ length: 12 }, (_, index) => {
      const angle = index / 12 * Math.PI * 2
      return {
        position: new THREE.Vector3(x + Math.sin(angle) * 9.4, deck, z + Math.cos(angle) * 9.4),
        scale: new THREE.Vector3(1, 1, 1),
        yaw: angle,
      }
    }),
  )

  const markGeometry = createMarkGeometry(SPLASH_MARK.width)
  const mask = rasterizeMark(MARK_FIELD_SIZE)
  const field = createIgnitionTexture(markIgnitionField(mask, MARK_FIELD_SIZE, markIgnitionSeed(mask, MARK_FIELD_SIZE)), MARK_FIELD_SIZE)
  const ignite = { value: 0 }
  const dormant = { value: 0 }
  const mark = new THREE.Mesh(markGeometry, cityMaterial(shared, MARK_VERTEX_GLSL, MARK_FRAGMENT_GLSL, {
    uField: { value: field },
    uIgnite: ignite,
    uDormant: dormant,
  }))
  const rest = splashCameraAt(1).position
  // The mark leans toward the resting camera so its face reads without foreshortening.
  const tilt = Math.atan2(SPLASH_MARK.y - rest.y, rest.z - SPLASH_MARK.z)
  mark.position.set(SPLASH_MARK.x, SPLASH_MARK.y, SPLASH_MARK.z)
  mark.rotation.x = tilt

  const lensTop = deck + 2.75
  const markBottom = SPLASH_MARK.y + (markGeometry.boundingBox?.min.y ?? -SPLASH_MARK.width * 0.3) * Math.cos(tilt)
  const beam = (bottomRadius: number, topRadius: number, top: number, strength: number): { mesh: THREE.Mesh; strength: number; power: { value: number }; reach: { value: number } } => {
    const power = { value: 0 }
    const reach = { value: 0 }
    const height = top - lensTop
    const mesh = new THREE.Mesh(
      new THREE.CylinderGeometry(topRadius, bottomRadius, height, 64, 1, true),
      cityMaterial(shared, BEAM_VERTEX_GLSL, BEAM_FRAGMENT_GLSL, { uBeam: power, uBeamReach: reach }, {
        blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, side: THREE.DoubleSide,
      }),
    )
    mesh.position.set(x, lensTop + height / 2, z)
    return { mesh, strength, power, reach }
  }
  const core = beam(1.5, 1.1, markBottom + 0.6, 1)
  const volume = beam(3.4, SPLASH_MARK.width * 0.46, SPLASH_MARK.y, 0.32)

  return {
    objects: [ring, innerRing, housing, lens, fins, core.mesh, volume.mesh, mark],
    update: (timeline, ambient) => {
      const { projectorMs, projectorRampMs, beamMs, beamRampMs, igniteMs, igniteRampMs } = SPLASH_TIMINGS
      const projector = splashPhase(timeline, projectorMs, projectorRampMs)
      const reach = splashPhase(timeline, beamMs, beamRampMs)
      const lit = splashPhase(timeline, igniteMs, igniteRampMs)
      ringGlow.setRGB(2.3 * projector, 0.12 * projector, 0.09 * projector)
      innerGlow.setRGB(0.25 * projector, 1.2 * projector, 1.7 * projector)
      lensGlow.setRGB(3.2 * projector, 0.9 * projector, 0.7 * projector)
      for (const part of [core, volume]) {
        part.power.value = part.strength * projector * (1 - 0.35 * lit)
        part.reach.value = reach * 1.04
      }
      dormant.value = splashPhase(timeline, beamMs + beamRampMs * 0.6, 500)
      ignite.value = lit
      const settle = splashPhase(timeline, igniteMs + igniteRampMs - 200, 1600)
      mark.rotation.y = 0.16 * Math.sin(ambient * 0.42) * settle
      shared.uHolo.value = 0.22 * projector + 0.78 * lit
    },
    dispose: () => { field.dispose() },
  }
}

function disposeScene(scene: THREE.Scene): void {
  scene.traverse(object => {
    if (!(object instanceof THREE.Mesh)) return
    if (object instanceof Reflector) {
      object.dispose()
      object.geometry.dispose()
      return
    }
    object.geometry.dispose()
    const materials: THREE.Material[] = Array.isArray(object.material) ? object.material : [object.material]
    for (const material of materials) {
      if (material instanceof THREE.ShaderMaterial) {
        for (const uniform of Object.values(material.uniforms)) {
          const value: unknown = uniform.value
          if (value instanceof THREE.CanvasTexture) value.dispose()
        }
      }
      material.dispose()
    }
  })
}

function renderScene(canvas: HTMLCanvasElement, reducedMotion: boolean, onReady: () => void): SplashScene {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance', stencil: false })
  let shaderFailed = false
  renderer.debug.onShaderError = (gl, _program, vertexShader, fragmentShader) => {
    shaderFailed = true
    console.error('Tomato splash: shader compilation failed', gl.getShaderInfoLog(vertexShader), gl.getShaderInfoLog(fragmentShader))
  }
  renderer.setClearColor(CLEAR_COLOR, 1)
  let pixelRatio = Math.min(MAX_PIXEL_RATIO, window.devicePixelRatio || 1)
  renderer.setPixelRatio(pixelRatio)

  const shared: SharedUniforms = {
    uTime: { value: 0 },
    uHoloPos: { value: new THREE.Vector3(SPLASH_MARK.x, SPLASH_MARK.y, SPLASH_MARK.z) },
    uHolo: { value: 0 },
    uFogDensity: { value: 0.0034 },
    uFogFalloff: { value: 0.0125 },
  }
  const viewport = { value: new THREE.Vector2(1, 1) }
  const scene = new THREE.Scene()
  const camera = new THREE.PerspectiveCamera(60, 1, 0.3, 4000)
  camera.layers.enable(RAIN_LAYER)

  const layout = splashCityLayout()
  const anisotropy = renderer.capabilities.getMaxAnisotropy()
  const ground = createGround(shared)
  ground.getReflectionCamera(camera).layers.disable(RAIN_LAYER)
  const landmark = createLandmark(shared)
  scene.add(
    createSky(shared),
    ground,
    createCity(layout, shared),
    ...createProps(layout, shared),
    createPanels(shared, layout.signs.map(sign => ({ ...sign, y: sign.y + sign.height / 2, yaw: 0 })), createSignAtlas(anisotropy), 1.45, false),
    createPanels(shared, layout.screens, createScreenAtlas(anisotropy), 1.0, true),
    ...landmark.objects,
    createPointLights(layout, shared, viewport),
    createTraffic(shared, viewport),
    createRain(shared, viewport),
  )
  const post = createSplashPost(renderer, scene, camera)

  let origin = 0
  let started = false
  let skipped = false
  let stopped = false
  let frame = 0
  let samples = 0
  let slowSamples = 0
  let lastStamp = 0
  let adapted = false

  const resize = (): void => {
    // A hidden window can report zero size; zero-sized attachments leave every target incomplete.
    const width = Math.max(1, window.innerWidth)
    const height = Math.max(1, window.innerHeight)
    renderer.setPixelRatio(pixelRatio)
    renderer.setSize(width, height, false)
    post.setSize(width, height, pixelRatio)
    ground.getRenderTarget().setSize(Math.max(1, Math.round(width * pixelRatio * 0.5)), Math.max(1, Math.round(height * pixelRatio * 0.5)))
    camera.aspect = width / height
    camera.updateProjectionMatrix()
    // Resizing clears the canvas; the reduced-motion frame has no loop to repaint it.
    if (started && reducedMotion && !stopped) draw(performance.now())
  }
  const timelineAt = (now: number): number => (skipped || reducedMotion ? SPLASH_TIMINGS.holdMs : Math.min(SPLASH_TIMINGS.holdMs, now - origin))
  const pose = (timeline: number): void => {
    const shot = splashCameraAt(timeline / SPLASH_TIMINGS.cameraMs)
    camera.position.set(shot.position.x, shot.position.y, shot.position.z)
    camera.fov = shot.fov
    camera.updateProjectionMatrix()
    camera.lookAt(shot.target.x, shot.target.y, shot.target.z)
  }
  const draw = (now: number): void => {
    const timeline = timelineAt(now)
    const ambient = now / 1000
    shared.uTime.value = ambient
    post.time.value = ambient
    pose(timeline)
    landmark.update(timeline, ambient)
    post.exposure.value = splashPhase(timeline, 0, SPLASH_TIMINGS.fadeInMs)
    post.composer.render()
  }
  // One downgrade when the first second runs below ~42 fps; repeated switching would itself read as flicker.
  const adapt = (stamp: number): void => {
    if (adapted) return
    if (lastStamp > 0) {
      samples += 1
      if (samples > 8 && stamp - lastStamp > 24) slowSamples += 1
    }
    lastStamp = stamp
    if (samples < 68) return
    adapted = true
    if (slowSamples > 30 && pixelRatio > MIN_PIXEL_RATIO) {
      pixelRatio = Math.max(MIN_PIXEL_RATIO, pixelRatio * 0.72)
      resize()
    }
  }
  const tick = (stamp: number): void => {
    if (stopped) return
    frame = requestAnimationFrame(tick)
    draw(performance.now())
    adapt(stamp)
  }
  const start = (): void => {
    if (stopped) return
    if (shaderFailed) throw new Error('splash: a city shader failed to compile')
    origin = performance.now()
    started = true
    onReady()
    if (reducedMotion) draw(origin)
    else frame = requestAnimationFrame(tick)
  }
  const fallback = (error: unknown): void => {
    console.error('Tomato splash: WebGL scene failed; using the static brand.', error)
    stopped = true
    cancelAnimationFrame(frame)
    document.documentElement.dataset.scene = 'fallback'
    if (!started) {
      started = true
      onReady()
    }
  }

  window.addEventListener('resize', resize)
  resize()
  pose(reducedMotion ? SPLASH_TIMINGS.holdMs : 0)
  // Compile every program before the clock starts, so slow shader translation cannot skip the opening.
  // Programs depend on the output color space, so they compile against the composer's linear scene target.
  renderer.setRenderTarget(post.composer.renderTarget1)
  const warmUp = renderer.compileAsync(scene, camera)
  renderer.setRenderTarget(null)
  warmUp
    .then(() => {
      if (stopped) return
      post.exposure.value = 0
      post.composer.render()
      start()
    })
    .catch(fallback)

  return {
    finish: () => {
      skipped = true
      if (started && reducedMotion && !stopped) draw(performance.now())
    },
    stop: () => {
      stopped = true
      cancelAnimationFrame(frame)
      window.removeEventListener('resize', resize)
      landmark.dispose()
      disposeScene(scene)
      post.dispose()
      renderer.dispose()
    },
  }
}

/**
 * Start the procedural city, falling back to the static local brand when WebGL is unavailable.
 * @param canvas - target WebGL canvas; null selects the static fallback.
 * @param reducedMotion - render only the composed final frame when true.
 * @param onReady - called once when the timeline starts: after shader warm-up, or immediately on fallback.
 * @returns final-frame and disposal actions owned by the splash document.
 */
export function startSplashScene(canvas: HTMLCanvasElement | null, reducedMotion: boolean, onReady: () => void): SplashScene {
  if (canvas === null) {
    document.documentElement.dataset.scene = 'fallback'
    onReady()
    return staticScene
  }
  try {
    return renderScene(canvas, reducedMotion, onReady)
  } catch (error) {
    console.error('Tomato splash: WebGL initialization failed; using the static brand.', error)
    document.documentElement.dataset.scene = 'fallback'
    onReady()
    return staticScene
  }
}
