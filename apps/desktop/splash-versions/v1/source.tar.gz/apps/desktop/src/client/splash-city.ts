/** Deterministic layout, camera path, and traffic for the WebGL launch city; no DOM or WebGL access. */

/** A point in scene metres. */
export interface SplashVector {
  readonly x: number
  readonly y: number
  readonly z: number
}

/** Facade families resolved by the city shader. */
export const SPLASH_FACADE = { glass: 0, panel: 1, ribbon: 2, hero: 3 } as const

/** One facade family. */
export type SplashFacade = typeof SPLASH_FACADE[keyof typeof SPLASH_FACADE]

/** Steady accent lighting resolved by the city shader. */
export const SPLASH_TRIM = { none: 0, redCorners: 1, cyanCorners: 2, crownBand: 3 } as const

/** One accent lighting choice. */
export type SplashTrim = typeof SPLASH_TRIM[keyof typeof SPLASH_TRIM]

/** Axis-aligned box: centre `x`/`z`, base height `y`, and extents in metres. */
export interface SplashBox {
  readonly x: number
  readonly y: number
  readonly z: number
  readonly width: number
  readonly height: number
  readonly depth: number
}

/** One building tier and the facade parameters the city shader reads. */
export interface SplashTier extends SplashBox {
  /** Stable per-building hash input in [0, 1). */
  readonly seed: number
  readonly facade: SplashFacade
  /** Share of rooms with their lights on, in [0, 1]. */
  readonly lit: number
  readonly trim: SplashTrim
  /** Shop fronts occupy the street-level band facing the avenue. */
  readonly storefront: boolean
}

/** Vertical neon blade sign projecting over the avenue; its artwork faces +Z. */
export interface SplashSign {
  readonly x: number
  /** Height of the sign's lower edge. */
  readonly y: number
  readonly z: number
  readonly width: number
  readonly height: number
  /** Artwork slot in the sign atlas, below `SPLASH_SIGN_SLOTS`. */
  readonly slot: number
}

/** Advertising screen centred on `x`/`y`/`z`; `yaw` turns its +Z face around the vertical axis. */
export interface SplashScreen {
  readonly x: number
  readonly y: number
  readonly z: number
  readonly width: number
  readonly height: number
  readonly yaw: number
  /** Artwork slot in the screen atlas, below `SPLASH_SCREEN_SLOTS`. */
  readonly slot: number
}

/** Roof mast standing on `y`, with a steady obstruction light at its tip. */
export interface SplashAntenna {
  readonly x: number
  readonly y: number
  readonly z: number
  readonly height: number
}

/** The complete deterministic city. */
export interface SplashCityLayout {
  readonly tiers: readonly SplashTier[]
  readonly roofUnits: readonly SplashBox[]
  readonly antennas: readonly SplashAntenna[]
  readonly signs: readonly SplashSign[]
  readonly screens: readonly SplashScreen[]
}

/** Camera position, look-at target, and vertical field of view in degrees. */
export interface SplashCameraPose {
  readonly position: SplashVector
  readonly target: SplashVector
  readonly fov: number
}

/** One light trail looping along a straight lane. */
export interface SplashVehicle {
  /** Lane anchor; the vehicle loops within `span / 2` metres of it along `direction`. */
  readonly origin: SplashVector
  /** Unit horizontal travel direction. */
  readonly directionX: number
  readonly directionZ: number
  /** Metres per second. */
  readonly speed: number
  /** Initial offset along the loop, in metres. */
  readonly phase: number
  /** Loop length in metres. */
  readonly span: number
  /** Trail length behind the light, in metres. */
  readonly trail: number
  /** Light radius in metres. */
  readonly radius: number
  /** Headlights face the viewer's end of the avenue; tail lights face away. */
  readonly headlight: boolean
}

/** Artwork slots drawn into the blade-sign atlas. */
export const SPLASH_SIGN_SLOTS = 8

/** Artwork slots drawn into the screen atlas. */
export const SPLASH_SCREEN_SLOTS = 4

/** Distance from the avenue centreline to the first building line. */
export const SPLASH_AVENUE_FRONTAGE = 17

/** Avenue extent along Z; the landmark plaza begins past `end`. */
export const SPLASH_AVENUE = { start: 175, end: -205 } as const

/** Street lamps stand at ±`x` every `spacing` metres along the avenue. */
export const SPLASH_LAMPS = { x: 12.4, spacing: 26, height: 9.5 } as const

/** Landmark tower closing the avenue; `deck` is the crown deck height the projector stands on. */
export const SPLASH_TOWER = { x: 0, z: -238, deck: 150 } as const

/** Centre and width of the projected Tomato mark above the landmark tower. */
export const SPLASH_MARK = { x: 0, y: 178, z: -238, width: 48 } as const

interface CameraKey extends SplashCameraPose {
  /** Share of the camera move, in [0, 1]. */
  readonly at: number
}

/** Street-level glide, upward crane, and the resting composition with the mark in the upper third. */
const CAMERA_KEYS: readonly CameraKey[] = [
  { at: 0, position: { x: 0, y: 5.2, z: 130 }, target: { x: 0, y: 17, z: 20 }, fov: 62 },
  { at: 0.3, position: { x: 0.4, y: 8.5, z: 62 }, target: { x: 0, y: 40, z: -110 }, fov: 58 },
  { at: 0.54, position: { x: -0.5, y: 36, z: 14 }, target: { x: 0, y: 104, z: -210 }, fov: 52 },
  { at: 0.78, position: { x: 0.3, y: 116, z: -38 }, target: { x: 0, y: 150, z: -238 }, fov: 44 },
  { at: 1, position: { x: 0, y: 152, z: -70 }, target: { x: 0, y: 157, z: -238 }, fov: 40 },
]

function createRandom(seed: number): () => number {
  let state = seed | 0
  return () => {
    state = (state + 0x6d2b79f5) | 0
    let value = Math.imul(state ^ (state >>> 15), 1 | state)
    value = (value + Math.imul(value ^ (value >>> 7), 61 | value)) ^ value
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296
  }
}

/** Cubic Hermite blend of one scalar between two keys. */
function hermite(from: number, to: number, fromSlope: number, toSlope: number, span: number, t: number): number {
  const t2 = t * t
  const t3 = t2 * t
  return (2 * t3 - 3 * t2 + 1) * from + (t3 - 2 * t2 + t) * span * fromSlope
    + (-2 * t3 + 3 * t2) * to + (t3 - t2) * span * toSlope
}

/** Catmull-Rom slope at key `index`; the first key keeps its travel speed and the last key comes to rest. */
function keySlope(read: (key: CameraKey) => number, index: number): number {
  const last = CAMERA_KEYS.length - 1
  if (index >= last) return 0
  const before = CAMERA_KEYS[Math.max(0, index - 1)]
  const after = CAMERA_KEYS[index + 1]
  if (before === undefined || after === undefined) return 0
  return (read(after) - read(before)) / (after.at - before.at)
}

/**
 * Sample the continuous crane shot.
 * @param progress - share of the camera move; values outside [0, 1] clamp to the first or resting pose.
 * @returns the camera pose at that point of the move.
 */
export function splashCameraAt(progress: number): SplashCameraPose {
  const at = Math.min(1, Math.max(0, progress))
  let index = 0
  while (index < CAMERA_KEYS.length - 2 && (CAMERA_KEYS[index + 1]?.at ?? 1) < at) index += 1
  const from = CAMERA_KEYS[index]
  const to = CAMERA_KEYS[index + 1]
  if (from === undefined || to === undefined) throw new Error('splash: camera keys are incomplete')
  const span = to.at - from.at
  const t = (at - from.at) / span
  const blend = (read: (key: CameraKey) => number): number =>
    hermite(read(from), read(to), keySlope(read, index), keySlope(read, index + 1), span, t)
  return {
    position: { x: blend(key => key.position.x), y: blend(key => key.position.y), z: blend(key => key.position.z) },
    target: { x: blend(key => key.target.x), y: blend(key => key.target.y), z: blend(key => key.target.z) },
    fov: blend(key => key.fov),
  }
}

/**
 * Eased share of a timeline phase.
 * @param elapsedMs - milliseconds since document start.
 * @param startMs - phase start in milliseconds.
 * @param durationMs - phase length in milliseconds.
 * @returns 0 before the phase, 1 after it, and a smoothstep-eased value between.
 */
export function splashPhase(elapsedMs: number, startMs: number, durationMs: number): number {
  const value = Math.min(1, Math.max(0, (elapsedMs - startMs) / durationMs))
  return value * value * (3 - 2 * value)
}

/** Lowest camera height while the camera crosses `z`, or undefined where the camera never travels. */
function cameraHeightNear(z: number): number | undefined {
  let height: number | undefined
  for (let step = 0; step <= 400; step += 1) {
    const pose = splashCameraAt(step / 400)
    if (Math.abs(pose.position.z - z) > 6) continue
    height = Math.min(height ?? Infinity, pose.position.y)
  }
  return height
}

interface CityDraft {
  readonly tiers: SplashTier[]
  readonly roofUnits: SplashBox[]
  readonly antennas: SplashAntenna[]
  readonly signs: SplashSign[]
  readonly screens: SplashScreen[]
}

interface Plot {
  readonly x: number
  readonly z: number
  readonly width: number
  readonly depth: number
  readonly height: number
  readonly storefront: boolean
}

function pickFacade(random: () => number): SplashFacade {
  const value = random()
  if (value < 0.46) return SPLASH_FACADE.glass
  if (value < 0.78) return SPLASH_FACADE.panel
  return SPLASH_FACADE.ribbon
}

function pickTrim(random: () => number): SplashTrim {
  const value = random()
  if (value < 0.09) return SPLASH_TRIM.redCorners
  if (value < 0.15) return SPLASH_TRIM.cyanCorners
  if (value < 0.24) return SPLASH_TRIM.crownBand
  return SPLASH_TRIM.none
}

/** Stack a podium, setbacks, roof equipment, and an optional mast on one plot; returns the tiers it added. */
function addBuilding(city: CityDraft, random: () => number, plot: Plot): SplashTier[] {
  const seed = random()
  const facade = pickFacade(random)
  const lit = 0.08 + random() * 0.3
  const trim = pickTrim(random)
  const added: SplashTier[] = []
  let base = 0
  let width = plot.width
  let depth = plot.depth
  let tierCount = plot.height > 60 ? 2 + Math.floor(random() * 2) : random() < 0.4 ? 2 : 1
  if (tierCount > 1 && random() < 0.55) {
    const podium = Math.min(plot.height * 0.4, 9 + random() * 10)
    added.push({
      x: plot.x, y: 0, z: plot.z, width, depth, height: podium,
      seed, facade: SPLASH_FACADE.panel, lit: Math.min(1, lit + 0.15), trim: SPLASH_TRIM.none, storefront: plot.storefront,
    })
    base = podium
    width *= 0.7 + random() * 0.18
    depth *= 0.7 + random() * 0.18
    tierCount -= 1
  }
  for (let tier = 0; tier < tierCount; tier += 1) {
    const remaining = plot.height - base
    const last = tier === tierCount - 1
    const height = last ? remaining : remaining * (0.58 + random() * 0.2)
    added.push({
      x: plot.x, y: base, z: plot.z, width, depth, height,
      seed, facade, lit, trim: last ? trim : SPLASH_TRIM.none, storefront: plot.storefront && base === 0,
    })
    base += height
    width *= 0.72 + random() * 0.16
    depth *= 0.72 + random() * 0.16
  }
  const top = added.at(-1)
  if (top === undefined) return added
  const roof = top.y + top.height
  const units = 1 + Math.floor(random() * 3)
  for (let unit = 0; unit < units; unit += 1) {
    const unitWidth = 1.6 + random() * Math.min(5, top.width * 0.3)
    const unitDepth = 1.6 + random() * Math.min(5, top.depth * 0.3)
    city.roofUnits.push({
      x: top.x + (random() - 0.5) * (top.width - unitWidth - 1.5),
      y: roof,
      z: top.z + (random() - 0.5) * (top.depth - unitDepth - 1.5),
      width: unitWidth,
      height: 1.2 + random() * 2.4,
      depth: unitDepth,
    })
  }
  if (plot.height > 70 && random() < 0.55) {
    city.antennas.push({
      x: top.x + (random() - 0.5) * top.width * 0.5,
      y: roof,
      z: top.z + (random() - 0.5) * top.depth * 0.5,
      height: 7 + random() * 16,
    })
  }
  city.tiers.push(...added)
  return added
}

/** Avenue frontage on one side: shop fronts, blade signs, and facade screens facing the camera corridor. */
function addFrontage(city: CityDraft, random: () => number, side: -1 | 1): void {
  let z = SPLASH_AVENUE.start
  while (z > SPLASH_AVENUE.end + 12) {
    const length = Math.min(z - SPLASH_AVENUE.end, 14 + random() * 13)
    const centreZ = z - length / 2
    const width = 15 + random() * 13
    const setback = random() * 2.2
    const face = SPLASH_AVENUE_FRONTAGE + setback
    const towerward = Math.max(0, Math.min(1, (40 - centreZ) / 220))
    // Frontage near the plaza stays below the mark so the resting shot keeps it unobstructed.
    const ceiling = centreZ < -120 ? 132 : Infinity
    const height = Math.min(ceiling, 26 + random() ** 1.5 * 96 + towerward * 46)
    const tiers = addBuilding(city, random, {
      x: side * (face + width / 2), z: centreZ, width, depth: length, height, storefront: true,
    })
    const street = tiers[0]
    if (street !== undefined && centreZ < 160 && centreZ > -150) {
      const count = random() < 0.8 ? 1 + Math.floor(random() * 2.4) : 0
      for (let index = 0; index < count; index += 1) {
        // Sign artwork slots are 1:4; heights follow widths so glyphs keep their proportions.
        const signWidth = 2.1 + random() * 0.6
        const signHeight = signWidth * (3.7 + random() * 0.5)
        const bottom = 5.5 + random() * Math.max(0, Math.min(34, street.height - signHeight - 7))
        if (bottom + signHeight > street.height - 1) continue
        city.signs.push({
          x: side * (face - signWidth / 2 - 0.35),
          y: bottom,
          z: centreZ + (index - (count - 1) / 2) * Math.min(5, length / Math.max(1, count)) + (random() - 0.5),
          width: signWidth,
          height: signHeight,
          slot: Math.floor(random() * SPLASH_SIGN_SLOTS),
        })
      }
    }
    if (street !== undefined && height > 46 && length > 16 && random() < 0.42 && centreZ < 120) {
      const screenWidth = Math.min(length - 4, 11 + random() * 9)
      const screenHeight = screenWidth * (0.5 + random() * 0.12)
      const screenY = Math.min(street.height - screenHeight / 2 - 3, 20 + screenHeight / 2 + random() * 26)
      if (screenY - screenHeight / 2 > 12) {
        city.screens.push({
          x: side * (face - 0.45), y: screenY, z: centreZ,
          width: screenWidth, height: screenHeight, yaw: -side * Math.PI / 2,
          slot: Math.floor(random() * SPLASH_SCREEN_SLOTS),
        })
      }
    }
    z -= length + (random() < 0.4 ? 4 + random() * 5 : 1.2)
  }
}

/** Taller second-row towers behind the frontage; some carry rooftop screens facing the camera. */
function addSecondRow(city: CityDraft, random: () => number, side: -1 | 1): void {
  let z = SPLASH_AVENUE.start - 10
  while (z > -300) {
    const length = 18 + random() * 14
    const centreZ = z - length / 2
    const width = 18 + random() * 16
    const towerward = Math.max(0, Math.min(1, (60 - centreZ) / 300))
    const height = 50 + random() ** 1.3 * 110 + towerward * 60
    const tiers = addBuilding(city, random, {
      x: side * (44 + random() * 10 + width / 2), z: centreZ, width, depth: length, height, storefront: false,
    })
    const top = tiers.at(-1)
    if (top !== undefined && centreZ < -40 && random() < 0.35) {
      const screenWidth = Math.min(top.width - 2, 12 + random() * 8)
      const screenHeight = screenWidth * 0.48
      city.screens.push({
        x: top.x, y: top.y + top.height + 1.2 + screenHeight / 2, z: top.z + top.depth / 2 - 1,
        width: screenWidth, height: screenHeight, yaw: 0,
        slot: Math.floor(random() * SPLASH_SCREEN_SLOTS),
      })
    }
    z -= length + 3 + random() * 6
  }
}

/** Surrounding districts on a street grid, rising toward the landmark. */
function addDistricts(city: CityDraft, random: () => number): void {
  for (let gridX = -520; gridX <= 520; gridX += 46) {
    for (let gridZ = -780; gridZ <= 200; gridZ += 46) {
      if (Math.abs(gridX) < 96 && gridZ > -320) continue
      if (Math.hypot(gridX - SPLASH_TOWER.x, gridZ - SPLASH_TOWER.z) < 90) continue
      const buildings = 1 + Math.floor(random() * 2.2)
      for (let index = 0; index < buildings; index += 1) {
        const width = 12 + random() * (buildings === 1 ? 20 : 12)
        const depth = 12 + random() * (buildings === 1 ? 20 : 12)
        const x = gridX + (random() - 0.5) * (34 - width)
        const z = gridZ + (random() - 0.5) * (34 - depth)
        const toTower = Math.hypot(x - SPLASH_TOWER.x, z - SPLASH_TOWER.z)
        const spike = random() < 0.07 ? 70 + random() * 110 : 0
        const height = 16 + random() ** 1.8 * 70 + 120 * Math.exp(-((toTower / 300) ** 2)) + spike
        addBuilding(city, random, { x, z, width, depth, height, storefront: false })
      }
    }
  }
}

/** Distant megastructures that read as silhouettes through the haze. */
function addMegastructures(city: CityDraft, random: () => number): void {
  for (let index = 0; index < 14; index += 1) {
    const angle = -Math.PI * 0.92 + (index / 13) * Math.PI * 0.84 + (random() - 0.5) * 0.1
    const distance = 720 + random() * 420
    const width = 70 + random() * 70
    addBuilding(city, random, {
      x: SPLASH_TOWER.x + Math.cos(angle) * distance,
      z: SPLASH_TOWER.z + Math.sin(angle) * distance,
      width,
      depth: width * (0.7 + random() * 0.5),
      height: 260 + random() * 240,
      storefront: false,
    })
  }
}

/** The landmark the camera rises toward; the projector deck carries the mark. */
function addLandmark(city: CityDraft): void {
  const { x, z, deck } = SPLASH_TOWER
  const tier = (y: number, width: number, height: number, facade: SplashFacade, trim: SplashTrim): SplashTier => ({
    x, y, z, width, depth: width, height, seed: 0.618, facade, lit: 0.42, trim, storefront: false,
  })
  city.tiers.push(
    tier(0, 72, 22, SPLASH_FACADE.panel, SPLASH_TRIM.crownBand),
    tier(22, 36, 96, SPLASH_FACADE.hero, SPLASH_TRIM.none),
    tier(118, 30, 22, SPLASH_FACADE.hero, SPLASH_TRIM.crownBand),
    tier(140, 24, deck - 140, SPLASH_FACADE.hero, SPLASH_TRIM.crownBand),
  )
}

/** Skybridges across the avenue, placed clear of the camera's height where it crosses them. */
function addSkybridges(city: CityDraft, random: () => number): void {
  for (const z of [118, 86, 47, 18, -16, -58, -112, -160]) {
    const camera = cameraHeightNear(z)
    let bottom: number
    if (camera === undefined) bottom = 30 + random() * 50
    else if (camera < 22) bottom = camera + 14 + random() * 16
    else if (camera > 42) bottom = camera - 18 - random() * 10
    else continue
    if (bottom < 10) continue
    const top = bottom + 4.6
    // Each end sinks 1.5 m into the nearest tier that spans the bridge's height on that side.
    const ends = ([-1, 1] as const).map(side => {
      const faces = city.tiers
        .filter(tier => Math.sign(tier.x) === side
          && Math.abs(tier.z - z) < tier.depth / 2 - 4
          && tier.y < bottom && tier.y + tier.height > top + 6)
        .map(tier => Math.abs(tier.x) - tier.width / 2)
      return faces.length === 0 ? undefined : side * (Math.min(...faces) + 1.5)
    })
    const [left, right] = ends
    if (left === undefined || right === undefined || right - left > SPLASH_AVENUE_FRONTAGE * 2 + 10) continue
    city.tiers.push({
      x: (left + right) / 2, y: bottom, z, width: right - left, height: top - bottom, depth: 6.5,
      seed: random(), facade: SPLASH_FACADE.glass, lit: 0.55, trim: SPLASH_TRIM.none, storefront: false,
    })
  }
}

/**
 * Build the seeded city: avenue frontage with signs and screens, second row, districts, skyline, and landmark.
 * @returns the same layout on every call.
 */
export function splashCityLayout(): SplashCityLayout {
  const random = createRandom(0x70a704)
  const city: CityDraft = { tiers: [], roofUnits: [], antennas: [], signs: [], screens: [] }
  addFrontage(city, random, -1)
  addFrontage(city, random, 1)
  addSecondRow(city, random, -1)
  addSecondRow(city, random, 1)
  addDistricts(city, random)
  addMegastructures(city, random)
  addLandmark(city)
  addSkybridges(city, random)
  return city
}

/**
 * Seeded air and street traffic: avenue lanes in both directions, cross lanes over the canyon, and street cars.
 * @returns the same vehicles on every call.
 */
export function splashTraffic(): SplashVehicle[] {
  const random = createRandom(0x5eed)
  const vehicles: SplashVehicle[] = []
  const lane = (
    origin: SplashVector, directionX: number, directionZ: number, count: number, span: number,
    speed: [number, number], trail: [number, number], radius: number, headlight: boolean,
  ): void => {
    for (let index = 0; index < count; index += 1) {
      vehicles.push({
        origin, directionX, directionZ,
        speed: speed[0] + random() * (speed[1] - speed[0]),
        phase: (index + random() * 0.7) * span / count,
        span,
        trail: trail[0] + random() * (trail[1] - trail[0]),
        radius,
        headlight,
      })
    }
  }
  for (const height of [24, 38, 57, 82, 112]) {
    lane({ x: -8.6, y: height, z: -60 }, 0, 1, 7, 560, [28, 42], [7, 13], 0.32, true)
    lane({ x: 8.6, y: height + 3, z: -60 }, 0, -1, 7, 560, [28, 42], [7, 13], 0.3, false)
  }
  for (const [z, height] of [[40, 70], [40, 92], [-140, 96], [-140, 128], [-330, 74], [-330, 118]] as const) {
    lane({ x: 0, y: height, z }, 1, 0, 9, 720, [36, 54], [9, 16], 0.34, true)
    lane({ x: 0, y: height + 4, z: z - 6 }, -1, 0, 9, 720, [36, 54], [9, 16], 0.32, false)
  }
  // Street cars carry a pair of lights that share one speed and phase.
  for (const [x, directionZ] of [[-6.6, 1], [-3.3, 1], [3.3, -1], [6.6, -1]] as const) {
    for (let index = 0; index < 6; index += 1) {
      const speed = 13 + random() * 6
      const phase = (index + random() * 0.7) * 400 / 6
      const trail = 1.2 + random() * 0.8
      for (const offset of [-0.72, 0.72]) {
        vehicles.push({
          origin: { x: x + offset, y: 0.78, z: -20 }, directionX: 0, directionZ,
          speed, phase, span: 400, trail, radius: 0.16, headlight: directionZ > 0,
        })
      }
    }
  }
  return vehicles
}
