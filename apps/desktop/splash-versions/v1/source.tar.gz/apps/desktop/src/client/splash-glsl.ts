/** GLSL sources for the launch city: shared noise, sky, haze, and per-surface shading. */

/**
 * Uniforms, hashes, noise, sky radiance, mark light, and height haze shared by every city surface.
 * Materials that include it bind the shared `uTime`, `uHoloPos`, `uHolo`, `uFogDensity`, and `uFogFalloff` uniform objects.
 */
export const CITY_COMMON_GLSL = /* glsl */ `
uniform float uTime;
uniform vec3 uHoloPos;
uniform float uHolo;
uniform float uFogDensity;
uniform float uFogFalloff;

const vec3 HOLO_RGB = vec3(1.0, 0.075, 0.06);
const vec3 HAZE_LOW = vec3(0.2, 0.038, 0.052);
const vec3 HAZE_HIGH = vec3(0.028, 0.013, 0.042);

float hash11(float p) {
  p = fract(p * 0.1031);
  p *= p + 33.33;
  p *= p + p;
  return fract(p);
}

float hash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

float hash13(vec3 p3) {
  p3 = fract(p3 * 0.1031);
  p3 += dot(p3, p3.zyx + 31.32);
  return fract((p3.x + p3.y) * p3.z);
}

float valueNoise(vec2 p) {
  vec2 cell = floor(p);
  vec2 f = fract(p);
  vec2 blend = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(hash12(cell), hash12(cell + vec2(1.0, 0.0)), blend.x),
    mix(hash12(cell + vec2(0.0, 1.0)), hash12(cell + vec2(1.0, 1.0)), blend.x),
    blend.y);
}

float fbm(vec2 p, int octaves) {
  float value = 0.0;
  float amplitude = 0.5;
  for (int octave = 0; octave < 6; octave++) {
    if (octave >= octaves) break;
    value += amplitude * valueNoise(p);
    p = p * 2.03 + vec2(17.13, 9.71);
    amplitude *= 0.5;
  }
  return value;
}

// Coverage of a line of half-width halfWidth at signed offset; sub-pixel lines widen to one pixel at reduced energy.
float lineCoverage(float offset, float halfWidth, float pixel) {
  float shown = max(halfWidth, pixel);
  return clamp((shown - abs(offset)) / pixel + 0.5, 0.0, 1.0) * (halfWidth / shown);
}

// Polluted night sky: red horizon glow, under-lit cloud deck, and the mark's glint.
vec3 skyRadiance(vec3 origin, vec3 direction, int cloudOctaves) {
  float rise = direction.y;
  vec3 color = mix(HAZE_LOW * 1.08, vec3(0.052, 0.012, 0.038), smoothstep(0.0, 0.16, rise));
  color = mix(color, vec3(0.005, 0.005, 0.013), smoothstep(0.12, 0.62, rise));
  color = mix(color, HAZE_LOW * 0.8, smoothstep(0.0, -0.25, rise));
  if (cloudOctaves > 0 && rise > 0.0) {
    vec2 drift = vec2(uTime * 0.008, uTime * 0.003);
    float density = smoothstep(0.42, 0.86, fbm(direction.xz / (rise + 0.09) * 1.5 + drift, cloudOctaves));
    vec3 underside = mix(vec3(0.24, 0.046, 0.056), vec3(0.042, 0.018, 0.05), smoothstep(0.03, 0.4, rise));
    color = mix(color, underside, density * smoothstep(0.0, 0.12, rise) * 0.9);
  }
  float toward = max(dot(direction, normalize(uHoloPos - origin)), 0.0);
  color += HOLO_RGB * uHolo * 0.02 * pow(toward, 40.0);
  return color;
}

// Red light the lit mark casts on nearby surfaces.
vec3 holoLight(vec3 position, vec3 normal) {
  vec3 toLight = uHoloPos - position;
  float distanceSq = dot(toLight, toLight);
  return HOLO_RGB * uHolo * 3200.0 / (distanceSq + 1200.0) * max(dot(normal, toLight * inversesqrt(distanceSq)), 0.0);
}

// Exponential height haze integrated along the eye ray.
float hazeAmount(vec3 position) {
  vec3 ray = position - cameraPosition;
  float rayLength = length(ray);
  float originY = max(cameraPosition.y, 0.0);
  float rise = ray.y / max(rayLength, 1e-3) * uFogFalloff;
  float path = abs(rise) < 1e-5 ? rayLength : (1.0 - exp(-rayLength * rise)) / rise;
  return 1.0 - exp(-uFogDensity * exp(-originY * uFogFalloff) * path);
}

vec3 hazeRadiance(vec3 position) {
  vec3 ray = position - cameraPosition;
  vec3 direction = ray / max(length(ray), 1e-3);
  float middle = max(cameraPosition.y, 0.0) + ray.y * 0.5;
  vec3 haze = mix(HAZE_LOW, HAZE_HIGH, smoothstep(0.0, 210.0, middle));
  float toward = max(dot(direction, normalize(uHoloPos - cameraPosition)), 0.0);
  return haze + HOLO_RGB * uHolo * 0.07 * pow(toward, 28.0);
}

vec3 applyHaze(vec3 color, vec3 position) {
  return mix(color, hazeRadiance(position), hazeAmount(position));
}
`

/** Instanced building tiers: a unit box with its base at y = 0, scaled and placed per instance. */
export const FACADE_VERTEX_GLSL = /* glsl */ `
attribute vec3 aCenter;
attribute vec3 aSize;
attribute vec4 aStyle;
attribute float aStorefront;
flat varying vec4 vStyle;
flat varying vec3 vSize;
flat varying vec2 vTier;
varying vec3 vWorld;
varying vec3 vLocal;
varying vec3 vNormal;

void main() {
  vec3 local = position * aSize;
  vec3 world = aCenter + local;
  vStyle = aStyle;
  vSize = aSize;
  vTier = vec2(aCenter.y, aStorefront);
  vWorld = world;
  vLocal = local;
  vNormal = normal;
  gl_Position = projectionMatrix * viewMatrix * vec4(world, 1.0);
}
`

/**
 * Facades: interior-mapped rooms behind Fresnel glass, mullions, spandrels, blinds, shop fronts, and steady accent strips.
 * Window detail fades to its average once a window spans only a few pixels, so distant facades never sparkle.
 */
export const FACADE_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
flat varying vec4 vStyle;
flat varying vec3 vSize;
flat varying vec2 vTier;
varying vec3 vWorld;
varying vec3 vLocal;
varying vec3 vNormal;

vec3 roomTint(float h) {
  if (h < 0.42) return vec3(1.0, 0.5, 0.2);
  if (h < 0.7) return vec3(0.8, 0.9, 1.0);
  if (h < 0.86) return vec3(0.32, 0.56, 1.0);
  if (h < 0.94) return vec3(1.0, 0.18, 0.5);
  return vec3(0.12, 0.95, 0.88);
}

vec3 neonTint(float h) {
  if (h < 0.42) return vec3(1.0, 0.08, 0.1);
  if (h < 0.68) return vec3(0.12, 0.72, 1.0);
  if (h < 0.86) return vec3(1.0, 0.24, 0.58);
  return vec3(1.0, 0.58, 0.16);
}

// Ray exit from inside a room box spanning [-1, 1]^3; the window is the z = -1 face.
vec3 roomRadiance(vec2 cellUv, vec3 direction, vec3 light, float lit, float hash) {
  vec3 origin = vec3(cellUv * 2.0 - 1.0, -1.0);
  vec3 inverse = 1.0 / (direction + vec3(1e-5));
  vec3 exits = abs(inverse) - origin * inverse;
  float t = min(min(exits.x, exits.y), exits.z);
  vec3 hit = origin + direction * t;
  float depth = hit.z * 0.5 + 0.5;
  float shade;
  if (t == exits.z) {
    shade = 0.4 + 0.16 * hit.y;
    float furniture = step(hit.y, -0.42) * step(0.3, fract(hit.x * 1.7 + hash * 5.0));
    shade *= 1.0 - 0.45 * furniture;
  } else if (t == exits.y) {
    if (direction.y > 0.0) {
      float fixture = (1.0 - smoothstep(0.36, 0.48, abs(hit.x))) * (1.0 - smoothstep(0.14, 0.24, abs(hit.z - 0.15)));
      shade = 0.5 + 0.9 * fixture;
    } else {
      shade = 0.13 + 0.12 * depth;
    }
  } else {
    shade = 0.24 + 0.16 * depth;
  }
  vec3 dark = vec3(0.0035, 0.0045, 0.008) * (0.5 + depth) + vec3(0.0, 0.009, 0.024) * step(0.88, hash) * (1.0 - depth);
  return mix(dark, light * shade, lit);
}

vec3 storefront(float u, float y, float seed, vec3 sky, float fresnel) {
  float shopCoord = u / 6.5;
  float shop = floor(shopCoord);
  float across = fract(shopCoord);
  float shopHash = hash12(vec2(shop, seed * 91.0));
  vec2 pixel = max(fwidth(vec2(shopCoord, y)), vec2(1e-4));
  float glassMask = smoothstep(0.35 - pixel.y, 0.35 + pixel.y, y) * (1.0 - smoothstep(3.5 - pixel.y, 3.5 + pixel.y, y))
    * smoothstep(0.03 - pixel.x, 0.03 + pixel.x, across) * (1.0 - smoothstep(0.97 - pixel.x, 0.97 + pixel.x, across));
  float shelves = 0.5 + 0.5 * step(0.28, fract(y * 1.6 + shopHash * 3.0));
  vec3 interior = roomTint(shopHash) * 0.34 * (0.7 + 0.6 * hash11(shopHash * 13.0)) * shelves
    * (0.55 + 0.45 * valueNoise(vec2(u * 1.3, y * 1.7)));
  float open = step(0.16, fract(shopHash * 7.1));
  float shutterRibs = 0.7 + 0.3 * step(0.5, fract(y * 9.0));
  vec3 shutter = vec3(0.03) * mix(1.0, shutterRibs, smoothstep(30.0, 60.0, 1.0 / pixel.y));
  float mullion = lineCoverage((fract(u / 1.6 + 0.5) - 0.5) * 1.6, 0.035, max(fwidth(u), 1e-4));
  vec3 window = mix(mix(shutter, interior, open) * (1.0 - fresnel) + sky * fresnel, vec3(0.012), mullion * open);
  float band = smoothstep(3.8 - pixel.y, 3.8 + pixel.y, y) * (1.0 - smoothstep(5.0 - pixel.y, 5.0 + pixel.y, y));
  vec2 glyphCoord = vec2(u * 2.4, (y - 3.95) * 2.8);
  vec2 glyphCell = floor(glyphCoord);
  vec2 glyphUv = fract(glyphCoord);
  float glyph = step(0.42, hash12(glyphCell + shop * 7.0)) * step(0.16, glyphUv.x) * step(glyphUv.x, 0.84)
    * step(0.12, glyphUv.y) * step(glyphUv.y, 0.88);
  float textArea = step(0.18, across) * step(across, 0.82) * step(4.0, y) * step(y, 4.8);
  float glyphDetail = smoothstep(2.0, 6.0, 1.0 / max(fwidth(glyphCoord.x), 1e-4));
  vec3 signLight = neonTint(fract(shopHash * 3.7)) * mix(0.3, 0.06 + 1.3 * glyph * textArea, glyphDetail);
  return mix(mix(vec3(0.02), window, glassMask), signLight, band);
}

vec3 wallRadiance(vec3 normal, vec3 view) {
  float seed = vStyle.x;
  int facade = int(vStyle.y + 0.5);
  float litRatio = vStyle.z;
  int trim = int(vStyle.w + 0.5);
  vec3 tangent = vec3(normal.z, 0.0, -normal.x);
  float faceWidth = abs(normal.x) > 0.5 ? vSize.z : vSize.x;
  float u = dot(vLocal, tangent) + faceWidth * 0.5;
  float y = vWorld.y;
  float faceId = dot(normal, vec3(1.0, 0.0, 2.0)) + 3.0;

  float floorHeight = 3.4 + 0.9 * hash11(seed * 71.3 + 0.17);
  float targetCell = facade == 1 ? 2.3 + 1.3 * hash11(seed * 13.7) : 1.35 + 1.45 * hash11(seed * 29.3);
  float cellWidth = faceWidth / max(1.0, floor(faceWidth / targetCell + 0.5));
  vec2 coord = vec2(u / cellWidth, y / floorHeight);
  vec2 cell = floor(coord);
  vec2 cellUv = fract(coord);
  vec2 pixel = max(fwidth(coord), vec2(1e-5));
  float detail = smoothstep(1.8, 5.5, 1.0 / max(pixel.x, pixel.y));

  vec4 window = facade == 1 ? vec4(0.2, 0.3, 0.8, 0.82)
    : facade == 2 ? vec4(0.02, 0.36, 0.98, 0.86)
    : facade == 3 ? vec4(0.05, 0.18, 0.95, 0.97)
    : vec4(0.045, 0.25, 0.955, 0.965);
  vec2 inside = smoothstep(window.xy - pixel, window.xy + pixel, cellUv)
    * (1.0 - smoothstep(window.zw - pixel, window.zw + pixel, cellUv));
  float windowMask = inside.x * inside.y;
  float windowArea = (window.z - window.x) * (window.w - window.y);

  float floorBias = hash12(vec2(cell.y, seed * 113.0 + faceId));
  float roomHash = hash13(vec3(cell, seed * 197.0 + faceId * 7.0));
  float litChance = clamp(litRatio * (0.3 + 1.4 * floorBias), 0.0, 0.95);
  float lit = step(roomHash, litChance);
  float zone = floor(cell.x / 4.0);
  vec3 light = roomTint(hash13(vec3(cell.y, zone, seed * 53.0 + faceId))) * (0.2 + 0.26 * hash12(cell + seed * 11.0));

  float roomDepth = cellWidth * 1.25 + 1.6;
  vec3 roomDirection = vec3(dot(view, tangent) / (0.5 * cellWidth), view.y / (0.5 * floorHeight), -dot(view, normal) / (0.5 * roomDepth));
  vec3 room = roomRadiance(cellUv, roomDirection, light, lit, roomHash);

  float blindHash = hash13(vec3(cell.yx, seed * 7.0 + faceId + 3.0));
  float blindLevel = mix(window.y, window.w, 0.2 + 0.7 * fract(blindHash * 7.31));
  float blinds = step(blindHash, 0.3) * smoothstep(blindLevel - pixel.y, blindLevel + pixel.y, cellUv.y);
  float slats = mix(1.0, 0.72 + 0.28 * step(0.35, fract(cellUv.y * floorHeight * 5.0)), smoothstep(40.0, 80.0, 1.0 / pixel.y));
  room = mix(room, mix(vec3(0.01), light * 0.5, lit) * slats, blinds);

  vec3 reflected = reflect(view, normal);
  float cosine = clamp(-dot(view, normal), 0.0, 1.0);
  float fresnel = 0.04 + 0.96 * pow(1.0 - cosine, 5.0);
  vec3 sky = skyRadiance(vWorld, reflected, 0);
  vec3 glass = room * vec3(0.8, 0.86, 0.9) * (1.0 - fresnel) + sky * fresnel;

  vec3 albedo;
  float sheen;
  if (facade == 1) {
    float grime = fbm(vec2(u * 0.3, y * 0.04) + seed * 31.0, 3);
    float seam = lineCoverage(cellUv.x - 0.5, 0.012, pixel.x) * 0.5;
    albedo = vec3(0.055, 0.05, 0.052) * (0.6 + 0.8 * grime) * (1.0 - seam);
    sheen = 0.06;
  } else if (facade == 2) {
    albedo = vec3(0.03, 0.032, 0.038);
    sheen = 0.35;
  } else if (facade == 3) {
    albedo = vec3(0.012, 0.01, 0.014);
    sheen = 0.5;
  } else {
    albedo = vec3(0.018, 0.02, 0.026);
    sheen = 0.45;
  }
  float avenue = step(0.5, -normal.x * sign(vWorld.x)) * (1.0 - smoothstep(26.0, 70.0, abs(vWorld.x))) * step(-205.0, vWorld.z);
  vec3 neon = mix(vec3(1.0, 0.08, 0.1), vec3(0.1, 0.65, 1.0), smoothstep(0.35, 0.65, valueNoise(vec2(vWorld.z * 0.05, seed * 9.0))));
  vec3 spill = neon * 0.9 * exp(-max(y - 2.0, 0.0) / 14.0) * avenue;
  vec3 ambient = mix(vec3(0.42, 0.11, 0.14), vec3(0.11, 0.1, 0.2), smoothstep(0.0, 180.0, y));
  vec3 structure = albedo * (ambient + spill + holoLight(vWorld, normal)) + sky * (0.04 + 0.5 * pow(1.0 - cosine, 5.0)) * sheen;

  vec3 averageRoom = mix(vec3(0.005), vec3(0.13, 0.11, 0.09), litRatio);
  vec3 averageFacade = mix(structure, averageRoom * (1.0 - fresnel) + sky * fresnel, windowArea);
  vec3 color = mix(averageFacade, mix(structure, glass, windowMask), detail);

  float pixelU = max(fwidth(u), 1e-4);
  if (facade == 3) {
    float period = cellWidth * 4.0;
    float offset = mod(u + 0.5 * period, period) - 0.5 * period;
    color += vec3(1.0, 0.06, 0.05) * 1.5 * lineCoverage(offset, 0.12, pixelU);
  }
  if (trim == 1 || trim == 2) {
    float edge = min(u, faceWidth - u);
    vec3 strip = trim == 1 ? vec3(1.0, 0.07, 0.06) * 2.2 : vec3(0.1, 0.72, 1.0) * 1.8;
    color += strip * lineCoverage(edge - 0.22, 0.22, pixelU);
  } else if (trim == 3) {
    float below = vTier.x + vSize.y - y;
    color += vec3(1.0, 0.07, 0.06) * 1.9 * lineCoverage(below - 0.45, 0.35, max(fwidth(y), 1e-4));
  }
  if (vTier.y > 0.5 && avenue > 0.5 && y < 5.6) color = storefront(u, y, seed, sky, fresnel);
  return color;
}

vec3 roofRadiance() {
  float grime = fbm(vWorld.xz * 0.12 + vStyle.x * 40.0, 3);
  vec3 albedo = vec3(0.045, 0.042, 0.046) * (0.65 + 0.6 * grime);
  vec2 edge = 0.5 * vSize.xz - abs(vLocal.xz);
  float rim = 1.0 - smoothstep(0.0, 0.6, min(edge.x, edge.y));
  return albedo * (vec3(0.16, 0.08, 0.14) + holoLight(vWorld, vec3(0.0, 1.0, 0.0))) * (1.0 + 0.8 * rim);
}

// Skybridge undersides carry rows of cool panel lights.
vec3 soffitRadiance() {
  float pixel = max(fwidth(vLocal.x), 1e-4);
  float row = fract(vLocal.x / 3.0 + 0.5) * 3.0 - 1.5;
  float inside = step(abs(vLocal.z), 0.32 * vSize.z);
  return vec3(0.012) + vec3(0.6, 0.85, 1.0) * 1.1 * lineCoverage(row, 0.25, pixel) * inside;
}

void main() {
  vec3 normal = normalize(vNormal);
  vec3 view = normalize(vWorld - cameraPosition);
  vec3 color;
  if (normal.y > 0.5) color = roofRadiance();
  else if (normal.y < -0.5) color = soffitRadiance();
  else color = wallRadiance(normal, view);
  gl_FragColor = vec4(applyHaze(color, vWorld), 1.0);
}
`

/** Ground plane projected into the reflector's mirrored render. */
export const GROUND_VERTEX_GLSL = /* glsl */ `
uniform mat4 textureMatrix;
varying vec4 vReflection;
varying vec3 vWorld;

void main() {
  vReflection = textureMatrix * vec4(position, 1.0);
  vec4 world = modelMatrix * vec4(position, 1.0);
  vWorld = world.xyz;
  gl_Position = projectionMatrix * viewMatrix * world;
}
`

/**
 * Wet asphalt: puddle mirrors, rough streaked reflections elsewhere, worn lane paint, a cyan guide line,
 * lamp pools, and shop-front neon spill. `color`, `tDiffuse`, and `textureMatrix` are bound by `Reflector`.
 */
export const GROUND_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
uniform vec3 color;
uniform sampler2D tDiffuse;
uniform vec4 uStreet;
uniform vec2 uAvenue;
varying vec4 vReflection;
varying vec3 vWorld;

void main() {
  vec3 p = vWorld;
  vec3 view = normalize(p - cameraPosition);
  float across = abs(p.x);
  vec2 pixel = max(fwidth(p.xz), vec2(1e-4));
  float onAvenue = step(uAvenue.y, p.z) * step(p.z, uAvenue.x);
  float frontage = uStreet.w;
  float sidewalk = onAvenue * smoothstep(10.0 - pixel.x, 10.0 + pixel.x, across);

  float puddle = smoothstep(0.5, 0.62, fbm(p.xz * 0.045 + vec2(3.1, 7.7), 4));
  float grainDetail = 1.0 - smoothstep(0.2, 0.8, max(pixel.x, pixel.y) * 1.2);
  float grain = mix(0.5, fbm(p.xz * 1.2, 3), grainDetail);
  float wet = mix(0.45, 1.0, puddle) * (1.0 - 0.4 * sidewalk);
  float roughness = mix(0.5, 0.03, puddle);

  vec2 ripple = vec2(valueNoise(p.xz * 1.6 + uTime * 0.25), valueNoise(p.xz * 1.6 + 9.2 - uTime * 0.25)) - 0.5;
  vec2 uv = vReflection.xy / vReflection.w + ripple * 0.005 * (1.0 - 0.7 * puddle) * grainDetail;
  vec3 reflection = vec3(0.0);
  float weight = 0.0;
  for (int tap = -3; tap <= 3; tap++) {
    float offset = float(tap) / 3.0;
    float tapWeight = exp(-offset * offset * 2.0);
    reflection += textureLod(tDiffuse, uv + vec2(0.0, offset * roughness * 0.05), roughness * 4.0).rgb * tapWeight;
    weight += tapWeight;
  }
  reflection /= weight;
  float cosine = clamp(-view.y, 0.0, 1.0);
  float fresnel = 0.05 + 0.95 * pow(1.0 - cosine, 4.0);

  vec3 albedo = mix(vec3(0.02, 0.019, 0.022), vec3(0.05, 0.048, 0.052), sidewalk) * (0.7 + 0.6 * grain);
  float dash = smoothstep(0.0, pixel.y / 9.0 + 0.002, 0.42 - fract(p.z / 9.0));
  float lanes = (lineCoverage(across - 3.35, 0.08, pixel.x) + lineCoverage(across - 6.75, 0.08, pixel.x)) * dash
    + lineCoverage(across - 9.55, 0.09, pixel.x);
  float centre = lineCoverage(across - 0.22, 0.06, pixel.x);
  float wear = smoothstep(0.25, 0.6, valueNoise(p.xz * vec2(2.0, 0.4)));
  float curb = lineCoverage(across - 10.0, 0.08, pixel.x);
  albedo = mix(albedo, vec3(0.42), lanes * onAvenue * wear);
  albedo = mix(albedo, vec3(0.5, 0.36, 0.08), centre * onAvenue * wear);
  albedo = mix(albedo, vec3(0.12), curb * onAvenue);
  float paint = clamp(lanes + centre, 0.0, 1.0) * onAvenue;

  vec3 light = vec3(0.3, 0.08, 0.1);
  float lampZ = p.z - uStreet.y * floor(p.z / uStreet.y + 0.5);
  float lampX = across - uStreet.x;
  light += vec3(1.0, 0.72, 0.46) * 2.6 * exp(-(lampX * lampX + lampZ * lampZ) / 32.0) * onAvenue;
  vec3 neon = mix(vec3(1.0, 0.08, 0.1), vec3(0.1, 0.65, 1.0), smoothstep(0.35, 0.65, valueNoise(vec2(p.z * 0.05, sign(p.x) * 4.0))));
  light += neon * 1.6 * exp(-max(frontage - across, 0.0) / 2.8) * step(across, frontage) * onAvenue;
  light += holoLight(p, vec3(0.0, 1.0, 0.0));

  float shine = wet * (1.0 - 0.6 * paint);
  vec3 radiance = albedo * light * (1.0 - 0.5 * shine) + reflection * color * fresnel * shine;
  float guideDash = step(0.5, fract(p.z / 4.0));
  radiance += vec3(0.1, 0.75, 1.0) * 1.1 * lineCoverage(p.x, 0.05, pixel.x) * guideDash * onAvenue;
  gl_FragColor = vec4(applyHaze(radiance, p), 1.0);
}
`

/** Sky dome centred on the rendering camera. */
export const SKY_VERTEX_GLSL = /* glsl */ `
varying vec3 vDirection;

void main() {
  vDirection = position;
  gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);
}
`

/** Sky dome radiance with the full cloud deck. */
export const SKY_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
varying vec3 vDirection;

void main() {
  gl_FragColor = vec4(skyRadiance(cameraPosition, normalize(vDirection), 5), 1.0);
}
`

/** Instanced props without facades: roof plant, masts, lamp posts, sign housings, and crown parts. */
export const SOLID_VERTEX_GLSL = /* glsl */ `
varying vec3 vWorld;
varying vec3 vNormal;

void main() {
  mat4 model = modelMatrix;
  #ifdef USE_INSTANCING
  model = model * instanceMatrix;
  #endif
  vec4 world = model * vec4(position, 1.0);
  vWorld = world.xyz;
  vNormal = normalize(mat3(model) * normal);
  gl_Position = projectionMatrix * viewMatrix * world;
}
`

/** Dark painted metal lit by city glow and the mark, plus a uniform emissive term. */
export const SOLID_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
uniform vec3 uAlbedo;
uniform vec3 uEmissive;
uniform float uSheen;
varying vec3 vWorld;
varying vec3 vNormal;

void main() {
  vec3 normal = normalize(vNormal);
  vec3 view = normalize(vWorld - cameraPosition);
  float cosine = clamp(abs(dot(view, normal)), 0.0, 1.0);
  vec3 ambient = mix(vec3(0.4, 0.1, 0.13), vec3(0.12, 0.1, 0.2), normal.y * 0.5 + 0.5);
  vec3 sky = skyRadiance(vWorld, reflect(view, normal), 0);
  vec3 color = uAlbedo * (ambient + holoLight(vWorld, normal))
    + sky * uSheen * (0.04 + 0.96 * pow(1.0 - cosine, 5.0)) + uEmissive;
  gl_FragColor = vec4(applyHaze(color, vWorld), 1.0);
}
`

/**
 * Screen-space light capsules shared by obstruction lights, lamps, traffic, and rain. Each instance is a quad
 * around the projected segment; lights thinner than `minPixels` widen to it at reduced energy instead of shimmering.
 * `uViewport` must hold the pixel size of the render target being drawn.
 */
const LIGHT_SEGMENT_VERTEX_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
uniform vec2 uViewport;
flat varying vec4 vSegment;
flat varying vec3 vColor;
flat varying float vRadius;

void emitSegment(vec3 head, vec3 tail, float worldRadius, float minPixels, vec3 color) {
  mat4 viewProjection = projectionMatrix * viewMatrix;
  vec4 clipHead = viewProjection * vec4(head, 1.0);
  vec4 clipTail = viewProjection * vec4(tail, 1.0);
  const float nearW = 0.05;
  if (clipHead.w < nearW && clipTail.w < nearW) {
    gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
    vSegment = vec4(0.0);
    vColor = vec3(0.0);
    vRadius = 1.0;
    return;
  }
  if (clipHead.w < nearW) clipHead = mix(clipHead, clipTail, (nearW - clipHead.w) / (clipTail.w - clipHead.w));
  if (clipTail.w < nearW) clipTail = mix(clipTail, clipHead, (nearW - clipTail.w) / (clipHead.w - clipTail.w));
  vec2 halfViewport = 0.5 * uViewport;
  vec2 screenHead = clipHead.xy / clipHead.w * halfViewport;
  vec2 screenTail = clipTail.xy / clipTail.w * halfViewport;
  float pixels = worldRadius * projectionMatrix[1][1] * halfViewport.y / clipHead.w;
  float shown = max(pixels, minPixels);
  vec2 axis = screenTail - screenHead;
  float axisLength = length(axis);
  vec2 along = axisLength > 1e-3 ? axis / axisLength : vec2(1.0, 0.0);
  // Clockwise normal keeps the quad's counter-clockwise winding, so front-face culling keeps it.
  vec2 across = vec2(along.y, -along.x);
  float reach = shown * 1.8;
  float t = position.y + 0.5;
  vec2 screen = mix(screenHead - along * reach, screenTail + along * reach, t) + across * position.x * 2.0 * reach;
  vec4 clip = mix(clipHead, clipTail, t);
  gl_Position = vec4(screen / halfViewport * clip.w, clip.z, clip.w);
  float energy = pixels / shown;
  float streak = clamp(axisLength / (4.0 * shown), 0.0, 1.0);
  vSegment = vec4(screenHead, screenTail);
  vRadius = shown;
  vColor = color * mix(energy * energy, energy, streak) * (1.0 - hazeAmount(head));
}
`

/** Static point lights: aviation lights and lamp heads. */
export const POINT_LIGHT_VERTEX_GLSL = /* glsl */ `
${LIGHT_SEGMENT_VERTEX_GLSL}
attribute vec3 aHead;
attribute vec4 aLight;

void main() {
  emitSegment(aHead, aHead, aLight.w, 2.2, aLight.rgb);
}
`

/** Vehicle light trails looping along their lanes. */
export const TRAFFIC_VERTEX_GLSL = /* glsl */ `
${LIGHT_SEGMENT_VERTEX_GLSL}
attribute vec4 aLane;
attribute vec4 aMotion;
attribute vec4 aTrail;

void main() {
  vec3 direction = vec3(aMotion.x, 0.0, aMotion.y);
  float travelled = mod(aMotion.z + uTime * aLane.w, aMotion.w) - 0.5 * aMotion.w;
  vec3 head = aLane.xyz + direction * travelled;
  vec3 color = aTrail.z > 0.5 ? vec3(1.0, 0.9, 0.78) * 2.0 : vec3(1.0, 0.06, 0.045) * 2.2;
  emitSegment(head, head - direction * aTrail.x, aTrail.y, 1.4, color);
}
`

/** Rain streaks wrapped in a box that travels with the camera. */
export const RAIN_VERTEX_GLSL = /* glsl */ `
${LIGHT_SEGMENT_VERTEX_GLSL}
uniform vec3 uRainBox;
uniform float uRain;
attribute vec4 aDrop;

void main() {
  vec3 fall = vec3(1.2, -24.0 - 8.0 * aDrop.w, 0.5);
  vec3 local = mod(aDrop.xyz * uRainBox + fall * uTime - cameraPosition + 0.5 * uRainBox, uRainBox) - 0.5 * uRainBox;
  vec3 head = cameraPosition + local;
  float reach = length(local);
  float fade = smoothstep(24.0, 7.0, reach) * smoothstep(0.8, 2.4, reach) * uRain;
  emitSegment(head, head - normalize(fall) * 0.85, 0.007, 0.7, vec3(0.5, 0.56, 0.7) * 0.5 * fade);
}
`

/** Capsule glow with its brightest end at the segment head. */
export const LIGHT_FRAGMENT_GLSL = /* glsl */ `
uniform vec2 uViewport;
flat varying vec4 vSegment;
flat varying vec3 vColor;
flat varying float vRadius;

void main() {
  vec2 p = gl_FragCoord.xy - 0.5 * uViewport;
  vec2 head = vSegment.xy;
  vec2 axis = vSegment.zw - head;
  float h = clamp(dot(p - head, axis) / max(dot(axis, axis), 1e-4), 0.0, 1.0);
  float d = length(p - head - axis * h) / vRadius;
  gl_FragColor = vec4(vColor * exp(-d * d * 2.0) * pow(1.0 - h, 1.6), 1.0);
}
`

/** Instanced sign and screen quads turned by a per-instance yaw. */
export const PANEL_VERTEX_GLSL = /* glsl */ `
attribute vec4 aPanel;
attribute vec4 aShape;
flat varying vec2 vPanel;
varying vec2 vUv;
varying vec3 vWorld;

void main() {
  float c = cos(aPanel.w);
  float s = sin(aPanel.w);
  vec2 local = position.xy * aShape.xy;
  vec3 world = aPanel.xyz + vec3(local.x * c, local.y, -local.x * s);
  vPanel = aShape.zw;
  vUv = uv;
  vWorld = world;
  gl_Position = projectionMatrix * viewMatrix * vec4(world, 1.0);
}
`

/** Emissive atlas artwork; screens add fine scan lines and a slow brightness sweep. */
export const PANEL_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
uniform sampler2D uAtlas;
uniform vec2 uGrid;
uniform float uScreen;
flat varying vec2 vPanel;
varying vec2 vUv;
varying vec3 vWorld;

void main() {
  float column = mod(vPanel.x, uGrid.x);
  float row = floor(vPanel.x / uGrid.x);
  vec2 uv = vec2((column + vUv.x) / uGrid.x, 1.0 - (row + 1.0 - vUv.y) / uGrid.y);
  vec3 color = texture2D(uAtlas, uv).rgb;
  if (uScreen > 0.5) {
    float lineCoord = vUv.y * 90.0;
    float lines = 1.0 - 0.14 * smoothstep(0.4, 0.9, abs(fract(lineCoord) - 0.5) * 2.0) * (1.0 - smoothstep(0.3, 0.7, fwidth(lineCoord)));
    float sweep = 0.86 + 0.14 * smoothstep(0.82, 1.0, 1.0 - abs(fract(vUv.y * 0.6 - uTime * 0.07) - 0.5) * 2.0);
    color *= lines * sweep;
  }
  gl_FragColor = vec4(applyHaze(color * vPanel.y, vWorld), 1.0);
}
`

/** Open cone from the projector to the mark. */
export const BEAM_VERTEX_GLSL = /* glsl */ `
varying vec3 vWorld;
varying vec3 vNormal;
varying float vHeight;

void main() {
  vHeight = uv.y;
  vec4 world = modelMatrix * vec4(position, 1.0);
  vWorld = world.xyz;
  vNormal = normalize(mat3(modelMatrix) * normal);
  gl_Position = projectionMatrix * viewMatrix * world;
}
`

/** Additive projector light: dense near the lens, climbing to `uBeamReach`, with slow rising dust. */
export const BEAM_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
uniform float uBeam;
uniform float uBeamReach;
varying vec3 vWorld;
varying vec3 vNormal;
varying float vHeight;

void main() {
  vec3 view = normalize(cameraPosition - vWorld);
  float facing = abs(dot(normalize(vNormal), view));
  float reach = 1.0 - smoothstep(uBeamReach - 0.12, uBeamReach, vHeight);
  float angle = atan(vWorld.z - uHoloPos.z, vWorld.x - uHoloPos.x);
  float dust = 0.72 + 0.28 * valueNoise(vec2(vHeight * 9.0 - uTime * 1.2, angle * 4.0));
  float density = pow(facing, 1.7) * mix(1.0, 0.5, vHeight) * dust * reach * uBeam;
  gl_FragColor = vec4(vec3(1.0, 0.17, 0.13) * 0.36 * density, 1.0);
}
`

/** Extruded mark with its source-path coordinates for the ignition field. */
export const MARK_VERTEX_GLSL = /* glsl */ `
attribute vec2 aMarkUv;
varying vec2 vMarkUv;
varying vec3 vWorld;
varying vec3 vNormal;

void main() {
  vMarkUv = aMarkUv;
  vec4 world = modelMatrix * vec4(position, 1.0);
  vWorld = world.xyz;
  vNormal = normalize(mat3(modelMatrix) * normal);
  gl_Position = projectionMatrix * viewMatrix * world;
}
`

/**
 * Neon-tube mark. Unlit strokes are dark glass; light runs outward from the beam's contact point by geodesic
 * distance along the strokes, with a hot leading edge, then settles to a steady saturated red.
 */
export const MARK_FRAGMENT_GLSL = /* glsl */ `
${CITY_COMMON_GLSL}
uniform sampler2D uField;
uniform float uIgnite;
uniform float uDormant;
varying vec2 vMarkUv;
varying vec3 vWorld;
varying vec3 vNormal;

void main() {
  float travel = texture2D(uField, vMarkUv).r;
  vec3 normal = normalize(vNormal);
  vec3 toEye = normalize(cameraPosition - vWorld);
  float facing = clamp(abs(dot(normal, toEye)), 0.0, 1.0);
  // The front passes the farthest stroke (travel = 1) before uIgnite reaches 1, so no hot edge remains at rest.
  float front = uIgnite * 1.22;
  float lit = 1.0 - smoothstep(front - 0.035, front, travel);
  if (lit <= 0.0 && uDormant <= 0.0) discard;
  float edge = smoothstep(front - 0.2, front, travel) * lit;
  vec3 rim = vec3(1.0, 0.03, 0.025) * 0.9;
  vec3 core = vec3(1.0, 0.13, 0.09) * 1.75;
  vec3 neon = mix(rim, core, pow(facing, 2.2)) + vec3(1.0, 0.42, 0.32) * 2.2 * edge;
  vec3 glass = vec3(0.09, 0.016, 0.022) * (0.3 + 0.7 * pow(1.0 - facing, 2.0)) * uDormant
    + skyRadiance(vWorld, reflect(-toEye, normal), 0) * 0.25 * pow(1.0 - facing, 3.0) * uDormant;
  gl_FragColor = vec4(applyHaze(mix(glass, neon, lit), vWorld), 1.0);
}
`
