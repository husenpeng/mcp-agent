/** HDR post-processing for the splash: a multisampled scene target, highlight-only bloom, and a lens grade. */

import * as THREE from 'three'
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js'
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js'
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js'
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js'

/** Composer and the grade controls the scene animates. */
export interface SplashPost {
  readonly composer: EffectComposer
  /** Linear exposure multiplier; 0 renders black. */
  readonly exposure: { value: number }
  /** Ambient seconds that animate the dither pattern. */
  readonly time: { value: number }
  /**
   * Resize every target.
   * @param width - CSS pixel width.
   * @param height - CSS pixel height.
   * @param pixelRatio - device pixels per CSS pixel.
   */
  setSize(width: number, height: number, pixelRatio: number): void
  dispose(): void
}

const GRADE_VERTEX_GLSL = /* glsl */ `
varying vec2 vUv;

void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`

/** ACES fitted tone curve (Hill), radial chromatic fringe, vignette, cool shadow toning, sRGB encoding, and dither. */
const GRADE_FRAGMENT_GLSL = /* glsl */ `
uniform sampler2D tDiffuse;
uniform float uExposure;
uniform float uTime;
varying vec2 vUv;

vec3 rrtAndOdtFit(vec3 v) {
  vec3 a = v * (v + 0.0245786) - 0.000090537;
  vec3 b = v * (0.983729 * v + 0.4329510) + 0.238081;
  return a / b;
}

vec3 acesFilmic(vec3 color) {
  const mat3 inputMatrix = mat3(
    vec3(0.59719, 0.07600, 0.02840),
    vec3(0.35458, 0.90834, 0.13383),
    vec3(0.04823, 0.01566, 0.83777));
  const mat3 outputMatrix = mat3(
    vec3(1.60475, -0.10208, -0.00327),
    vec3(-0.53108, 1.10813, -0.07276),
    vec3(-0.07367, -0.00605, 1.07602));
  return clamp(outputMatrix * rrtAndOdtFit(inputMatrix * (color / 0.6)), 0.0, 1.0);
}

vec3 srgbEncode(vec3 color) {
  return mix(color * 12.92, 1.055 * pow(color, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), color));
}

float hash(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

void main() {
  vec2 centred = vUv - 0.5;
  float radius = dot(centred, centred);
  vec2 fringe = centred * radius * 0.014;
  vec3 color = vec3(
    texture2D(tDiffuse, vUv + fringe).r,
    texture2D(tDiffuse, vUv).g,
    texture2D(tDiffuse, vUv - fringe).b);
  color = acesFilmic(color * uExposure);
  float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
  color *= mix(vec3(0.93, 1.0, 1.14), vec3(1.0), smoothstep(0.0, 0.3, luma));
  color *= 1.0 - 0.45 * smoothstep(0.08, 0.42, radius);
  color = srgbEncode(max(color, 0.0));
  color += (hash(gl_FragCoord.xy + fract(uTime * 7.0) * 61.0) - 0.5) * (1.5 / 255.0);
  gl_FragColor = vec4(color, 1.0);
}
`

/**
 * Build the post chain. The scene renders into a 4× multisampled half-float target; bloom only lifts radiance above 1.
 * @param renderer - renderer that owns every target.
 * @param scene - city scene.
 * @param camera - city camera.
 * @returns the composer, its grade controls, and resize/dispose actions.
 */
export function createSplashPost(renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.Camera): SplashPost {
  const target = new THREE.WebGLRenderTarget(1, 1, { type: THREE.HalfFloatType, samples: 4 })
  const composer = new EffectComposer(renderer, target)
  composer.addPass(new RenderPass(scene, camera))
  const bloom = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.55, 0.38, 1.0)
  composer.addPass(bloom)
  const exposure = { value: 0 }
  const time = { value: 0 }
  const grade = new THREE.ShaderMaterial({
    uniforms: { tDiffuse: { value: null }, uExposure: exposure, uTime: time },
    vertexShader: GRADE_VERTEX_GLSL,
    fragmentShader: GRADE_FRAGMENT_GLSL,
    depthTest: false,
    depthWrite: false,
  })
  const gradePass = new ShaderPass(grade)
  composer.addPass(gradePass)
  return {
    composer,
    exposure,
    time,
    setSize: (width, height, pixelRatio) => {
      composer.setPixelRatio(pixelRatio)
      composer.setSize(width, height)
    },
    dispose: () => {
      bloom.dispose()
      gradePass.dispose()
      grade.dispose()
      composer.dispose()
    },
  }
}
