import { describe, expect, it } from 'vitest'
import { SPLASH_TIMINGS, splashAnimationDoneAt, splashWaitingAt } from '../src/client/splash-timeline.ts'

describe('splash 3D timeline', () => {
  it('builds and traverses the city before revealing the mark and wordmark', () => {
    expect(SPLASH_TIMINGS.cityRiseMs).toBeLessThan(SPLASH_TIMINGS.markRevealMs)
    expect(SPLASH_TIMINGS.cameraMs).toBeGreaterThan(SPLASH_TIMINGS.markRevealMs)
    expect(SPLASH_TIMINGS.markRevealMs).toBeGreaterThanOrEqual(4000)
    expect(SPLASH_TIMINGS.markRevealMs + SPLASH_TIMINGS.markMs).toBeLessThanOrEqual(SPLASH_TIMINGS.wordmarkDelayMs + SPLASH_TIMINGS.wordmarkMs)
    expect(SPLASH_TIMINGS.wordmarkDelayMs + SPLASH_TIMINGS.wordmarkMs).toBeLessThan(SPLASH_TIMINGS.holdMs)
    expect(SPLASH_TIMINGS.holdMs).toBeGreaterThanOrEqual(6000)
  })

  it('reports completion at the hold frame, or after the static holds under reduced motion', () => {
    expect(splashAnimationDoneAt(false)).toBe(SPLASH_TIMINGS.holdMs)
    expect(splashAnimationDoneAt(true)).toBe(SPLASH_TIMINGS.reducedMotionHoldMs)
    expect(splashWaitingAt(6500)).toBe(6500 + SPLASH_TIMINGS.waitingDelayMs)
  })
})
