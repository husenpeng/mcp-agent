import { describe, expect, it } from 'vitest'
import { splashCameraAt, splashCityTowers, splashTowerGrowth } from '../src/client/splash-city.ts'

describe('splash 3D city geometry', () => {
  it('generates a deterministic field with a central flight corridor', () => {
    const towers = splashCityTowers()
    expect(towers).toEqual(splashCityTowers())
    expect(towers.length).toBeGreaterThan(60)
    expect(towers.some(tower => tower.height > 35)).toBe(true)
    expect(towers.some(tower => tower.accent)).toBe(true)
    expect(towers.filter(tower => Math.abs(tower.x) < 4 && tower.z > -42)).toHaveLength(0)
    for (const tower of towers) {
      expect(tower.width).toBeGreaterThan(0)
      expect(tower.depth).toBeGreaterThan(0)
      expect(tower.height).toBeGreaterThan(0)
    }
  })

  it('rises smoothly from underground and clamps construction at full height', () => {
    expect(splashTowerGrowth(0, 0.2)).toBe(0)
    expect(splashTowerGrowth(1500, 0.2)).toBeGreaterThan(0)
    expect(splashTowerGrowth(1500, 0.2)).toBeLessThan(1)
    expect(splashTowerGrowth(4000, 0.2)).toBe(1)
    expect(splashTowerGrowth(9000, 0.2)).toBe(1)
  })

  it('moves the camera through space and ends looking at the suspended mark', () => {
    const start = splashCameraAt(0)
    const end = splashCameraAt(1)
    expect(end.y).toBeGreaterThan(start.y + 20)
    expect(end.z).toBeLessThan(start.z - 40)
    expect(end.targetY).toBe(19)
    expect(end.targetZ).toBe(-35)
    expect(splashCameraAt(-1)).toEqual(start)
    expect(splashCameraAt(2)).toEqual(end)
  })
})
